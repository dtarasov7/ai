
# Создаем улучшенную версию с кешированием и ленивой загрузкой
with open('s3-commander.py', 'r', encoding='utf-8') as f:
    original_code = f.read()

# Добавляем import для кеширования после существующих импортов
import_addition = """import functools
from collections import OrderedDict
"""

# Находим позицию после последнего import
import re
last_import_pos = max([m.end() for m in re.finditer(r'^import .*$|^from .* import .*$', original_code, re.MULTILINE)])

# Вставляем новые импорты
new_code = original_code[:last_import_pos] + "\n" + import_addition + original_code[last_import_pos:]

# Создаем класс для LRU кеша
cache_class = '''
class LRUCache:
    """Простой LRU кеш для хранения результатов запросов к S3"""
    def __init__(self, maxsize=100):
        self.cache = OrderedDict()
        self.maxsize = maxsize
    
    def get(self, key):
        if key not in self.cache:
            return None
        self.cache.move_to_end(key)
        return self.cache[key]
    
    def put(self, key, value):
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        if len(self.cache) > self.maxsize:
            self.cache.popitem(last=False)
    
    def invalidate(self, pattern=None):
        """Инвалидация кеша по паттерну"""
        if pattern is None:
            self.cache.clear()
        else:
            keys_to_remove = [k for k in self.cache.keys() if pattern in k]
            for key in keys_to_remove:
                del self.cache[key]

'''

# Находим начало класса S3Manager
s3manager_start = new_code.find('class S3Manager:')

# Вставляем класс LRUCache перед S3Manager
new_code = new_code[:s3manager_start] + cache_class + new_code[s3manager_start:]

# Находим __init__ метод S3Manager и добавляем кеш
init_pattern = r'(class S3Manager:.*?def __init__\(self, endpoint_config\):.*?self\.connection_error = None)'
init_replacement = r'\1\n        \n        # Кеш для списков объектов\n        self.object_cache = LRUCache(maxsize=100)\n        self.bucket_cache = LRUCache(maxsize=10)'

new_code = re.sub(init_pattern, init_replacement, new_code, flags=re.DOTALL)

# Теперь модифицируем метод list_objects для использования кеша
list_objects_old = '''    def list_objects(self, bucket_name, prefix=''):
        if self.s3_client is None:
            return [], []
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
            folders = []
            files = []
            for page in pages:
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
            return folders, files
        except (ClientError, Exception):
            return [], []'''

list_objects_new = '''    def list_objects(self, bucket_name, prefix='', use_cache=True):
        """Список объектов с поддержкой кеширования
        
        Args:
            bucket_name: имя бакета
            prefix: префикс для фильтрации
            use_cache: использовать ли кеш
        """
        if self.s3_client is None:
            return [], []
        
        # Формируем ключ кеша
        cache_key = f"{bucket_name}:{prefix}"
        
        # Проверяем кеш
        if use_cache:
            cached = self.object_cache.get(cache_key)
            if cached is not None:
                return cached
        
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
            folders = []
            files = []
            for page in pages:
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
            
            # Сохраняем в кеш
            result = (folders, files)
            if use_cache:
                self.object_cache.put(cache_key, result)
            
            return result
        except (ClientError, Exception):
            return [], []'''

new_code = new_code.replace(list_objects_old, list_objects_new)

# Добавляем метод ленивой загрузки с пагинацией
lazy_load_method = '''
    def list_objects_lazy(self, bucket_name, prefix='', page_size=1000):
        """Ленивая загрузка объектов с использованием генератора
        
        Args:
            bucket_name: имя бакета
            prefix: префикс для фильтрации
            page_size: размер страницы для пагинации
            
        Yields:
            tuple: (folders, files) для каждой страницы результатов
        """
        if self.s3_client is None:
            yield [], []
            return
        
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(
                Bucket=bucket_name, 
                Prefix=prefix, 
                Delimiter='/',
                PaginationConfig={'PageSize': page_size}
            )
            
            for page in page_iterator:
                folders = []
                files = []
                
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
                
                yield folders, files
                
        except (ClientError, Exception):
            yield [], []
    
    def invalidate_cache(self, bucket_name=None, prefix=None):
        """Инвалидация кеша после операций изменения
        
        Args:
            bucket_name: имя бакета (опционально)
            prefix: префикс (опционально)
        """
        if bucket_name is None:
            self.object_cache.invalidate()
            self.bucket_cache.invalidate()
        else:
            pattern = f"{bucket_name}:"
            if prefix:
                pattern += prefix
            self.object_cache.invalidate(pattern)
'''

# Находим конец метода list_all_objects и вставляем новые методы
list_all_end = new_code.find('    def object_exists(self, bucket_name, key):')
if list_all_end != -1:
    new_code = new_code[:list_all_end] + lazy_load_method + "\n" + new_code[list_all_end:]

# Модифицируем методы создания/удаления объектов для инвалидации кеша
methods_to_modify = [
    'def create_bucket(self, bucket_name):',
    'def delete_bucket(self, bucket_name):',
    'def upload_file(self, local_path, bucket_name, key):',
    'def delete_object(self, bucket_name, key, version_id=None):',
    'def copy_object(self, source_bucket, source_key, dest_bucket, dest_key, version_id=None):'
]

for method_sig in methods_to_modify:
    # Находим метод
    method_start = new_code.find(method_sig)
    if method_start == -1:
        continue
    
    # Находим строку с return True после успешной операции
    method_block_start = method_start
    method_block_end = new_code.find('\n    def ', method_start + 1)
    if method_block_end == -1:
        method_block_end = len(new_code)
    
    method_block = new_code[method_block_start:method_block_end]
    
    # Добавляем инвалидацию кеша перед return True
    if 'bucket_name' in method_sig:
        if 'delete_object' in method_sig or 'upload_file' in method_sig or 'copy_object' in method_sig:
            cache_invalidation = '            self.invalidate_cache(bucket_name)\n                '
        else:
            cache_invalidation = '            self.bucket_cache.invalidate()\n                '
        
        modified_block = method_block.replace('            return True', 
                                               cache_invalidation + 'return True')
        new_code = new_code[:method_block_start] + modified_block + new_code[method_block_end:]

# Сохраняем новый файл
with open('s3-commander-enhanced.py', 'w', encoding='utf-8') as f:
    f.write(new_code)

print("✓ Создан файл s3-commander-enhanced.py с кешированием и ленивой загрузкой")
print(f"✓ Размер нового файла: {len(new_code)} символов ({len(new_code.splitlines())} строк)")
print(f"✓ Добавлено строк: {len(new_code.splitlines()) - len(original_code.splitlines())}")
