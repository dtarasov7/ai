
# Читаем файл полностью
with open('s3-commander.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Проверяем текущую структуру класса S3Manager
import re

# Находим определение класса S3Manager
s3manager_match = re.search(r'class S3Manager:.*?(?=\nclass |\Z)', code, re.DOTALL)
if s3manager_match:
    s3manager_code = s3manager_match.group(0)
    # Проверяем наличие методов list_objects и list_all_objects
    has_list_objects = 'def list_objects(' in s3manager_code
    has_list_all = 'def list_all_objects(' in s3manager_code
    print(f"Найден класс S3Manager")
    print(f"Метод list_objects: {has_list_objects}")
    print(f"Метод list_all_objects: {has_list_all}")
else:
    print("Класс S3Manager не найден")

# Проверяем размер файла
print(f"\nРазмер файла: {len(code)} символов")
print(f"Количество строк: {len(code.splitlines())}")
