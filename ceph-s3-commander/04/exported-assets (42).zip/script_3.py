
# 8. Модифицируем PanelWidget для использования ScrollBar
# Находим и заменяем создание listbox
old_linebox = '''        self.linebox = urwid.LineBox(
            urwid.Frame(
                urwid.AttrMap(self.listbox, 'body'),
                header=path_widget
            )
        )'''

new_linebox = '''        # Оборачиваем listbox в ScrollBar
        self.scrollbar = ScrollBar(self.listbox)
        
        self.linebox = urwid.LineBox(
            urwid.Frame(
                urwid.AttrMap(self.scrollbar, 'body'),
                header=path_widget
            )
        )'''

code = code.replace(old_linebox, new_linebox)
print("✓ PanelWidget обновлен для использования ScrollBar")

# 9. Добавляем отображение количества объектов в path_text для S3
# Находим секцию обновления path в _refresh_s3 для объектов
old_path_s3 = '''            self.update_header(f'[S3 Mode - {self.current_endpoint}] Sort: {self.sort_mode}')
            self.path_text.set_text(f'S3: /{self.current_endpoint}/{self.current_bucket}/{self.current_prefix}')'''

new_path_s3 = '''            self.update_header(f'[S3 Mode - {self.current_endpoint}] Sort: {self.sort_mode}')
            
            # Получаем количество объектов
            total_count, total_size = self.s3_manager.count_objects(self.current_bucket, self.current_prefix)
            if total_count is not None:
                count_info = f' [{total_count} objects, {format_size(total_size)}]'
            else:
                count_info = ''
            
            self.path_text.set_text(f'S3: /{self.current_endpoint}/{self.current_bucket}/{self.current_prefix}{count_info}')'''

code = code.replace(old_path_s3, new_path_s3)
print("✓ Добавлено отображение количества объектов в path для S3")

# 10. Добавляем отображение количества файлов в FS режиме
old_path_fs = '''    def _refresh_fs(self):
        self.update_header(f'[FS Mode] Sort: {self.sort_mode}')
        self.path_text.set_text(f'FS: {self.fs_browser.current_path}')'''

new_path_fs = '''    def _refresh_fs(self):
        self.update_header(f'[FS Mode] Sort: {self.sort_mode}')
        
        # Подсчитываем количество элементов в текущей директории
        items = self.fs_browser.list_directory()
        dir_count = sum(1 for item in items if item.get('is_dir', False) and item.get('name') != '..')
        file_count = sum(1 for item in items if not item.get('is_dir', False))
        count_info = f' [{dir_count} dirs, {file_count} files]'
        
        self.path_text.set_text(f'FS: {self.fs_browser.current_path}{count_info}')'''

code = code.replace(old_path_fs, new_path_fs)
print("✓ Добавлено отображение количества файлов в path для FS")

# 11. Добавляем цвета scrollbar в палитру
palette_pattern = r"(palette = \[.*?\n\])"
match = re.search(palette_pattern, code, re.DOTALL)

if match:
    old_palette = match.group(0)
    
    # Добавляем цвета для scrollbar перед закрывающей скобкой
    scrollbar_colors = """,
    ('scrollbar_track', 'dark gray', ''),
    ('scrollbar_thumb', 'light gray', 'dark blue')"""
    
    new_palette = old_palette[:-1] + scrollbar_colors + '\n]'
    code = code.replace(old_palette, new_palette)
    print("✓ Добавлены цвета scrollbar в палитру")

# Сохраняем финальный файл
with open('s3-commander-scrollbar.py', 'w', encoding='utf-8') as f:
    f.write(code)

print(f"\n✅ Создан файл s3-commander-scrollbar.py")
print(f"✓ Размер: {len(code)} символов")
print(f"✓ Строк кода: {len(code.splitlines())}")
print(f"\nДобавленная функциональность:")
print("  • LRU кеширование списков объектов и бакетов")
print("  • Метод count_objects() для быстрого подсчета без загрузки данных")
print("  • Метод list_objects_lazy() для ленивой загрузки больших списков")
print("  • Вертикальный ScrollBar у правой границы каждой панели")
print("  • Автоматическая инвалидация кеша при изменениях")
print("  • Отображение количества объектов и их размера в строке пути")
