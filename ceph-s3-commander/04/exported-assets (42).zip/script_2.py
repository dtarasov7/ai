
# Продолжаем модификацию кода

# 4. Добавляем кеш в __init__ S3Manager
init_pattern = r'(class S3Manager:.*?def __init__\(self, endpoint_config\):.*?self\.connection_error = None)'
init_replacement = r'\1\n        \n        # Кеш для списков объектов\n        self.object_cache = LRUCache(maxsize=100)\n        self.bucket_cache = LRUCache(maxsize=10)'

code = re.sub(init_pattern, init_replacement, code, flags=re.DOTALL)

# 5. Заменяем метод list_objects на версию с кешированием
list_objects_old = '''    def list_objects(self, bucket_name, prefix=''):
        if self.s3_client is None:
            return [], []
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
            folders = []
            files = []
            for page in pages:
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
            return folders, files
        except (ClientError, Exception):
            return [], []'''

list_objects_new = '''    def list_objects(self, bucket_name, prefix='', use_cache=True):
        """Список объектов с поддержкой кеширования"""
        if self.s3_client is None:
            return [], []
        
        cache_key = f"{bucket_name}:{prefix}"
        
        if use_cache:
            cached = self.object_cache.get(cache_key)
            if cached is not None:
                return cached
        
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
            folders = []
            files = []
            for page in pages:
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
            
            result = (folders, files)
            if use_cache:
                self.object_cache.put(cache_key, result)
            
            return result
        except (ClientError, Exception):
            return [], []'''

code = code.replace(list_objects_old, list_objects_new)

# 6. Добавляем методы count_objects, list_objects_lazy и invalidate_cache
new_methods = '''
    def count_objects(self, bucket_name, prefix=''):
        """Быстрый подсчет количества объектов без загрузки данных
        
        Args:
            bucket_name: имя бакета
            prefix: префикс для фильтрации
            
        Returns:
            tuple: (total_objects, total_size) или (None, None) при ошибке
        """
        if self.s3_client is None:
            return None, None
        
        # Проверяем кеш
        cache_key = f"count:{bucket_name}:{prefix}"
        cached = self.object_cache.get(cache_key)
        if cached is not None:
            return cached
        
        try:
            total_objects = 0
            total_size = 0
            
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
            
            for page in pages:
                if 'Contents' in page:
                    total_objects += len(page['Contents'])
                    total_size += sum(obj.get('Size', 0) for obj in page['Contents'])
            
            result = (total_objects, total_size)
            self.object_cache.put(cache_key, result)
            return result
            
        except (ClientError, Exception):
            return None, None

    def list_objects_lazy(self, bucket_name, prefix='', page_size=1000):
        """Ленивая загрузка объектов с использованием генератора"""
        if self.s3_client is None:
            yield [], []
            return
        
        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(
                Bucket=bucket_name, 
                Prefix=prefix, 
                Delimiter='/',
                PaginationConfig={'PageSize': page_size}
            )
            
            for page in page_iterator:
                folders = []
                files = []
                
                if 'CommonPrefixes' in page:
                    for obj in page['CommonPrefixes']:
                        folders.append({'Key': obj['Prefix']})
                
                if 'Contents' in page:
                    for obj in page['Contents']:
                        if not obj['Key'].endswith('/') and obj['Key'] != prefix:
                            files.append(obj)
                
                yield folders, files
                
        except (ClientError, Exception):
            yield [], []
    
    def invalidate_cache(self, bucket_name=None, prefix=None):
        """Инвалидация кеша после операций изменения"""
        if bucket_name is None:
            self.object_cache.invalidate()
            self.bucket_cache.invalidate()
        else:
            pattern = f"{bucket_name}:"
            if prefix:
                pattern += prefix
            self.object_cache.invalidate(pattern)
'''

# Находим метод object_exists и вставляем новые методы перед ним
object_exists_pos = code.find('    def object_exists(self, bucket_name, key):')
if object_exists_pos != -1:
    code = code[:object_exists_pos] + new_methods + '\n' + code[object_exists_pos:]

print("✓ Добавлены методы count_objects, list_objects_lazy, invalidate_cache")

# 7. Модифицируем методы для инвалидации кеша
methods_to_update = [
    ('def upload_file(self, local_path, bucket_name, key):', 'bucket_name'),
    ('def delete_object(self, bucket_name, key, version_id=None):', 'bucket_name'),
    ('def copy_object(self, source_bucket, source_key, dest_bucket, dest_key, version_id=None):', 'dest_bucket')
]

for method_sig, bucket_param in methods_to_update:
    # Находим все return True в методе и добавляем инвалидацию перед ними
    method_start = code.find('    ' + method_sig)
    if method_start == -1:
        continue
    
    method_end = code.find('\n    def ', method_start + 1)
    if method_end == -1:
        method_end = len(code)
    
    method_block = code[method_start:method_end]
    
    # Добавляем инвалидацию перед return True
    modified_block = method_block.replace(
        '            return True',
        f'            self.invalidate_cache({bucket_param})\n            return True'
    )
    
    code = code[:method_start] + modified_block + code[method_end:]

print("✓ Добавлена автоматическая инвалидация кеша в методы изменения данных")
