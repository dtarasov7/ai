
# Читаем оригинальный файл
with open('s3-commander.py', 'r', encoding='utf-8') as f:
    code = f.read()

import re

# Сначала добавляем все изменения из предыдущей версии (кеширование)

# 1. Добавляем импорты для кеширования
import_addition = """import functools
from collections import OrderedDict
"""

last_import_pos = max([m.end() for m in re.finditer(r'^import .*$|^from .* import .*$', code, re.MULTILINE)])
code = code[:last_import_pos] + "\n" + import_addition + code[last_import_pos:]

# 2. Добавляем класс LRUCache
cache_class = '''
class LRUCache:
    """Простой LRU кеш для хранения результатов запросов к S3"""
    def __init__(self, maxsize=100):
        self.cache = OrderedDict()
        self.maxsize = maxsize
    
    def get(self, key):
        if key not in self.cache:
            return None
        self.cache.move_to_end(key)
        return self.cache[key]
    
    def put(self, key, value):
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        if len(self.cache) > self.maxsize:
            self.cache.popitem(last=False)
    
    def invalidate(self, pattern=None):
        """Инвалидация кеша по паттерну"""
        if pattern is None:
            self.cache.clear()
        else:
            keys_to_remove = [k for k in self.cache.keys() if pattern in k]
            for key in keys_to_remove:
                del self.cache[key]

'''

s3manager_start = code.find('class S3Manager:')
code = code[:s3manager_start] + cache_class + code[s3manager_start:]

# 3. Добавляем класс ScrollBar перед SelectableText
scrollbar_class = '''
class ScrollBar(urwid.WidgetDecoration):
    """Вертикальный scrollbar для urwid ListBox"""
    
    def __init__(self, widget):
        """
        Args:
            widget: базовый виджет (обычно ListBox)
        """
        self.__super.__init__(widget)
        self.scrollbar_width = 1
        
    def render(self, size, focus=False):
        maxcol, maxrow = size
        
        # Рендерим основной виджет
        canvas = self._original_widget.render((maxcol - self.scrollbar_width, maxrow), focus)
        
        # Получаем информацию о позиции скролла
        if hasattr(self._original_widget, 'body'):
            # Для ListBox
            middle, top, bottom = self._original_widget.calculate_visible(
                (maxcol - self.scrollbar_width, maxrow), focus
            )
            
            if middle is None:
                return canvas
            
            # Получаем общее количество элементов
            try:
                total_rows = len(self._original_widget.body)
            except:
                total_rows = maxrow
            
            if total_rows == 0:
                return canvas
            
            # Вычисляем параметры scrollbar
            visible_rows = maxrow
            
            if total_rows <= visible_rows:
                thumb_height = maxrow
                thumb_top = 0
            else:
                thumb_height = max(1, int(visible_rows * visible_rows / total_rows))
                
                try:
                    focus_position = self._original_widget.body.focus
                    if focus_position is None:
                        focus_position = 0
                except:
                    focus_position = 0
                
                scrollable_area = maxrow - thumb_height
                if total_rows > visible_rows:
                    scroll_ratio = focus_position / (total_rows - 1) if total_rows > 1 else 0
                    thumb_top = int(scroll_ratio * scrollable_area)
                else:
                    thumb_top = 0
            
            # Создаем scrollbar
            scrollbar_canvas = self._create_scrollbar(maxrow, thumb_top, thumb_height)
            
            # Комбинируем canvas
            combined = urwid.CanvasJoin([
                (canvas, None, False, maxcol - self.scrollbar_width),
                (scrollbar_canvas, None, False, self.scrollbar_width)
            ])
            
            return combined
        
        return canvas
    
    def _create_scrollbar(self, height, thumb_top, thumb_height):
        """Создать canvas для scrollbar"""
        rows = []
        for i in range(height):
            if thumb_top <= i < thumb_top + thumb_height:
                rows.append([('scrollbar_thumb', None, '█'.encode('utf-8'))])
            else:
                rows.append([('scrollbar_track', None, '│'.encode('utf-8'))])
        
        return urwid.TextCanvas(rows, maxcol=1)
    
    def selectable(self):
        return self._original_widget.selectable()
    
    def keypress(self, size, key):
        maxcol, maxrow = size
        return self._original_widget.keypress((maxcol - self.scrollbar_width, maxrow), key)
    
    def mouse_event(self, size, event, button, col, row, focus):
        maxcol, maxrow = size
        if col < maxcol - self.scrollbar_width:
            return self._original_widget.mouse_event(
                (maxcol - self.scrollbar_width, maxrow),
                event, button, col, row, focus
            )
        return False

'''

selectable_pos = code.find('class SelectableText(urwid.Text):')
if selectable_pos != -1:
    code = code[:selectable_pos] + scrollbar_class + code[selectable_pos:]

print("✓ Добавлен класс ScrollBar")
