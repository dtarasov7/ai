
# Читаем улучшенный файл
with open('s3-commander-enhanced.py', 'r', encoding='utf-8') as f:
    code = f.read()

import re

# 1. Добавляем метод count query в S3Manager
count_method = '''
    def count_objects(self, bucket_name, prefix=''):
        """Быстрый подсчет количества объектов без загрузки данных
        
        Args:
            bucket_name: имя бакета
            prefix: префикс для фильтрации
            
        Returns:
            tuple: (total_objects, total_size) или (None, None) при ошибке
        """
        if self.s3_client is None:
            return None, None
        
        # Проверяем кеш
        cache_key = f"count:{bucket_name}:{prefix}"
        cached = self.object_cache.get(cache_key)
        if cached is not None:
            return cached
        
        try:
            total_objects = 0
            total_size = 0
            
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
            
            for page in pages:
                if 'Contents' in page:
                    total_objects += len(page['Contents'])
                    total_size += sum(obj.get('Size', 0) for obj in page['Contents'])
            
            result = (total_objects, total_size)
            self.object_cache.put(cache_key, result)
            return result
            
        except (ClientError, Exception):
            return None, None
'''

# Находим метод list_objects_lazy и вставляем count_method перед ним
lazy_method_pos = code.find('    def list_objects_lazy(')
if lazy_method_pos != -1:
    code = code[:lazy_method_pos] + count_method + '\n' + code[lazy_method_pos:]

print("✓ Добавлен метод count_objects")

# 2. Создаем класс ScrollBar для urwid
scrollbar_class = '''
class ScrollBar(urwid.WidgetDecoration):
    """Вертикальный scrollbar для urwid ListBox"""
    
    def __init__(self, widget):
        """
        Args:
            widget: базовый виджет (обычно ListBox)
        """
        self.__super.__init__(widget)
        self.scrollbar_width = 1
        
    def render(self, size, focus=False):
        maxcol, maxrow = size
        
        # Рендерим основной виджет
        canvas = self._original_widget.render((maxcol - self.scrollbar_width, maxrow), focus)
        
        # Получаем информацию о позиции скролла
        if hasattr(self._original_widget, 'body'):
            # Для ListBox
            middle, top, bottom = self._original_widget.calculate_visible(
                (maxcol - self.scrollbar_width, maxrow), focus
            )
            
            if middle is None:
                # Нет элементов для отображения
                return canvas
            
            # Получаем общее количество элементов
            try:
                total_rows = len(self._original_widget.body)
            except:
                total_rows = maxrow
            
            if total_rows == 0:
                return canvas
            
            # Вычисляем параметры scrollbar
            visible_rows = maxrow
            
            if total_rows <= visible_rows:
                # Весь контент помещается на экране
                thumb_height = maxrow
                thumb_top = 0
            else:
                # Вычисляем размер ползунка
                thumb_height = max(1, int(visible_rows * visible_rows / total_rows))
                
                # Получаем текущую позицию фокуса
                try:
                    focus_position = self._original_widget.body.focus
                    if focus_position is None:
                        focus_position = 0
                except:
                    focus_position = 0
                
                # Вычисляем позицию ползунка
                scrollable_area = maxrow - thumb_height
                if total_rows > visible_rows:
                    scroll_ratio = focus_position / (total_rows - 1) if total_rows > 1 else 0
                    thumb_top = int(scroll_ratio * scrollable_area)
                else:
                    thumb_top = 0
            
            # Создаем scrollbar
            scrollbar_canvas = self._create_scrollbar(maxrow, thumb_top, thumb_height)
            
            # Комбинируем canvas основного виджета и scrollbar
            combined = urwid.CanvasJoin([
                (canvas, None, False, maxcol - self.scrollbar_width),
                (scrollbar_canvas, None, False, self.scrollbar_width)
            ])
            
            return combined
        
        return canvas
    
    def _create_scrollbar(self, height, thumb_top, thumb_height):
        """Создать canvas для scrollbar"""
        rows = []
        for i in range(height):
            if thumb_top <= i < thumb_top + thumb_height:
                # Ползунок
                rows.append([('scrollbar_thumb', None, '█'.encode('utf-8'))])
            else:
                # Трек
                rows.append([('scrollbar_track', None, '│'.encode('utf-8'))])
        
        return urwid.TextCanvas(rows, maxcol=1)
    
    def selectable(self):
        return self._original_widget.selectable()
    
    def keypress(self, size, key):
        maxcol, maxrow = size
        return self._original_widget.keypress((maxcol - self.scrollbar_width, maxrow), key)
    
    def mouse_event(self, size, event, button, col, row, focus):
        maxcol, maxrow = size
        if col < maxcol - self.scrollbar_width:
            return self._original_widget.mouse_event(
                (maxcol - self.scrollbar_width, maxrow),
                event, button, col, row, focus
            )
        return False
'''

# Находим класс SelectableText и вставляем ScrollBar перед ним
selectable_pos = code.find('class SelectableText(urwid.Text):')
if selectable_pos != -1:
    code = code[:selectable_pos] + scrollbar_class + '\n\n' + code[selectable_pos:]
    print("✓ Добавлен класс ScrollBar")

# 3. Модифицируем PanelWidget для использования ScrollBar
# Находим создание listbox в PanelWidget.__init__
panel_init_pattern = r'(class PanelWidget.*?def __init__.*?self\.listbox = urwid\.ListBox\(self\.walker\))'
match = re.search(panel_init_pattern, code, re.DOTALL)

if match:
    # Заменяем создание linebox на использование ScrollBar
    old_linebox = '''        self.linebox = urwid.LineBox(
            urwid.Frame(
                urwid.AttrMap(self.listbox, 'body'),
                header=path_widget
            )
        )'''
    
    new_linebox = '''        # Оборачиваем listbox в ScrollBar
        self.scrollbar = ScrollBar(self.listbox)
        
        self.linebox = urwid.LineBox(
            urwid.Frame(
                urwid.AttrMap(self.scrollbar, 'body'),
                header=path_widget
            )
        )'''
    
    code = code.replace(old_linebox, new_linebox)
    print("✓ PanelWidget обновлен для использования ScrollBar")

# 4. Добавляем отображение количества элементов в path_text
# Модифицируем метод _refresh_s3 для отображения счетчика

# Находим место обновления path_text в _refresh_s3 для списка объектов
old_path_update = '''            self.update_header(f'[S3 Mode - {self.current_endpoint}] Sort: {self.sort_mode}')
            self.path_text.set_text(f'S3: /{self.current_endpoint}/{self.current_bucket}/{self.current_prefix}')'''

new_path_update = '''            self.update_header(f'[S3 Mode - {self.current_endpoint}] Sort: {self.sort_mode}')
            
            # Получаем количество объектов
            total_count, total_size = self.s3_manager.count_objects(self.current_bucket, self.current_prefix)
            if total_count is not None:
                count_info = f' [{total_count} objects, {format_size(total_size)}]'
            else:
                count_info = ''
            
            self.path_text.set_text(f'S3: /{self.current_endpoint}/{self.current_bucket}/{self.current_prefix}{count_info}')'''

code = code.replace(old_path_update, new_path_update)
print("✓ Добавлено отображение количества объектов в path")

# 5. Добавляем цвета для scrollbar в палитру
# Находим определение палитры
palette_pattern = r"palette = \[(.*?)\]"
match = re.search(palette_pattern, code, re.DOTALL)

if match:
    # Добавляем цвета для scrollbar перед закрывающей скобкой
    old_palette_end = match.group(0)
    
    scrollbar_colors = """,
    ('scrollbar_track', 'dark gray', ''),
    ('scrollbar_thumb', 'light gray', 'dark blue')"""
    
    new_palette = old_palette_end[:-1] + scrollbar_colors + '\n]'
    code = code.replace(old_palette_end, new_palette)
    print("✓ Добавлены цвета для scrollbar в палитру")

# Сохраняем обновленный файл
with open('s3-commander-scrollbar.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("\n✓ Создан файл s3-commander-scrollbar.py")
print(f"✓ Размер: {len(code)} символов ({len(code.splitlines())} строк)")
