# Story: Initial README

## Goal
Создать понятный README проекта.

## Acceptance Criteria
- README объясняет, что делает проект
- README содержит инструкции по запуску
- README содержит базовую структуру репозитория

## Dependencies
- none
