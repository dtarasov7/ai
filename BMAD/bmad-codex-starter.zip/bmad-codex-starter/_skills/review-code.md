# Skill: review-code

## Goal
Провести review изменения.

## Checklist
- Выполнены ли acceptance criteria?
- Есть ли лишние изменения?
- Есть ли тесты на основные сценарии?
- Есть ли риск регрессии?
- Корректна ли обработка ошибок?
- Соответствует ли код conventions?

## Output Format
- Verdict: approve | request_changes
- Findings:
  - item 1
  - item 2
