# BMAD + Skills + Task Graph starter kit for VS Code + Codex (Windows 10)

Этот набор файлов превращает репозиторий в структурированную AI-среду разработки.

## Что внутри

- `_bmad/` — роли агентов, workflow и шаблоны
- `_skills/` — переиспользуемые инструкции для типовых операций
- `_tasks/` — stories и состояние проекта
- `_memory/` — долговременные правила и контекст проекта
- `_bmad-output/` — генерируемые артефакты (PRD, архитектура и т.д.)
- `src/`, `tests/` — обычный код проекта

## Рекомендуемый стартовый сценарий

1. Открой проект в VS Code.
2. Попроси Codex прочитать `_bmad/system.md`.
3. Сгенерируй PRD в `_bmad-output/prd.md`.
4. Затем архитектуру в `_bmad-output/architecture.md`.
5. Затем эпики и stories в `_tasks/`.
6. После этого проси Codex выбирать следующую story из `_tasks/state.json`, реализовывать её и обновлять статусы.

## Базовые prompts

### 1) Сгенерировать PRD

```text
Follow _bmad/system.md.
Act as the Analyst from _bmad/agents/analyst.md.
Use _bmad/templates/prd-template.md.

My product idea:
<опиши идею>

Create _bmad-output/prd.md.
```

### 2) Сгенерировать архитектуру

```text
Follow _bmad/system.md.
Act as the Architect from _bmad/agents/architect.md.
Read _bmad-output/prd.md.
Use _bmad/templates/architecture-template.md.
Create _bmad-output/architecture.md.
```

### 3) Разбить на stories и обновить state

```text
Follow _bmad/system.md.
Act as the PM from _bmad/agents/pm.md.
Read _bmad-output/prd.md and _bmad-output/architecture.md.
Create or update stories in _tasks/stories/.
Update _tasks/state.json.
```

### 4) Реализовать следующую story

```text
Follow _bmad/system.md.
Read _tasks/state.json.
Pick the highest-priority story with status "ready".
Use _skills/implement-story.md and _skills/write-tests.md.
Implement the story in src/ and tests/.
Update _tasks/state.json.
```

### 5) Провести review

```text
Follow _bmad/system.md.
Act as the Reviewer from _bmad/agents/reviewer.md.
Use _skills/review-code.md.
Review the last implemented story.
```

## Совет по режиму работы

Держи stories маленькими: 1 story = 1 проверяемое изменение.
