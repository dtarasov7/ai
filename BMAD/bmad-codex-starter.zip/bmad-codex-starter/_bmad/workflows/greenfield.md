# Greenfield Workflow

## Purpose
Workflow для нового проекта.

## Stages
1. Analyst создаёт PRD
2. Architect создаёт архитектуру
3. PM разбивает продукт на эпики и stories
4. Developer реализует stories по одной
5. Reviewer проверяет каждую существенную реализацию
6. Состояние проекта обновляется в `_tasks/state.json`

## Main Artifacts
- `_bmad-output/prd.md`
- `_bmad-output/architecture.md`
- `_tasks/stories/*.md`
- `_tasks/state.json`
