#!/usr/bin/env bash
set -euo pipefail

echo "== Git status =="
git status --short

echo
echo "== Revisions =="
printf 'baseline: '
git rev-parse --short audit-baseline 2>/dev/null || echo '<missing>'
printf 'HEAD:     '
git rev-parse --short HEAD 2>/dev/null || echo '<missing>'

echo
echo "== Diff stat baseline..HEAD =="
git diff --stat audit-baseline..HEAD 2>/dev/null || true

echo
echo "== Diff whitespace/errors =="
git diff --check || true

echo
echo "== Recent commits =="
git log --oneline --decorate -12 2>/dev/null || true
