#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 \"commit message\" [path ...]" >&2
  exit 2
fi

msg="$1"
shift

echo "== status =="
git status --short

echo
echo "== diff check =="
git diff --check

echo
echo "== diff stat =="
git diff --stat

read -r -p "Stage and commit these changes? [y/N] " ans
case "$ans" in
  y|Y|yes|YES) ;;
  *) echo "Cancelled."; exit 1 ;;
esac

if [[ $# -gt 0 ]]; then
  git add -- "$@"
else
  git add -A
fi

git diff --cached --check
git diff --cached --stat
read -r -p "Commit staged changes with message '$msg'? [y/N] " ans2
case "$ans2" in
  y|Y|yes|YES) git commit -m "$msg" ;;
  *) echo "Commit cancelled; changes remain staged."; exit 1 ;;
esac
