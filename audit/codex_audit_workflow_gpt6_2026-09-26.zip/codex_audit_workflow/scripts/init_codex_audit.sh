#!/usr/bin/env bash
set -euo pipefail

if [[ ! -e . ]]; then
  echo "Run this script from the project root." >&2
  exit 1
fi

# Refuse a few obvious dangerous locations.
ROOT="$(pwd -P)"
case "$ROOT" in
  /|/home|/root|/usr|/var|/etc|/opt)
    echo "Refusing to initialize audit repo in suspicious root: $ROOT" >&2
    exit 2
    ;;
esac

# Add conservative ignore entries only if missing. Review these for your project.
touch .gitignore
for entry in \
  '.env' '.env.*' '*.pem' '*.key' '*.p12' '*.pfx' \
  'secrets/' '.secrets/' '*.sqlite' '*.sqlite3' '*.db' \
  'node_modules/' '.venv/' 'venv/' '__pycache__/' '.DS_Store'; do
  if ! grep -Fxq "$entry" .gitignore; then
    printf '%s\n' "$entry" >> .gitignore
  fi
done

mkdir -p \
  .audit/security/raw \
  .audit/performance \
  .audit/features \
  .audit/final

if [[ ! -f .audit/INDEX.md ]]; then
cat > .audit/INDEX.md <<'EOT'
# Audit State

## Git
- Original baseline: TBD
- Current HEAD: TBD

## Security
- Attack surface: `.audit/01_attack_surface.md`
- Findings: `.audit/security/findings.jsonl`
- Summary: `.audit/security/summary.md`
- Remediation plan: `.audit/security/remediation.md`
- Status: not started

## Performance
- Findings: `.audit/performance/findings.jsonl`
- Benchmarks: `.audit/performance/benchmarks.md`
- Summary: `.audit/performance/summary.md`
- Status: not started

## Features
- Ideas: `.audit/features/ideas.md`
- Architecture: `.audit/features/architecture.md`
- Status: not started

## Final review
- Review: `.audit/final/review.md`
- Status: not started
EOT
fi

cat > .audit/00_scope.md <<'EOT'
# Audit Scope

Repository is reviewed as a defensive code-quality/security/performance exercise.

## Rules
- Git + `.audit/` are the persistent source of truth between Codex stages.
- Do not rely on conversational memory.
- Use stable finding IDs.
- Do not mix unrelated security, performance, and feature changes in one commit.
- Avoid committing secrets, private keys, database dumps, or generated dependency directories.
EOT

: > .audit/security/findings.jsonl
cat > .audit/security/summary.md <<'EOT'
# Security Summary

Status: not started.
EOT
cat > .audit/security/remediation.md <<'EOT'
# Security Remediation Plan

Status: not started.
EOT
: > .audit/performance/findings.jsonl
cat > .audit/performance/benchmarks.md <<'EOT'
# Performance Benchmarks

Status: not started.
EOT
cat > .audit/performance/summary.md <<'EOT'
# Performance Summary

Status: not started.
EOT
cat > .audit/features/ideas.md <<'EOT'
# Feature Ideas

Status: not started.
EOT
cat > .audit/features/architecture.md <<'EOT'
# Feature Architecture Notes

Status: not started.
EOT
cat > .audit/final/review.md <<'EOT'
# Final Review

Status: not started.
EOT

if [[ ! -d .git ]]; then
  git init
fi

# Fail fast if identity is not configured; local-only identity is acceptable.
if ! git config user.email >/dev/null || ! git config user.name >/dev/null; then
  echo "Git identity is not configured." >&2
  echo "Set it locally, for example:" >&2
  echo "  git config user.name 'Codex Audit'" >&2
  echo "  git config user.email 'codex-audit@local'" >&2
  exit 3
fi

if git rev-parse --verify HEAD >/dev/null 2>&1; then
  echo "Repository already has commits; not creating a new baseline commit." >&2
else
  echo
  echo "About to create the local baseline commit. Review staged candidates first:" >&2
  git status --short
  echo
  echo "If this output contains secrets/dumps/generated files, press Ctrl-C now and update .gitignore." >&2
  read -r -p "Create baseline commit from current project contents? [y/N] " ans
  case "$ans" in
    y|Y|yes|YES)
      git add .
      git commit -m "baseline: imported source before Codex audit"
      ;;
    *)
      echo "Baseline commit cancelled. .audit structure has been created." >&2
      exit 4
      ;;
  esac
fi

if ! git rev-parse -q --verify refs/tags/audit-baseline >/dev/null; then
  git tag audit-baseline
fi

BASE="$(git rev-parse audit-baseline)"
HEAD="$(git rev-parse HEAD)"
python3 - "$BASE" "$HEAD" <<'PY'
from pathlib import Path
import sys
p = Path('.audit/INDEX.md')
s = p.read_text()
s = s.replace('- Original baseline: TBD', f'- Original baseline: {sys.argv[1]}')
s = s.replace('- Current HEAD: TBD', f'- Current HEAD: {sys.argv[2]}')
p.write_text(s)
PY

# Commit the INDEX hash update separately if it changed after the baseline commit.
if ! git diff --quiet -- .audit/INDEX.md; then
  git add .audit/INDEX.md
  git commit -m "audit: record baseline metadata"
fi

echo
echo "Initialized Codex audit workflow."
echo "Baseline tag: audit-baseline -> $(git rev-parse --short audit-baseline)"
echo "Current HEAD: $(git rev-parse --short HEAD)"
echo "Next: use prompts/01_repo_attack_surface.md"
