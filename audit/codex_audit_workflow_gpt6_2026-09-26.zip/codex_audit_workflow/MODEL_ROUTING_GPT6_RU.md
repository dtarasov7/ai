# Маршрутизация GPT-6 для Codex audit workflow

Актуально на 26 сентября 2026.

## Семейство

- **GPT-6 Astra** — максимальная capability для hardest end-to-end work.
- **GPT-6 Sol** — demanding coding и agentic workflows; основной выбор для сложного анализа кода.
- **GPT-6 Luna** — focused/high-volume work; основной выбор для дешёвых повторяемых проходов.
- **GPT-6 Terra не существует** в текущей линейке GPT-6. Если старый prompt говорит Terra, в этом workflow заменяйте её на GPT-6 Luna либо GPT-6 Sol по сложности.

## Reasoning

- Astra: `low`, `medium`, `high`, `xhigh`, `max`.
- Sol: `none`, `low`, `medium`, `high`, `xhigh`, `max`.
- Luna: `none`, `low`, `medium`, `high`, `xhigh`, `max`.

`medium` — разумная стартовая точка для Sol/Luna. Повышайте effort только там, где дополнительный анализ меняет результат.

## Схема этапов

| Этап | Рекомендация |
|---|---|
| Repo/attack-surface mapping | GPT-6 Luna / medium |
| SAST tooling + triage | GPT-6 Luna / high |
| Semantic security review | GPT-6 Sol / high |
| Critical/High validation | GPT-6 Astra / low; medium для спорных случаев |
| Remediation plan | GPT-6 Sol / medium |
| Localized remediation | GPT-6 Luna / high |
| Auth/authorization/protocol/concurrency remediation | GPT-6 Sol / medium/high |
| Performance hypotheses | GPT-6 Sol / medium |
| Benchmark/profile + local optimization | GPT-6 Luna / high |
| Architectural optimization | GPT-6 Sol / medium/high |
| Feature opportunities | GPT-6 Sol / medium |
| Final audit | GPT-6 Sol / high; GPT-6 Astra / low/medium для критичных систем |

## Почему `.audit/` всё ещё нужен

GPT-6 Sol/Luna/Astra имеют большой контекст, но audit pipeline должен быть воспроизводимым независимо от конкретной сессии. Git + `.audit/INDEX.md` + JSONL findings дают стабильные ID, baseline, историю статусов и позволяют новой сессии читать только нужные артефакты.

## Пятичасовые лимиты

Не закладывайте фиксированный расход GPT-6 Sol/Luna в скрипты или planning: на дату этого файла OpenAI уже выпустила эти модели в Work/Codex, но публичная таблица estimated local messages per 5-hour window ещё не содержит отдельные строки для GPT-6 Sol/Luna. Проверяйте Settings → Usage и `/status` в Codex CLI.

## Если GPT-6 Sol/Luna ещё не видны в вашем Codex

Обновите Codex/VS Code integration до актуальной версии. Если rollout или workspace policy пока не даёт GPT-6 Sol/Luna, временный fallback:

- GPT-6 Luna → GPT-5.6 Luna для самых простых проходов либо GPT-5.6 Terra для более содержательных;
- GPT-6 Sol → GPT-5.6 Sol;
- GPT-6 Astra → GPT-6 Astra, если доступна.

Не меняйте структуру `.audit/` и Git workflow — только модель этапа.
