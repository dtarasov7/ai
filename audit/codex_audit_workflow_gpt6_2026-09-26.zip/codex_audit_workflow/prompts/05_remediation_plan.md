# Stage 5 — Security remediation plan
**Recommended:** GPT-6 Sol / medium
**After review, run:** `git add .audit && git commit -m "audit: define security remediation plan"`

## PROMPT
Create a remediation plan for the validated security findings. Do not change application source code yet.

Read:
- `.audit/INDEX.md`
- `.audit/security/summary.md`
- `.audit/security/findings.jsonl`

Use only findings that are `confirmed` (or explicitly accepted for remediation). Group fixes into small logical batches. Prefer batches that can be independently reviewed, tested and committed.

For every batch specify:
- included finding IDs;
- exact affected modules/symbols;
- intended security invariant after the fix;
- minimal implementation strategy;
- backwards-compatibility/API/data-migration concerns;
- tests needed to reproduce the old failure and verify the new behavior;
- rollout/config considerations;
- whether the batch is suitable for GPT-6 Luna/high or needs GPT-6 Sol/medium/high because it changes authorization, architecture, protocol, concurrency, or other subtle semantics.

Avoid unrelated refactoring. Prefer fixes that narrow trust boundaries and make security invariants explicit.

Write/update `.audit/security/remediation.md`. Set accepted findings to `fix_planned` and add a batch identifier where appropriate. Update `.audit/INDEX.md` with the ordered remediation batches.

Do not implement fixes and do not commit changes yourself.
