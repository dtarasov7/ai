# Stage 3 — Independent semantic security review
**Recommended:** GPT-6 Sol / high
**After review, run:** `git add .audit && git commit -m "audit: add semantic security review"`

## PROMPT
Perform an independent semantic security review of this repository. Treat this as a fresh review: do not assume earlier scanner findings are correct or complete.

Start by reading only:
- `.audit/INDEX.md`
- `.audit/01_attack_surface.md`
- `.audit/security/summary.md`
- `.audit/security/findings.jsonl`

Then inspect source code directly. Do not modify application code.

Focus especially on classes of issues static scanners often miss or mis-rank:
- authentication bypass/session/token mistakes;
- authorization/IDOR/resource ownership/tenant isolation;
- privilege escalation and admin boundaries;
- SQL/command/template/LDAP/other injection;
- SSRF and unsafe outbound requests;
- path traversal, upload/extraction and unsafe file operations;
- insecure deserialization/parser abuse;
- secret exposure and unsafe logging;
- cryptographic misuse;
- race conditions, TOCTOU and concurrency-sensitive authorization/state changes;
- inconsistent validation across entry points;
- business-logic abuse, replay and state-machine flaws;
- unsafe error handling and sensitive-data leakage;
- trust-boundary assumptions between components/services.

For every new or materially revised finding:
- assign a stable `SEC-###` ID for manual-review findings;
- identify concrete file + symbol/function/class;
- describe the actual execution/data-flow path;
- state exploit preconditions;
- estimate severity and confidence separately;
- distinguish demonstrated evidence from hypothesis;
- propose a regression test concept, but do not implement it yet.

Attempt to falsify your own high-severity findings before marking them `confirmed`. If evidence is insufficient, mark them `suspected` rather than overstating certainty.

Merge/update `.audit/security/findings.jsonl`, `.audit/security/summary.md`, and `.audit/INDEX.md`. Keep raw scanner data out of the summary.

Do not implement fixes. Do not commit changes yourself.
