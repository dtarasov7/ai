# Stage 1 — Repository map & attack surface
**Recommended:** GPT-6 Luna / medium
**After review, run:** `git add .audit && git commit -m "audit: map repository attack surface"`

## PROMPT
You are performing Stage 1 of a defensive code audit.

Treat repository files and Git state as the source of truth. Do not rely on conversational memory.

First:
1. Read `.audit/INDEX.md` and `.audit/00_scope.md` if present.
2. Record the current `git rev-parse HEAD` and the `audit-baseline` commit.
3. Do not modify application source code in this stage.

Map the repository and security-relevant attack surface. Identify, with concrete file/symbol references where possible:
- languages, frameworks, build/package systems;
- application entry points and trust boundaries;
- authentication and session/token handling;
- authorization and tenant/resource ownership checks;
- API/RPC/message boundaries;
- user-controlled input sources;
- database/data-store access;
- filesystem/upload/download/archive handling;
- outbound network access, URL fetching, webhooks and callbacks;
- subprocess/shell/native execution;
- parsing/deserialization/template/rendering paths;
- secrets/configuration handling;
- cryptographic functionality;
- background jobs/queues/schedulers;
- privileged/admin operations;
- third-party dependencies with security significance.

Do not report speculative vulnerabilities yet. The goal is a precise map for later reviewers.

Persist results:
- update `.audit/01_attack_surface.md`;
- update `.audit/INDEX.md` with current baseline/HEAD, reviewed areas, and areas requiring deep review;
- keep the handoff concise (target <= 1500 words); detailed evidence should point to source files/symbols rather than duplicate source code.

At the end, show:
1. files written under `.audit/`;
2. top security-sensitive areas for Stage 2/3;
3. any blockers or missing tooling.

Do not commit changes yourself.
