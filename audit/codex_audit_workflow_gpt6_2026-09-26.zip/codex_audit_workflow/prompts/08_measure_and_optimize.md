# Stage 8 — Measure, then optimize selected PERF findings
**Recommended:** GPT-6 Luna / high for benchmark/profile harness + localized changes; GPT-6 Sol / medium for architectural redesign
**After review, run:** `git add -A && git commit -m "performance: optimize <PERF-IDs>"`

## PROMPT
Work only on these performance findings: `<PERF-IDS>`.

Read `.audit/INDEX.md`, the matching records in `.audit/performance/findings.jsonl`, and affected source/tests.

Follow this order strictly:
1. Build or identify a reproducible measurement/benchmark/profile for each selected hypothesis.
2. Measure the current behavior before optimizing.
3. If the hypothesis is not supported by evidence, mark it `rejected` or `not_significant` and do not change production code for it.
4. If confirmed, implement the smallest clear optimization that preserves semantics and security invariants.
5. Re-run the same measurement and relevant tests.
6. Record before/after results, environment/parameters, and uncertainty.

Do not trade correctness/security for speed. Do not combine unrelated cleanup or feature work with optimization.

Update `.audit/performance/findings.jsonl`, `.audit/performance/benchmarks.md`, `.audit/performance/summary.md`, and `.audit/INDEX.md`.

For confirmed and improved findings, record:
- measurement before;
- measurement after;
- relative/absolute improvement where meaningful;
- test coverage and residual risks.

At the end show the diff summary and exact commands/results used for measurement/testing.

Do not commit changes yourself.
