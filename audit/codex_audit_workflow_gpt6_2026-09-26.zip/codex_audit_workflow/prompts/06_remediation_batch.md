# Stage 6 — Implement ONE remediation batch
**Recommended:** GPT-6 Luna / high for localized fixes; GPT-6 Sol / medium or high for auth/authorization/architecture/concurrency/protocol changes
**After review, run:** `git add -A && git commit -m "security: remediate <SEC-IDs>"`

## PROMPT
Implement exactly one remediation batch: `<BATCH-ID OR SEC-IDS>`.

Treat the repository and `.audit/` as source of truth. Read:
- `.audit/INDEX.md`
- `.audit/security/remediation.md`
- only the relevant records from `.audit/security/findings.jsonl`
- the affected source/tests.

Before changing code, verify each finding against the current HEAD. If the code has diverged enough that the planned fix is no longer appropriate, stop that finding, record the mismatch in `.audit/`, and continue only with findings that remain valid.

Constraints:
- no unrelated refactoring, formatting sweeps, dependency upgrades, or feature work;
- preserve public behavior unless the security fix intentionally requires a documented behavior change;
- add regression tests that would fail on the vulnerable behavior and pass with the fix;
- add boundary/negative tests where they materially improve confidence;
- run the smallest relevant test set first, then the broader available test suite/checks where practical;
- do not hide failing tests; distinguish pre-existing failures from regressions caused by this batch.

For each remediated finding update `.audit/security/findings.jsonl`:
- status → `retest_required` (not `verified` yet);
- note files/tests changed;
- record current pre-commit HEAD as the working base; the Git commit hash will be filled/verified in a later review if necessary.

Update `.audit/security/summary.md` and `.audit/INDEX.md`.

At the end show:
1. concise diff summary;
2. tests/checks run and results;
3. remaining risks/assumptions;
4. exact finding IDs handled.

Do not commit changes yourself.
