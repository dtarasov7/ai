# Stage 9 — Feature opportunities
**Recommended:** GPT-6 Sol / medium
**After review, run:** `git add .audit && git commit -m "audit: propose feature opportunities"`

## PROMPT
Analyze the current product/codebase and propose additional functionality. This stage is planning only: do not implement features.

Read `.audit/INDEX.md` for orientation, then inspect the current architecture/source as needed. Avoid assuming that prior security/performance findings imply product requirements.

Propose a concise set of opportunities grouped into:
- Quick wins;
- Medium-effort improvements;
- Strategic features;
- Developer/operational experience improvements.

For each proposal assign `FEAT-###` and evaluate:
- user/operator value;
- implementation effort;
- architectural impact;
- security/privacy impact;
- performance/operational impact;
- maintenance cost;
- prerequisites/dependencies;
- suggested MVP scope;
- why this codebase specifically makes the feature relevant.

Prioritize a Top 5 using value vs effort/risk. Avoid generic feature brainstorming disconnected from the repository.

Write/update:
- `.audit/features/ideas.md`
- `.audit/features/architecture.md` only for the Top 5 when architectural notes are useful
- `.audit/INDEX.md`

Do not implement code and do not commit changes yourself.
