# Stage 4 — Independent validation of Critical/High findings
**Recommended:** GPT-6 Astra / low; use medium only for genuinely difficult/ambiguous cases
**After review, run:** `git add .audit && git commit -m "audit: validate high-risk security findings"`

## PROMPT
Act as an independent skeptical security reviewer.

Do not rely on prior conversation. Read `.audit/INDEX.md` and load from `.audit/security/findings.jsonl` only findings currently marked Critical/High or explicitly listed as needing independent validation. Then inspect the relevant source files directly.

Your job is not to agree with the prior reviewer. For each selected finding, actively try to disprove it before accepting it.

For each finding determine one of:
- `confirmed`
- `rejected`
- `downgraded`
- `upgraded`
- `needs_more_evidence`

Check:
- whether source-to-sink/data/control flow is actually reachable;
- authentication/authorization preconditions;
- existing validation/sanitization/encoding/allow-listing;
- framework protections that materially change exploitability;
- deployment/config assumptions encoded in the repository;
- alternate paths that make the issue better or worse;
- whether the proposed severity matches realistic impact.

Update each reviewed record with concise validation evidence and reviewer disposition. If you discover a more fundamental adjacent vulnerability, create a new `SEC-###` record rather than silently changing the meaning of an existing ID.

Update `.audit/security/summary.md` and `.audit/INDEX.md` so the next stage sees the validated set.

Do not modify application code. Do not commit changes yourself.
