# Stage 7 — Performance review / hypotheses
**Recommended:** GPT-6 Sol / medium; use high for complex concurrency/data-path analysis
**After review, run:** `git add .audit && git commit -m "audit: identify performance hypotheses"`

## PROMPT
Perform a performance review as a separate concern from the security audit. Do not modify application source code in this stage.

Read `.audit/INDEX.md` for project orientation, but do not let prior security discussion bias performance conclusions. Inspect the current source tree and relevant tests/config directly.

Look for plausible high-impact bottlenecks in:
- algorithmic complexity;
- N+1 or excessive database queries;
- missing batching/pagination/streaming;
- repeated serialization/deserialization/copying;
- unnecessary allocations or large object retention;
- synchronous/blocking I/O on hot paths;
- excessive network round trips;
- lock contention/concurrency bottlenecks;
- cache opportunities and cache invalidation costs;
- startup/build/runtime hot paths;
- repeated expensive computation;
- unbounded queues/buffers/result sets.

Do not recommend micro-optimizations merely because code looks improvable. Every meaningful finding should include a way to measure or falsify it.

Assign stable IDs `PERF-###` and write `.audit/performance/findings.jsonl`. Fields should include:
`id`, `status` (`hypothesis` initially), `impact`, `confidence`, `file`, `symbol`, `hypothesis`, `measurement_plan`, `expected_signal`, `risk_of_change`.

Write `.audit/performance/summary.md` with the prioritized hypotheses and update `.audit/INDEX.md`.

Do not implement optimizations. Do not commit changes yourself.
