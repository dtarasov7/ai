# Stage 2 — SAST/dependency tooling & triage
**Recommended:** GPT-6 Luna / high
**After review, run:** `git add .audit && git commit -m "audit: collect and triage SAST findings"`

## PROMPT
You are performing Stage 2 of a defensive code audit.

Do not rely on previous conversation. Read `.audit/INDEX.md` and `.audit/01_attack_surface.md` first. Do not modify application source code.

Determine which static-analysis and dependency/security tools are appropriate for the detected languages/frameworks and which are already available in the environment. Prefer established project-native tooling and scanners. Run applicable tools when practical. Do not install or execute untrusted project artifacts beyond what is reasonably necessary for static analysis; note anything you intentionally skip.

Examples may include Semgrep, CodeQL, Bandit, gosec, cargo-audit, npm/pnpm/yarn audit, pip-audit, language linters/security rules, compiler warnings, secret scanners, and dependency vulnerability scanners, but choose based on this repository rather than blindly running everything.

For scanner output:
- store raw or minimally transformed machine-readable output under `.audit/security/raw/` where practical;
- normalize meaningful findings into `.audit/security/findings.jsonl`;
- deduplicate overlapping scanner findings;
- classify obvious false positives, but preserve evidence;
- assign stable IDs (`SAST-001`, `SAST-002`, ...).

Each normalized finding should include, when known:
`id`, `source`, `status`, `severity`, `confidence`, `cwe`, `file`, `symbol`, `baseline_commit`, `current_commit`, `evidence`, `source_to_sink`, `exploit_preconditions`, `false_positive_reason`, `recommended_test`.

Use concise evidence; do not paste large source files or entire scanner reports into summaries.

Update:
- `.audit/security/findings.jsonl`
- `.audit/security/summary.md`
- `.audit/INDEX.md`

In the summary, separate: Critical / High / Medium / Low / rejected-or-obvious-false-positive / tooling gaps.

Do not implement fixes and do not commit changes yourself.
