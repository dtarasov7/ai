# Stage 10 — Final adversarial audit
**Recommended:** GPT-6 Sol / high; for especially critical systems use GPT-6 Astra / low or medium as an independent final reviewer
**After review, run:** `git add .audit && git commit -m "audit: complete final adversarial review" && git tag audit-final`

## PROMPT
Perform a final adversarial review of the current repository as if it were about to be deployed.

Do not rely on conversational memory. Use Git and `.audit/` as source of truth.

Start with:
- `git status --short`
- `git rev-parse audit-baseline`
- `git rev-parse HEAD`
- `git diff --stat audit-baseline..HEAD`
- `git diff audit-baseline..HEAD`
- `.audit/INDEX.md`
- relevant security/performance findings and remediation records.

Review the complete change set since `audit-baseline`, with emphasis on unintended consequences rather than stylistic preferences.

Check for:
- unresolved or incorrectly marked security findings;
- security regressions introduced by remediation/performance changes;
- authentication/authorization and tenant-boundary regressions;
- functional behavior regressions;
- accidental API/schema/config changes;
- error-handling/sensitive-data exposure;
- race/concurrency/state-transition problems;
- incomplete migrations/backwards compatibility issues;
- performance regressions caused by fixes;
- missing or weak regression tests;
- dead code/temporary debug code/secrets/artifacts accidentally introduced;
- discrepancy between `.audit/` status and actual source/tests.

For findings marked `retest_required`, independently verify the current code and tests. Mark `verified` only when evidence supports it; otherwise reopen the finding with a clear reason.

Run relevant tests/checks where practical. Do not make production-code changes during this stage unless explicitly asked; this is a review stage.

Write `.audit/final/review.md` containing:
- reviewed baseline and HEAD;
- release-blocking issues;
- non-blocking issues;
- verified security fixes;
- unresolved risks/assumptions;
- tests/checks run;
- release recommendation: `GO`, `GO_WITH_CONDITIONS`, or `NO_GO`, with concise rationale.

Update `.audit/INDEX.md` to reflect final status.

Do not commit changes yourself.
