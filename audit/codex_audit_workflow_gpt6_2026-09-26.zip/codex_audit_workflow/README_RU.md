# Codex Audit Workflow: SAST → remediation → performance → features → final audit

Этот набор рассчитан на сценарий, где исходный проект копируется на remote server **без `.git`**, после чего вы работаете с Codex из VS Code Remote SSH.

Главный принцип: **не использовать историю чата как долговременную память**. Состояние пайплайна хранится в локальном Git и в `.audit/`.

## 0. Однократная подготовка

Из корня скопированного проекта запустите:

```bash
/path/to/unpacked/codex-audit-workflow/scripts/init_codex_audit.sh
```

Скрипт:
- проверит/создаст `.gitignore` записи для типичных секретов;
- выполнит `git init`, если репозитория ещё нет;
- создаст структуру `.audit/`;
- создаст baseline commit;
- поставит тег `audit-baseline`.

**Важно:** перед первым commit вручную убедитесь, что в рабочем каталоге нет секретов, приватных ключей, дампов БД и других файлов, которые не должны попадать даже в локальную Git object database.

Если хотите сделать всё вручную:

```bash
git init
git add .
git commit -m "baseline: imported source before Codex audit"
git tag audit-baseline
```

## Общие правила для всех этапов

1. Каждый серьёзный этап лучше запускать в **новой Codex-сессии**.
2. В начале каждого prompt Codex получает указание читать `.audit/INDEX.md`, а не полагаться на предыдущий диалог.
3. `.audit/` находится под Git и является частью audit trail.
4. Findings имеют стабильные ID (`SEC-*`, `PERF-*`, `FEAT-*`).
5. Не использовать номера строк как основной идентификатор; хранить `file + symbol + baseline/current commit`.
6. После каждого этапа сначала посмотреть `git diff`, затем выполнить указанную Git-команду.
7. Один логический набор изменений — один commit. Не смешивать security remediation, performance и feature implementation.

## Рекомендуемая последовательность

| # | Файл prompt | Модель / reasoning | Цель | Git после этапа |
|---|---|---|---|---|
| 1 | `prompts/01_repo_attack_surface.md` | **GPT-6 Luna / medium** | Карта repo и attack surface | `git add .audit && git commit -m "audit: map repository attack surface"` |
| 2 | `prompts/02_sast_tooling_triage.md` | **GPT-6 Luna / high** | Запуск SAST/dependency tooling и triage | `git add .audit && git commit -m "audit: collect and triage SAST findings"` |
| 3 | `prompts/03_semantic_security_review.md` | **GPT-6 Sol / high** | Независимый semantic security review | `git add .audit && git commit -m "audit: add semantic security review"` |
| 4 | `prompts/04_validate_high_risk_findings.md` | **GPT-6 Astra / low** (при сложных/спорных findings → medium) | Независимая проверка Critical/High | `git add .audit && git commit -m "audit: validate high-risk security findings"` |
| 5 | `prompts/05_remediation_plan.md` | **GPT-6 Sol / medium** | План исправлений и batching | `git add .audit && git commit -m "audit: define security remediation plan"` |
| 6 | `prompts/06_remediation_batch.md` | **GPT-6 Luna / high** для локальных fixes; **GPT-6 Sol / medium/high** для auth/architecture | Исправление одного batch + regression tests | `git add -A && git commit -m "security: remediate <SEC-IDs>"` |
| 7 | `prompts/07_performance_review.md` | **GPT-6 Sol / medium** (сложный concurrency/data path → high) | Performance hypotheses без premature optimization | `git add .audit && git commit -m "audit: identify performance hypotheses"` |
| 8 | `prompts/08_measure_and_optimize.md` | **GPT-6 Luna / high** для measurement; при сложном redesign → **GPT-6 Sol / medium** | Benchmark/profile → точечная оптимизация | `git add -A && git commit -m "performance: optimize <PERF-IDs>"` |
| 9 | `prompts/09_feature_opportunities.md` | **GPT-6 Sol / medium** | Дополнительный функционал и приоритизация | `git add .audit && git commit -m "audit: propose feature opportunities"` |
| 10 | `prompts/10_final_adversarial_audit.md` | **GPT-6 Sol / high**; для особо критичного проекта **GPT-6 Astra / low/medium** | Финальный adversarial review `audit-baseline..HEAD` | `git add .audit && git commit -m "audit: complete final adversarial review" && git tag audit-final` |

### Актуальная маршрутизация моделей GPT-6 (26 сентября 2026)

В Codex доступны GPT-6 Astra, GPT-6 Sol и GPT-6 Luna. Отдельной GPT-6 Terra сейчас нет. Для этого workflow используйте:

- **GPT-6 Luna** — inventory, запуск/разбор SAST, benchmark harness, локальные механические fixes и другие хорошо ограниченные задачи;
- **GPT-6 Sol** — semantic security review, remediation design, сложные auth/authorization/concurrency изменения, performance reasoning и feature architecture;
- **GPT-6 Astra** — независимая проверка наиболее критичных/неоднозначных findings и финальный review особо критичных систем.

GPT-6 Sol и Luna поддерживают `none/low/medium/high/xhigh/max`; GPT-6 Astra — `low/medium/high/xhigh/max`. У всех трёх контекст до 1.05M токенов, но `.audit/` остаётся основной долговременной памятью workflow: большой контекст не заменяет воспроизводимый audit trail, Git baseline и выборочную загрузку findings.

Важно: на дату обновления публичная таблица пятичасовых лимитов Work/Codex уже подтверждает GPT-6 Astra, но ещё не публикует отдельные численные диапазоны для GPT-6 Sol/Luna. Поэтому этот набор **не предполагает вымышленные коэффициенты расхода** для новых моделей; маршрутизация основана на их официальном назначении и относительной сложности этапов.

## Как пользоваться prompt-файлами

Откройте нужный файл, скопируйте **только текст внутри блока `PROMPT`** в новую Codex-сессию. Если этап работает с конкретными IDs, замените placeholders вроде `<SEC-004, SEC-007>`.

Перед commit рекомендуется:

```bash
git status --short
git diff --check
git diff
```

Если изменения выглядят правильно — выполняйте команду из таблицы.

## Remediation: запускать повторно

`06_remediation_batch.md` — шаблон, который нужно запускать **несколько раз**, по одному небольшому batch. Например:

```text
Batch A: SEC-004, SEC-007
Batch B: SEC-011
Batch C: SEC-014, SEC-015
```

После каждого batch — отдельный commit.

## Полезные Git-команды

Сравнить текущий проект с исходным baseline:

```bash
git diff audit-baseline..HEAD
```

Показать историю audit/remediation:

```bash
git log --oneline --decorate --graph --all
```

Посмотреть исходную версию файла:

```bash
git show audit-baseline:path/to/file
```

Откатить незакоммиченные изменения конкретного файла:

```bash
git restore path/to/file
```

Откатить все незакоммиченные tracked-изменения (осторожно):

```bash
git restore .
```

## Структура `.audit/`

```text
.audit/
├── INDEX.md
├── 00_scope.md
├── 01_attack_surface.md
├── security/
│   ├── findings.jsonl
│   ├── summary.md
│   ├── remediation.md
│   └── raw/
├── performance/
│   ├── findings.jsonl
│   ├── benchmarks.md
│   └── summary.md
├── features/
│   ├── ideas.md
│   └── architecture.md
└── final/
    └── review.md
```

## Почему JSONL для findings

Каждый finding — одна запись. Это позволяет следующему этапу загрузить только нужные IDs, не читая весь raw output. Пример:

```json
{"id":"SEC-007","status":"confirmed","severity":"high","confidence":"high","file":"src/services/fetcher.ts","symbol":"fetchRemoteDocument","source":"manual-review","baseline_commit":"<hash>","evidence":"User-controlled URL can reach the outbound HTTP client without network destination validation.","recommended_test":"Reject loopback/link-local/private destinations after DNS resolution."}
```

Рекомендуемые статусы:

```text
suspected → confirmed → fix_planned → fixed → retest_required → verified
           ↘ rejected
```

## Raw SAST outputs

Raw scanner output сохраняется в `.audit/security/raw/`, но последующие модели не должны читать его целиком без необходимости. Основная передача состояния идёт через `findings.jsonl`, `summary.md` и `INDEX.md`.

## Скрипты

- `scripts/init_codex_audit.sh` — первичная инициализация Git + `.audit/` + baseline.
- `scripts/check_audit_state.sh` — быстрый status/HEAD/baseline/diff check.
- `scripts/commit_audit_stage.sh` — вспомогательный commit с предварительной проверкой diff (использование: `./scripts/commit_audit_stage.sh "audit: ..."`).

