
# Модуль 2 - Mindmap
module02_mindmap = """@startmindmap
* MCP-протокол
** Transport Layer
*** STDIO
**** Локальные процессы
**** stdin/stdout
**** Без аутентификации
**** Desktop приложения
*** HTTP/SSE
**** Удаленный доступ
**** POST запросы
**** SSE для событий
**** Bearer tokens
**** Масштабируемость
left side
** Message Types
*** Request
**** id (обязательно)
**** method
**** params
**** Ждет Response
*** Response
**** id (из request)
**** result ИЛИ error
**** Успех/ошибка
*** Error
**** code (стандартные коды)
**** message
**** data (опционально)
*** Notification
**** Без id
**** Fire-and-forget
**** Асинхронные события
** Методы протокола
*** initialize
*** tools/list, tools/call
*** resources/list, resources/read
*** prompts/list, prompts/get
*** sampling/createMessage
*** ping
** Notifications
*** progress
**** progressToken
**** progress/total
*** message (логи)
**** level, data, logger
*** resources/updated
*** tools/list_changed
*** prompts/list_changed
** Error Codes
*** -32700 Parse error
*** -32600 Invalid Request
*** -32601 Method not found
*** -32602 Invalid params
*** -32603 Internal error
*** -32000..-32099 Server errors
@endmindmap
"""

with open("mcp-java-course/lectures/module-02-protocol/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module02_mindmap)

print("✓ Файл создан: module-02-protocol/mindmap.puml")
