
# Модуль 3 - Лекция
module03_lecture = """# Модуль 3: MCP SDK на Java

## Цели модуля

После изучения этого модуля вы:
- Познакомитесь с официальной Java SDK для MCP
- Научитесь создавать и настраивать MCP-клиенты
- Научитесь создавать и настраивать MCP-серверы
- Узнаете о best practices и patterns

---

## Обзор MCP Java SDK

### Официальная библиотека

MCP Java SDK — это официальная библиотека для работы с Model Context Protocol в Java-приложениях.

**GitHub**: https://github.com/modelcontextprotocol/java-sdk

### Maven зависимость

```xml
<dependency>
    <groupId>io.modelcontextprotocol</groupId>
    <artifactId>mcp-sdk</artifactId>
    <version>0.5.0</version>
</dependency>
```

### Gradle зависимость

```gradle
implementation 'io.modelcontextprotocol:mcp-sdk:0.5.0'
```

### Основные компоненты SDK

1. **Transport** — транспортный уровень (STDIO, HTTP)
2. **Session** — управление сессией соединения
3. **Server** — построение MCP-серверов
4. **Client** — построение MCP-клиентов
5. **Schema** — типы данных протокола

### Архитектура SDK

```
┌─────────────────────────────────────────┐
│         Application Layer               │
│  (Your Business Logic)                  │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         MCP SDK Layer                   │
│  • McpServer / McpClient                │
│  • Session Management                   │
│  • Request/Response Handling            │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         Transport Layer                 │
│  • StdioTransport                       │
│  • HttpTransport                        │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│         Network / I/O                   │
│  • stdin/stdout                         │
│  • HTTP connections                     │
└─────────────────────────────────────────┘
```

---

## Реализация MCP-клиента

### Базовый клиент

Создадим простой MCP-клиент, который подключается к серверу и вызывает инструменты.

```java
package com.example.mcp.client;

import io.modelcontextprotocol.sdk.client.McpClient;
import io.modelcontextprotocol.sdk.client.StdioClientTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.util.List;
import java.util.Map;

/**
 * Базовый MCP-клиент для подключения к серверу через STDIO.
 * 
 * Этот клиент демонстрирует:
 * - Установку соединения
 * - Согласование capabilities
 * - Вызов инструментов
 */
public class BasicMcpClient {
    
    private final McpClient client;
    
    /**
     * Конструктор создает клиента с STDIO транспортом.
     * 
     * @param serverCommand команда для запуска сервера
     * @param serverArgs аргументы командной строки для сервера
     */
    public BasicMcpClient(String serverCommand, List<String> serverArgs) {
        // Создаем STDIO транспорт, который запустит сервер как дочерний процесс
        StdioClientTransport transport = StdioClientTransport.builder()
            .command(serverCommand)
            .args(serverArgs)
            .build();
        
        // Создаем клиента с указанием наших capabilities
        this.client = McpClient.builder()
            .transport(transport)
            // Информация о нашем клиенте
            .clientInfo(Implementation.builder()
                .name("basic-mcp-client")
                .version("1.0.0")
                .build())
            // Наши возможности
            .capabilities(ClientCapabilities.builder()
                // Можем предоставлять корневые директории
                .roots(RootsCapability.builder()
                    .listChanged(true)
                    .build())
                .build())
            .build();
    }
    
    /**
     * Подключение к серверу и инициализация.
     * 
     * @throws Exception если подключение не удалось
     */
    public void connect() throws Exception {
        // Устанавливаем соединение и выполняем handshake
        InitializeResult result = client.initialize();
        
        System.out.println("Подключено к серверу:");
        System.out.println("  Имя: " + result.serverInfo().name());
        System.out.println("  Версия: " + result.serverInfo().version());
        
        // Выводим capabilities сервера
        ServerCapabilities caps = result.capabilities();
        System.out.println("\\nВозможности сервера:");
        
        if (caps.tools() != null) {
            System.out.println("  ✓ Tools (инструменты)");
        }
        if (caps.resources() != null) {
            System.out.println("  ✓ Resources (ресурсы)");
        }
        if (caps.prompts() != null) {
            System.out.println("  ✓ Prompts (шаблоны)");
        }
        if (caps.logging() != null) {
            System.out.println("  ✓ Logging (логирование)");
        }
    }
    
    /**
     * Получение списка доступных инструментов.
     * 
     * @return список инструментов
     * @throws Exception если запрос не удался
     */
    public List<Tool> listTools() throws Exception {
        ListToolsResult result = client.listTools();
        
        System.out.println("\\nДоступные инструменты:");
        for (Tool tool : result.tools()) {
            System.out.println("  • " + tool.name() + " - " + tool.description());
        }
        
        return result.tools();
    }
    
    /**
     * Вызов инструмента с параметрами.
     * 
     * @param toolName имя инструмента
     * @param arguments параметры инструмента
     * @return результат выполнения
     * @throws Exception если вызов не удался
     */
    public String callTool(String toolName, Map<String, Object> arguments) 
            throws Exception {
        
        System.out.println("\\nВызываем инструмент: " + toolName);
        System.out.println("Параметры: " + arguments);
        
        // Вызываем инструмент
        CallToolResult result = client.callTool(toolName, arguments);
        
        // Проверяем на ошибки
        if (result.isError() != null && result.isError()) {
            throw new RuntimeException("Tool execution failed");
        }
        
        // Извлекаем текстовый результат
        if (result.content() != null && !result.content().isEmpty()) {
            Content content = result.content().get(0);
            if (content instanceof TextContent textContent) {
                String text = textContent.text();
                System.out.println("Результат: " + text);
                return text;
            }
        }
        
        return "";
    }
    
    /**
     * Закрытие соединения.
     */
    public void disconnect() {
        if (client != null) {
            client.close();
            System.out.println("\\nСоединение закрыто");
        }
    }
    
    /**
     * Пример использования клиента.
     */
    public static void main(String[] args) {
        // Создаем клиента для подключения к Java MCP-серверу
        BasicMcpClient client = new BasicMcpClient(
            "java",
            List.of("-jar", "path/to/mcp-server.jar")
        );
        
        try {
            // Подключаемся
            client.connect();
            
            // Получаем список инструментов
            List<Tool> tools = client.listTools();
            
            // Вызываем первый доступный инструмент
            if (!tools.isEmpty()) {
                Tool firstTool = tools.get(0);
                Map<String, Object> args = Map.of(
                    "param1", "value1"
                );
                
                String result = client.callTool(firstTool.name(), args);
                System.out.println("\\nФинальный результат:\\n" + result);
            }
            
        } catch (Exception e) {
            System.err.println("Ошибка: " + e.getMessage());
            e.printStackTrace();
            
        } finally {
            // Всегда закрываем соединение
            client.disconnect();
        }
    }
}
```

### Клиент с обработкой уведомлений

```java
package com.example.mcp.client;

import io.modelcontextprotocol.sdk.client.McpClient;

/**
 * MCP-клиент с обработчиками уведомлений от сервера.
 */
public class NotificationAwareClient {
    
    private final McpClient client;
    
    public NotificationAwareClient(McpClient client) {
        this.client = client;
        setupNotificationHandlers();
    }
    
    /**
     * Настройка обработчиков для всех типов уведомлений.
     */
    private void setupNotificationHandlers() {
        
        // Обработчик прогресса
        client.setProgressHandler((token, progress, total) -> {
            double percentage = (progress * 100.0) / total;
            System.out.printf(
                "[PROGRESS] %s: %.1f%% (%d/%d)\\n",
                token, percentage, progress, total
            );
            
            // Можно обновить UI прогресс-бар
            updateProgressUI(token, percentage);
        });
        
        // Обработчик логов
        client.setLogHandler((level, message, logger) -> {
            String prefix = switch (level) {
                case "error", "critical" -> "❌";
                case "warning" -> "⚠️";
                case "info" -> "ℹ️";
                case "debug" -> "🔍";
                default -> "📝";
            };
            
            System.out.printf(
                "%s [%s] %s: %s\\n",
                prefix, level.toUpperCase(), logger, message
            );
        });
        
        // Обработчик изменения ресурсов
        client.setResourceUpdatedHandler(uri -> {
            System.out.println("♻️ Ресурс обновлен: " + uri);
            
            // Автоматически перечитываем ресурс
            try {
                ReadResourceResult result = client.readResource(uri);
                handleUpdatedResource(uri, result);
            } catch (Exception e) {
                System.err.println("Ошибка чтения обновленного ресурса: " + e);
            }
        });
        
        // Обработчик изменения списка инструментов
        client.setToolsChangedHandler(() -> {
            System.out.println("🔄 Список инструментов изменен");
            
            // Обновляем кеш инструментов
            try {
                List<Tool> tools = client.listTools();
                updateToolsCache(tools);
            } catch (Exception e) {
                System.err.println("Ошибка обновления tools: " + e);
            }
        });
        
        System.out.println("✅ Notification handlers настроены");
    }
    
    // Заглушки для обработчиков
    private void updateProgressUI(String token, double percentage) {
        // Реализация обновления UI
    }
    
    private void handleUpdatedResource(String uri, ReadResourceResult result) {
        // Обработка обновленного ресурса
    }
    
    private void updateToolsCache(List<Tool> tools) {
        // Обновление кеша
    }
}
```

### HTTP клиент

```java
package com.example.mcp.client;

import io.modelcontextprotocol.sdk.client.McpClient;
import io.modelcontextprotocol.sdk.client.HttpClientTransport;

/**
 * MCP-клиент для подключения к удаленному серверу через HTTP.
 */
public class HttpMcpClient {
    
    /**
     * Создание HTTP клиента с аутентификацией.
     */
    public static McpClient createHttpClient(
            String endpoint,
            String apiKey) {
        
        // Настраиваем HTTP транспорт
        HttpClientTransport transport = HttpClientTransport.builder()
            .endpoint(endpoint)
            // Добавляем аутентификацию
            .header("Authorization", "Bearer " + apiKey)
            // Настраиваем SSE для уведомлений
            .sseEnabled(true)
            .sseEndpoint(endpoint.replace("/messages", "/sse"))
            // Таймауты
            .connectTimeout(10_000)  // 10 секунд
            .readTimeout(60_000)     // 60 секунд для длительных операций
            // Retry логика
            .retryAttempts(3)
            .retryDelay(1000)
            .build();
        
        // Создаем клиента
        return McpClient.builder()
            .transport(transport)
            .clientInfo(Implementation.builder()
                .name("http-mcp-client")
                .version("1.0.0")
                .build())
            .build();
    }
    
    /**
     * Пример использования HTTP клиента.
     */
    public static void main(String[] args) {
        String endpoint = "https://api.example.com/mcp/messages";
        String apiKey = System.getenv("MCP_API_KEY");
        
        McpClient client = createHttpClient(endpoint, apiKey);
        
        try {
            // Подключаемся
            client.initialize();
            System.out.println("Подключено к удаленному серверу");
            
            // Используем клиента
            List<Tool> tools = client.listTools();
            System.out.println("Доступно инструментов: " + tools.size());
            
            // Вызываем инструмент
            String result = client.callTool("some_tool", Map.of());
            System.out.println("Результат: " + result);
            
        } catch (Exception e) {
            System.err.println("Ошибка: " + e.getMessage());
        } finally {
            client.close();
        }
    }
}
```

---

## Реализация MCP-сервера

### Базовый сервер

Создадим простой MCP-сервер, который предоставляет инструменты.

```java
package com.example.mcp.server;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.server.StdioServerTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.util.List;
import java.util.Map;

/**
 * Базовый MCP-сервер с несколькими инструментами.
 * 
 * Этот сервер демонстрирует:
 * - Регистрацию инструментов
 * - Обработку вызовов инструментов
 * - Отправку уведомлений
 */
public class BasicMcpServer {
    
    private final McpServer server;
    
    /**
     * Создание и настройка сервера.
     */
    public BasicMcpServer() {
        // Создаем сервер с помощью builder
        this.server = McpServer.builder()
            // Информация о сервере
            .serverInfo(Implementation.builder()
                .name("basic-mcp-server")
                .version("1.0.0")
                .build())
            
            // Объявляем capabilities сервера
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder()
                    .listChanged(true)  // Поддержка уведомлений об изменениях
                    .build())
                .logging(LoggingCapability.builder()
                    .build())
                .build())
            
            // Регистрируем provider для списка инструментов
            .toolsProvider(this::provideTools)
            
            // Регистрируем handler для вызова инструментов
            .callToolHandler(this::handleToolCall)
            
            .build();
    }
    
    /**
     * Предоставление списка доступных инструментов.
     * 
     * Этот метод вызывается когда клиент запрашивает tools/list.
     * 
     * @return список инструментов
     */
    private List<Tool> provideTools() {
        return List.of(
            // Инструмент 1: Echo - возвращает то, что получил
            Tool.builder()
                .name("echo")
                .description("Возвращает переданное сообщение")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "message", JsonSchema.builder()
                            .type("string")
                            .description("Сообщение для echo")
                            .build()
                    ))
                    .required(List.of("message"))
                    .build())
                .build(),
            
            // Инструмент 2: Add - складывает два числа
            Tool.builder()
                .name("add")
                .description("Складывает два числа")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "a", JsonSchema.builder()
                            .type("number")
                            .description("Первое число")
                            .build(),
                        "b", JsonSchema.builder()
                            .type("number")
                            .description("Второе число")
                            .build()
                    ))
                    .required(List.of("a", "b"))
                    .build())
                .build(),
            
            // Инструмент 3: Get time - возвращает текущее время
            Tool.builder()
                .name("get_time")
                .description("Возвращает текущее время")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of())  // Без параметров
                    .build())
                .build()
        );
    }
    
    /**
     * Обработка вызова инструмента.
     * 
     * Этот метод вызывается когда клиент отправляет tools/call.
     * 
     * @param request запрос на вызов инструмента
     * @return результат выполнения
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        String toolName = request.params().name();
        Map<String, JsonNode> arguments = request.params().arguments();
        
        // Логируем вызов
        server.sendLog("info", "Tool called: " + toolName, "BasicMcpServer");
        
        try {
            // Маршрутизируем на соответствующий handler
            return switch (toolName) {
                case "echo" -> handleEcho(arguments);
                case "add" -> handleAdd(arguments);
                case "get_time" -> handleGetTime(arguments);
                default -> throw new IllegalArgumentException(
                    "Unknown tool: " + toolName
                );
            };
            
        } catch (Exception e) {
            // Логируем ошибку
            server.sendLog("error", 
                "Tool execution failed: " + e.getMessage(), 
                "BasicMcpServer");
            
            // Возвращаем ошибку в результате
            return CallToolResult.builder()
                .content(List.of(
                    TextContent.builder()
                        .text("Ошибка выполнения: " + e.getMessage())
                        .build()
                ))
                .isError(true)
                .build();
        }
    }
    
    /**
     * Обработка инструмента echo.
     */
    private CallToolResult handleEcho(Map<String, JsonNode> arguments) {
        String message = arguments.get("message").asText();
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text("Echo: " + message)
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента add.
     */
    private CallToolResult handleAdd(Map<String, JsonNode> arguments) {
        double a = arguments.get("a").asDouble();
        double b = arguments.get("b").asDouble();
        double result = a + b;
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text(String.format("%.2f + %.2f = %.2f", a, b, result))
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента get_time.
     */
    private CallToolResult handleGetTime(Map<String, JsonNode> arguments) {
        String currentTime = java.time.Instant.now().toString();
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text("Текущее время: " + currentTime)
                    .build()
            ))
            .build();
    }
    
    /**
     * Запуск сервера с STDIO транспортом.
     */
    public void start() {
        // Создаем STDIO транспорт
        StdioServerTransport transport = new StdioServerTransport();
        
        // Подключаем транспорт к серверу
        server.connect(transport);
        
        // Логируем запуск в stderr (stdout занят протоколом)
        System.err.println("BasicMcpServer запущен");
        System.err.println("Готов принимать MCP-запросы");
    }
    
    /**
     * Точка входа приложения.
     */
    public static void main(String[] args) {
        BasicMcpServer server = new BasicMcpServer();
        server.start();
    }
}
```

### Сервер с Resources

```java
package com.example.mcp.server;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.schema.*;
import java.util.List;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * MCP-сервер, предоставляющий доступ к ресурсам (файлам, данным).
 */
public class ResourcesMcpServer {
    
    private final McpServer server;
    private final Path dataDirectory;
    
    public ResourcesMcpServer(Path dataDirectory) {
        this.dataDirectory = dataDirectory;
        
        this.server = McpServer.builder()
            .serverInfo(Implementation.builder()
                .name("resources-mcp-server")
                .version("1.0.0")
                .build())
            
            // Объявляем поддержку resources
            .capabilities(ServerCapabilities.builder()
                .resources(ResourcesCapability.builder()
                    .subscribe(true)      // Поддержка подписки на изменения
                    .listChanged(true)    // Уведомления об изменениях списка
                    .build())
                .build())
            
            // Provider для списка ресурсов
            .resourcesProvider(this::provideResources)
            
            // Handler для чтения ресурсов
            .readResourceHandler(this::handleReadResource)
            
            // Handler для подписки на ресурс
            .subscribeResourceHandler(this::handleSubscribeResource)
            
            // Handler для отписки от ресурса
            .unsubscribeResourceHandler(this::handleUnsubscribeResource)
            
            .build();
    }
    
    /**
     * Предоставление списка доступных ресурсов.
     */
    private List<Resource> provideResources() {
        try {
            return Files.list(dataDirectory)
                .filter(Files::isRegularFile)
                .map(this::pathToResource)
                .toList();
                
        } catch (Exception e) {
            server.sendLog("error", 
                "Failed to list resources: " + e.getMessage(),
                "ResourcesMcpServer");
            return List.of();
        }
    }
    
    /**
     * Преобразование пути файла в Resource.
     */
    private Resource pathToResource(Path path) {
        String fileName = path.getFileName().toString();
        String uri = "file://" + path.toAbsolutePath();
        String mimeType = guessMimeType(fileName);
        
        return Resource.builder()
            .uri(uri)
            .name(fileName)
            .description("Файл: " + fileName)
            .mimeType(mimeType)
            .build();
    }
    
    /**
     * Определение MIME-типа по расширению файла.
     */
    private String guessMimeType(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".txt")) return "text/plain";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".xml")) return "application/xml";
        if (lower.endsWith(".csv")) return "text/csv";
        if (lower.endsWith(".md")) return "text/markdown";
        return "application/octet-stream";
    }
    
    /**
     * Чтение содержимого ресурса.
     */
    private ReadResourceResult handleReadResource(ReadResourceRequest request) {
        String uri = request.params().uri();
        
        try {
            // Извлекаем путь из URI
            Path path = Path.of(uri.replace("file://", ""));
            
            // Проверяем, что файл находится в разрешенной директории
            if (!path.startsWith(dataDirectory)) {
                throw new SecurityException("Access denied: " + uri);
            }
            
            // Читаем содержимое
            String content = Files.readString(path);
            String mimeType = guessMimeType(path.getFileName().toString());
            
            // Возвращаем результат
            return ReadResourceResult.builder()
                .contents(List.of(
                    ResourceContents.builder()
                        .uri(uri)
                        .mimeType(mimeType)
                        .text(content)
                        .build()
                ))
                .build();
                
        } catch (Exception e) {
            server.sendLog("error", 
                "Failed to read resource " + uri + ": " + e.getMessage(),
                "ResourcesMcpServer");
            throw new RuntimeException("Failed to read resource", e);
        }
    }
    
    /**
     * Подписка клиента на обновления ресурса.
     */
    private EmptyResult handleSubscribeResource(SubscribeRequest request) {
        String uri = request.params().uri();
        
        // Здесь можно реализовать file watcher
        server.sendLog("info", "Client subscribed to: " + uri, "ResourcesMcpServer");
        
        return EmptyResult.builder().build();
    }
    
    /**
     * Отписка клиента от обновлений ресурса.
     */
    private EmptyResult handleUnsubscribeResource(UnsubscribeRequest request) {
        String uri = request.params().uri();
        
        server.sendLog("info", "Client unsubscribed from: " + uri, "ResourcesMcpServer");
        
        return EmptyResult.builder().build();
    }
    
    /**
     * Уведомление клиентов об изменении ресурса.
     * Вызывается когда файл изменяется на диске.
     */
    public void notifyResourceUpdated(String uri) {
        server.sendNotification(
            ResourceUpdatedNotification.builder()
                .method("notifications/resources/updated")
                .params(ResourceUpdatedParams.builder()
                    .uri(uri)
                    .build())
                .build()
        );
    }
}
```

---

## Best Practices

### 1. Обработка ошибок

```java
/**
 * Всегда оборачивайте tool handlers в try-catch
 * и возвращайте понятные ошибки.
 */
private CallToolResult safeToolHandler(CallToolRequest request) {
    try {
        return executeToolLogic(request);
        
    } catch (IllegalArgumentException e) {
        // Ошибки валидации
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text("Невалидные параметры: " + e.getMessage())
                    .build()
            ))
            .isError(true)
            .build();
            
    } catch (Exception e) {
        // Неожиданные ошибки
        server.sendLog("error", 
            "Unexpected error: " + e.getMessage(),
            "ToolHandler");
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text("Внутренняя ошибка сервера")
                    .build()
            ))
            .isError(true)
            .build();
    }
}
```

### 2. Валидация параметров

```java
/**
 * Валидируйте все входные параметры перед использованием.
 */
private void validateToolArguments(
        String toolName, 
        Map<String, JsonNode> arguments) {
    
    switch (toolName) {
        case "send_email" -> {
            if (!arguments.containsKey("to")) {
                throw new IllegalArgumentException("Missing required field: to");
            }
            String email = arguments.get("to").asText();
            if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                throw new IllegalArgumentException("Invalid email format");
            }
        }
        
        case "delete_file" -> {
            if (!arguments.containsKey("path")) {
                throw new IllegalArgumentException("Missing required field: path");
            }
            String path = arguments.get("path").asText();
            // Проверяем, что путь не выходит за пределы разрешенной директории
            if (path.contains("..")) {
                throw new SecurityException("Path traversal attempt detected");
            }
        }
    }
}
```

### 3. Логирование

```java
/**
 * Используйте structured logging для отладки.
 */
public class LoggingBestPractices {
    
    private void logToolCall(String toolName, Map<String, Object> args) {
        // Debug level для детальной информации
        server.sendLog("debug",
            String.format("Tool called: %s with args: %s", toolName, args),
            "ToolHandler");
    }
    
    private void logToolResult(String toolName, boolean success, long durationMs) {
        // Info level для аудита
        server.sendLog("info",
            String.format("Tool %s %s in %dms", 
                toolName, 
                success ? "succeeded" : "failed",
                durationMs),
            "ToolHandler");
    }
    
    private void logSecurityEvent(String event, String details) {
        // Warning/Error level для безопасности
        server.sendLog("warning",
            String.format("Security event: %s - %s", event, details),
            "Security");
    }
}
```

### 4. Прогресс для длительных операций

```java
/**
 * Всегда отправляйте progress для операций > 1 секунды.
 */
private CallToolResult longRunningOperation(CallToolRequest request) {
    String progressToken = generateProgressToken();
    int total = 100;
    
    for (int i = 0; i < total; i++) {
        // Выполняем работу
        processStep(i);
        
        // Отправляем прогресс каждые 10%
        if (i % 10 == 0) {
            server.sendProgress(progressToken, i, total);
        }
    }
    
    server.sendProgress(progressToken, total, total);
    return createResult();
}
```

---

## Резюме модуля

### Что вы узнали:

✅ **MCP Java SDK** — официальная библиотека для работы с протоколом

✅ **McpClient** — создание клиентов с STDIO и HTTP транспортами

✅ **McpServer** — создание серверов с tools, resources, prompts

✅ **Best Practices** — обработка ошибок, валидация, логирование, прогресс

### Следующие шаги:

В следующем модуле вы узнаете:
- Отладку и мониторинг MCP-приложений
- Использование MCP Inspector
- Диагностику проблем

---

## Дополнительные материалы

- [MCP Java SDK GitHub](https://github.com/modelcontextprotocol/java-sdk)
- [MCP SDK Documentation](https://modelcontextprotocol.io/docs/sdk/java)
- [Example Servers](https://github.com/modelcontextprotocol/servers)
"""

with open("mcp-java-course/lectures/module-03-java-sdk/lecture.md", "w", encoding="utf-8") as f:
    f.write(module03_lecture)

print("✓ Файл создан: module-03-java-sdk/lecture.md")
