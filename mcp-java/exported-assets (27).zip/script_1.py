
# Создаем отсутствующие директории
import os

dirs_to_create = [
    "mcp-java-course/lectures/module-02-protocol/diagrams",
    "mcp-java-course/lectures/module-03-java-sdk/diagrams",
    "mcp-java-course/labs/lab-01-simple-server",
    "mcp-java-course/labs/lab-02-client",
    "mcp-java-course/labs/lab-03-tools",
]

for dir_path in dirs_to_create:
    os.makedirs(dir_path, exist_ok=True)

print("Директории созданы. Продолжаем создание файлов...")
