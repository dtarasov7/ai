
# Модуль 2 - Mindmap
module02_mindmap = """@startmindmap
* MCP-протокол
** Transport Layer
*** STDIO
**** Локальные процессы
**** stdin/stdout
**** Без аутентификации
**** Desktop приложения
*** HTTP/SSE
**** Удаленный доступ
**** POST запросы
**** SSE для событий
**** Bearer tokens
**** Масштабируемость
left side
** Message Types
*** Request
**** id (обязательно)
**** method
**** params
**** Ждет Response
*** Response
**** id (из request)
**** result ИЛИ error
**** Успех/ошибка
*** Error
**** code (стандартные коды)
**** message
**** data (опционально)
*** Notification
**** Без id
**** Fire-and-forget
**** Асинхронные события
** Методы протокола
*** initialize
*** tools/list, tools/call
*** resources/list, resources/read
*** prompts/list, prompts/get
*** sampling/createMessage
*** ping
** Notifications
*** progress
**** progressToken
**** progress/total
*** message (логи)
**** level, data, logger
*** resources/updated
*** tools/list_changed
*** prompts/list_changed
** Error Codes
*** -32700 Parse error
*** -32600 Invalid Request
*** -32601 Method not found
*** -32602 Invalid params
*** -32603 Internal error
*** -32000..-32099 Server errors
@endmindmap
"""

# Модуль 2 - Диаграмма транспортов
transport_diagram = """@startuml

title MCP Transport Layer: STDIO vs HTTP/SSE

package "STDIO Transport" {
    component "Claude Desktop\\n(Host + Client)" as ClaudeStdio
    component "MCP Server\\nProcess" as ServerStdio
    
    ClaudeStdio -down-> ServerStdio : stdin/stdout\\n(same machine)
    
    note right of ServerStdio
        **Характеристики:**
        • Локальное выполнение
        • Без сетевых накладных расходов
        • Не требует аутентификации
        • stdout - протокол
        • stderr - логи
    end note
}

package "HTTP/SSE Transport" {
    component "Web Client\\n(Browser)" as WebClient
    component "HTTP Server\\n(Spring Boot)" as HTTPServer
    database "Backend\\nServices" as Backend
    
    WebClient -down-> HTTPServer : POST /mcp/messages\\n(JSON-RPC)
    HTTPServer -down-> WebClient : SSE /mcp/sse\\n(notifications)
    HTTPServer -right-> Backend
    
    note right of HTTPServer
        **Характеристики:**
        • Удаленный доступ
        • Bearer token auth
        • Масштабируемость
        • Load balancing
        • Cloud deployment
    end note
}

@enduml
"""

# Модуль 2 - Диаграмма типов сообщений
messages_diagram = """@startuml
!theme plain

title MCP Message Types

participant Client
participant Server

== Request/Response ==
Client -> Server : **Request**\\n{"jsonrpc":"2.0", "id":"1",\\n"method":"tools/list"}
activate Server
Server --> Client : **Response**\\n{"jsonrpc":"2.0", "id":"1",\\n"result": {...}}
deactivate Server

== Error ==
Client -> Server : **Request**\\n{"jsonrpc":"2.0", "id":"2",\\n"method":"invalid/method"}
activate Server
Server --> Client : **Error Response**\\n{"jsonrpc":"2.0", "id":"2",\\n"error": {"code": -32601, ...}}
deactivate Server

== Notification (односторонняя) ==
Server -> Client : **Notification**\\n{"jsonrpc":"2.0",\\n"method":"notifications/progress",\\n"params": {...}}
note right : Нет id, нет ответа

Client -> Server : **Notification**\\n{"jsonrpc":"2.0",\\n"method":"notifications/cancelled",\\n"params": {...}}
note left : Нет id, нет ответа

@enduml
"""

# Модуль 2 - Диаграмма жизненного цикла
lifecycle_diagram = """@startuml

title MCP Session Lifecycle

participant Client
participant Server

== Инициализация ==
Client -> Server : initialize\\n{protocolVersion, clientInfo, capabilities}
activate Server
Server --> Client : InitializeResult\\n{serverInfo, capabilities}
deactivate Server

Client -> Server : initialized (notification)\\nКлиент готов к работе

== Обнаружение возможностей ==
Client -> Server : tools/list
Server --> Client : [Tool1, Tool2, ...]

Client -> Server : resources/list
Server --> Client : [Resource1, Resource2, ...]

Client -> Server : prompts/list
Server --> Client : [Prompt1, Prompt2, ...]

== Использование ==
loop Работа с сервером
    Client -> Server : tools/call\\n{name, arguments}
    activate Server
    
    Server -> Client : notifications/progress\\n(опционально)
    
    Server --> Client : CallToolResult\\n{content, isError}
    deactivate Server
    
    Client -> Server : resources/read\\n{uri}
    Server --> Client : ReadResourceResult\\n{contents}
end

== Динамические изменения ==
Server -> Client : notifications/tools/list_changed
Client -> Server : tools/list\\n(обновить список)
Server --> Client : [обновленный список]

== Завершение ==
Client -> Server : close connection

@enduml
"""

# Записываем все файлы модуля 2
with open("mcp-java-course/lectures/module-02-protocol/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module02_mindmap)

with open("mcp-java-course/lectures/module-02-protocol/diagrams/transport.puml", "w", encoding="utf-8") as f:
    f.write(transport_diagram)

with open("mcp-java-course/lectures/module-02-protocol/diagrams/messages.puml", "w", encoding="utf-8") as f:
    f.write(messages_diagram)

with open("mcp-java-course/lectures/module-02-protocol/diagrams/lifecycle.puml", "w", encoding="utf-8") as f:
    f.write(lifecycle_diagram)

print("✓ Файл создан: module-02-protocol/mindmap.puml")
print("✓ Файл создан: module-02-protocol/diagrams/transport.puml")
print("✓ Файл создан: module-02-protocol/diagrams/messages.puml")
print("✓ Файл создан: module-02-protocol/diagrams/lifecycle.puml")
