
# Модуль 1 - Диаграмма сравнения с и без MCP
comparison_diagram = """@startuml

title Сравнение: Интеграция LLM без MCP vs с MCP

package "Традиционный подход (БЕЗ MCP)" {
    
    component "Claude\\nDesktop" as Claude1
    component "ChatGPT\\nWeb" as ChatGPT1
    component "Custom\\nApp" as Custom1
    
    database "Database A" as DB1
    database "Database B" as DB2
    component "API Service" as API1
    component "File System" as FS1
    
    Claude1 -[#red]-> DB1 : custom integration
    Claude1 -[#red]-> API1 : custom integration
    ChatGPT1 -[#red]-> DB1 : duplicate code
    ChatGPT1 -[#red]-> DB2 : custom integration
    Custom1 -[#red]-> FS1 : custom integration
    Custom1 -[#red]-> DB2 : duplicate code
    
    note right of DB1 #FFE6E6
        Проблемы:
        • Дублирование кода
        • Высокая сложность
        • Трудная поддержка
        • Несовместимость решений
    end note
}

package "Современный подход (С MCP)" {
    
    component "Claude\\nDesktop" as Claude2
    component "ChatGPT\\nWeb" as ChatGPT2
    component "Custom\\nApp" as Custom2
    
    component "MCP\\nClient" as Client1
    component "MCP\\nClient" as Client2
    component "MCP\\nClient" as Client3
    
    component "Database\\nMCP Server" as DBMCP
    component "API\\nMCP Server" as APIMCP
    component "FileSystem\\nMCP Server" as FSMCP
    
    database "Database A" as DB3
    database "Database B" as DB4
    component "API Service" as API2
    component "File System" as FS2
    
    Claude2 -[#green]-> Client1 : встроенный
    ChatGPT2 -[#green]-> Client2 : встроенный
    Custom2 -[#green]-> Client3 : встроенный
    
    Client1 -[#blue]-> DBMCP : MCP Protocol
    Client1 -[#blue]-> APIMCP : MCP Protocol
    Client2 -[#blue]-> DBMCP : MCP Protocol
    Client2 -[#blue]-> FSMCP : MCP Protocol
    Client3 -[#blue]-> APIMCP : MCP Protocol
    Client3 -[#blue]-> FSMCP : MCP Protocol
    
    DBMCP --> DB3
    DBMCP --> DB4
    APIMCP --> API2
    FSMCP --> FS2
    
    note right of DBMCP #E6FFE6
        Преимущества:
        ✓ Единый стандарт
        ✓ Переиспользование
        ✓ Простая поддержка
        ✓ Экосистема решений
    end note
}

@enduml
"""

with open("mcp-java-course/lectures/module-01-introduction/diagrams/comparison.puml", "w", encoding="utf-8") as f:
    f.write(comparison_diagram)

print("✓ Файл создан: module-01-introduction/diagrams/comparison.puml")
