
# Модуль 1 - Mindmap
module01_mindmap = """@startmindmap
* Model Context Protocol
** Что такое MCP
*** Открытый протокол
*** Стандартизация интеграции
*** LLM ↔ External Data
*** Разработан Anthropic
*** JSON-RPC 2.0
** Применение
*** AI-powered IDE
**** Git интеграция
**** Анализ кода
*** Чат-интерфейсы
**** Корпоративные БД
**** CRM/ERP системы
*** Custom AI workflows
**** Автоматизация процессов
**** API интеграции
*** Agentic системы
**** Автономные агенты
**** Многошаговое рассуждение
left side
** Архитектура
*** Host
**** LLM Application
**** UI Management
**** Lifecycle Control
**** User Consent
*** Client (коннектор)
**** Connection Manager
**** Capability Negotiation
**** Session Management
**** Request/Response
*** Server (сервис)
**** Tools Provider
**** Resources Provider
**** Prompts Provider
**** Data Access
** Протокол
*** Transport Layer
**** STDIO
***** Локальные процессы
***** Оптимальная производительность
**** HTTP/SSE
***** Удаленный доступ
***** Аутентификация
***** Масштабируемость
*** Data Layer
**** Tools (инструменты)
**** Resources (данные)
**** Prompts (шаблоны)
**** Notifications
** Безопасность
*** User Consent
**** Явное согласие
**** Понятный UI
*** Data Privacy
**** Контроль доступа
**** Защита данных
*** Tool Safety
**** Понимание действий
**** Опасные операции
*** Sampling Control
**** Одобрение запросов
**** Аудит действий
@endmindmap
"""

with open("mcp-java-course/lectures/module-01-introduction/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module01_mindmap)

print("✓ Файл создан: module-01-introduction/mindmap.puml")
