
# Модуль 1 - Лекция
module01_lecture = """# Модуль 1: Введение в Model Context Protocol

## Цели модуля

После изучения этого модуля вы:
- Поймете, что такое Model Context Protocol и зачем он нужен
- Узнаете основные роли в архитектуре MCP: Host, Client, Server
- Сможете объяснить преимущества использования MCP
- Поймете принципы безопасности протокола

---

## Что такое MCP (Model Context Protocol)

Model Context Protocol (MCP) — это **открытый стандартизированный протокол**, который обеспечивает бесшовную интеграцию между LLM-приложениями и внешними источниками данных и инструментами. Протокол был разработан компанией Anthropic и предоставляет универсальный способ для AI-моделей взаимодействовать с внешним миром через согласованный интерфейс.

### Основная идея

MCP решает проблему **фрагментированной интеграции** AI-систем. Вместо того чтобы создавать отдельные интеграции для каждой комбинации LLM и источника данных, MCP предлагает единый протокол, который работает везде.

**Аналогия**: Представьте MCP как **USB-порт для AI**. Точно так же, как USB стандартизировал подключение периферийных устройств к компьютерам (мышь, клавиатура, принтер используют один интерфейс), MCP стандартизирует подключение AI-моделей к данным и инструментам.

### Ключевые возможности MCP

MCP позволяет приложениям:

- **Делиться контекстной информацией** с языковыми моделями через унифицированный интерфейс
- **Предоставлять инструменты и возможности** AI-системам для выполнения действий
- **Строить композиционные интеграции** и сложные рабочие процессы
- **Обеспечивать безопасный доступ** к данным и операциям с контролем пользователя

### Технические основы протокола

MCP базируется на следующих принципах:

- **Формат сообщений**: JSON-RPC 2.0 (легкий протокол удаленного вызова процедур)
- **Соединения**: Stateful (с сохранением состояния между запросами)
- **Согласование возможностей**: Динамическое обнаружение capabilities между сервером и клиентом
- **Безопасность**: Контроль доступа и согласие пользователя на уровне протокола

---

## Роль MCP в экосистеме LLM

### Проблема без MCP

Традиционно, для интеграции LLM с внешними системами требуется создавать отдельную интеграцию для каждой пары "приложение-источник данных":

```
┌─────────────┐      ┌──────────────┐
│ LLM App 1   │─────→│ Database A   │
│ (Claude)    │      └──────────────┘
└─────────────┘
       │             ┌──────────────┐
       └────────────→│ API Service B│
                     └──────────────┘

┌─────────────┐      ┌──────────────┐
│ LLM App 2   │─────→│ Database A   │
│ (ChatGPT)   │      └──────────────┘
└─────────────┘
       │             ┌──────────────┐
       └────────────→│ API Service C│
                     └──────────────┘
```

Это приводит к:
- ❌ **Дублированию кода** — каждое приложение реализует свои коннекторы
- ❌ **Сложности поддержки** — изменения в API требуют обновления всех интеграций
- ❌ **Несовместимости** — решения от разных разработчиков не работают вместе
- ❌ **Высокой стоимости** — каждая новая интеграция требует значительных ресурсов

### Решение с MCP

MCP создает **единый стандарт взаимодействия**:

```
┌─────────────┐      ┌──────────────┐      ┌──────────────┐
│ LLM App 1   │─────→│ MCP Client   │─────→│ MCP Server A │
│ (Claude)    │      └──────────────┘      │ (Database)   │
└─────────────┘                            └──────────────┘

┌─────────────┐      ┌──────────────┐      ┌──────────────┐
│ LLM App 2   │─────→│ MCP Client   │─────→│ MCP Server B │
│ (ChatGPT)   │      └──────────────┘      │ (FileSystem) │
└─────────────┘                            └──────────────┘
```

Преимущества:
- ✅ **Переиспользование** — один MCP-сервер работает со всеми клиентами
- ✅ **Простота поддержки** — изменения локализованы в одном месте
- ✅ **Экосистема** — разработчики создают совместимые компоненты
- ✅ **Снижение затрат** — быстрая разработка новых интеграций

### Применение в экосистеме

MCP используется для:

1. **AI-powered IDE**
   - Интеграция с системами контроля версий (Git)
   - Доступ к кодовой базе проекта
   - Анализ зависимостей и документации

2. **Чат-интерфейсы**
   - Доступ к корпоративным базам данных
   - Интеграция с CRM и ERP системами
   - Поиск по внутренним документам

3. **Кастомные AI-workflow**
   - Автоматизация бизнес-процессов
   - Интеграция с внешними API
   - Обработка и анализ данных

4. **Agentic системы**
   - Построение автономных агентов с доступом к инструментам
   - Многошаговые рассуждения с использованием внешних данных
   - Самостоятельное планирование и выполнение задач

---

## Архитектура: клиент, сервер, хост

MCP определяет **три ключевые роли** в своей архитектуре. Понимание этих ролей критически важно для работы с протоколом.

### 1. Host (Хост)

**Определение**: LLM-приложение, которое инициирует соединения с MCP-серверами и управляет общим workflow.

**Примеры Host-приложений**:
- Claude Desktop (официальный клиент от Anthropic)
- IDE с AI-ассистентами (Cursor, VS Code с расширениями)
- Кастомные AI-приложения на базе различных LLM

**Ответственность Host**:
- Управление жизненным циклом приложения
- Отправка запросов к LLM (например, OpenAI, Anthropic, локальные модели)
- Управление пользовательским интерфейсом
- Координация между пользователем, LLM и MCP-серверами
- Обеспечение безопасности и получение согласия пользователя

**Пример кода Host**:

```java
package com.example.mcp.host;

import java.util.List;

/**
 * Пример реализации MCP Host — AI-приложения,
 * которое координирует взаимодействие пользователя с LLM и MCP-серверами.
 */
public class AIApplicationHost {
    
    // Клиент для взаимодействия с LLM (например, OpenAI API)
    private final ChatClient chatClient;
    
    // MCP-клиент для подключения к внешним серверам
    private final McpClient mcpClient;
    
    /**
     * Конструктор хоста AI-приложения.
     * Хост управляет взаимодействием между пользователем, LLM и MCP-серверами.
     * 
     * @param chatClient клиент для взаимодействия с LLM
     * @param mcpClient клиент для подключения к MCP-серверам
     */
    public AIApplicationHost(ChatClient chatClient, McpClient mcpClient) {
        this.chatClient = chatClient;
        this.mcpClient = mcpClient;
    }
    
    /**
     * Обработка пользовательского запроса.
     * 
     * Workflow:
     * 1. Получаем доступные инструменты от всех подключенных MCP-серверов
     * 2. Отправляем запрос пользователя в LLM вместе со списком доступных tools
     * 3. LLM анализирует запрос и решает, нужно ли вызвать какой-то tool
     * 4. Если нужно — вызываем tool через MCP-клиент
     * 5. Возвращаем результат пользователю
     * 
     * @param userQuery запрос от пользователя
     * @return ответ AI-ассистента
     */
    public String processUserQuery(String userQuery) {
        // Шаг 1: Получаем доступные инструменты от MCP-серверов
        List<Tool> availableTools = mcpClient.listTools();
        
        // Шаг 2: Отправляем запрос в LLM с доступными инструментами
        // LLM сам решит, нужно ли использовать какой-то tool
        String llmResponse = chatClient.call(userQuery, availableTools);
        
        // Шаг 3: Если LLM решил вызвать tool, обрабатываем это
        if (chatClient.wantsToCallTool()) {
            ToolCall toolCall = chatClient.getToolCall();
            
            // ВАЖНО: Запрашиваем согласие пользователя перед вызовом tool
            if (!requestUserConsent(toolCall)) {
                return "Операция отменена пользователем";
            }
            
            // Вызываем tool через MCP-клиент
            String toolResult = mcpClient.callTool(
                toolCall.getName(), 
                toolCall.getArguments()
            );
            
            // Отправляем результат обратно в LLM для формирования финального ответа
            llmResponse = chatClient.continueWithToolResult(toolResult);
        }
        
        return llmResponse;
    }
    
    /**
     * Запрос согласия пользователя на выполнение операции.
     * Критически важно для безопасности!
     * 
     * @param toolCall информация о вызываемом инструменте
     * @return true если пользователь одобрил операцию
     */
    private boolean requestUserConsent(ToolCall toolCall) {
        // В реальном приложении здесь должен быть UI-диалог
        System.out.println("AI хочет выполнить: " + toolCall.getName());
        System.out.println("Параметры: " + toolCall.getArguments());
        System.out.print("Разрешить? (y/n): ");
        
        // Здесь должна быть реальная логика получения согласия от пользователя
        return true; // Упрощенная версия для примера
    }
}
```

### 2. Client (Клиент)

**Определение**: Коннектор внутри host-приложения, который управляет соединением с одним или несколькими MCP-серверами.

**Важно понять**: Client — это не отдельное приложение, а **компонент внутри Host**. Часто Host и Client существуют в одном процессе.

**Ответственность Client**:
- Установление соединения с MCP-серверами
- Согласование возможностей (capability negotiation) при инициализации
- Управление жизненным циклом сессии
- Отправка запросов к серверам и получение ответов
- Обработка уведомлений от серверов

**Пример кода Client**:

```java
package com.example.mcp.client;

import java.util.Collections;
import java.util.List;

/**
 * Пример реализации MCP Client — компонента, который управляет
 * соединением с MCP-сервером.
 */
public class SimpleMcpClient {
    
    // Сессия соединения с сервером
    private McpSession session;
    
    // Возможности сервера, полученные при инициализации
    private InitializeResult serverCapabilities;
    
    /**
     * Инициализация соединения с MCP-сервером.
     * 
     * Процесс инициализации:
     * 1. Создаем транспортный канал (STDIO или HTTP)
     * 2. Создаем сессию на основе транспорта
     * 3. Отправляем initialize запрос с нашими возможностями
     * 4. Получаем возможности сервера
     * 5. Отправляем initialized уведомление
     * 
     * @param transport транспортный механизм (STDIO, HTTP, SSE)
     * @throws Exception если инициализация не удалась
     */
    public void connect(McpTransport transport) throws Exception {
        // Создаем сессию на основе транспорта
        this.session = McpSession.create(transport);
        
        // Формируем запрос инициализации с нашими возможностями
        InitializeRequest request = InitializeRequest.builder()
            .protocolVersion("2024-11-05") // Версия протокола MCP
            .clientInfo(Implementation.builder()
                .name("my-mcp-client")
                .version("1.0.0")
                .build())
            .capabilities(ClientCapabilities.builder()
                // Объявляем, что поддерживаем корневые директории
                .roots(RootsCapability.builder()
                    .listChanged(true) // Можем уведомлять об изменениях
                    .build())
                // Объявляем, что поддерживаем sampling (LLM запросы от сервера)
                .sampling(SamplingCapability.builder().build())
                .build())
            .build();
        
        // Отправляем запрос и получаем возможности сервера
        this.serverCapabilities = session.initialize(request);
        
        // Выводим информацию о подключенном сервере
        System.out.println("Подключено к серверу: " + 
            serverCapabilities.serverInfo().name() + " v" +
            serverCapabilities.serverInfo().version());
        
        System.out.println("Возможности сервера:");
        if (serverCapabilities.capabilities().tools() != null) {
            System.out.println("  ✓ Tools");
        }
        if (serverCapabilities.capabilities().resources() != null) {
            System.out.println("  ✓ Resources");
        }
        if (serverCapabilities.capabilities().prompts() != null) {
            System.out.println("  ✓ Prompts");
        }
    }
    
    /**
     * Получение списка доступных инструментов с сервера.
     * 
     * @return список инструментов, предоставляемых сервером
     */
    public List<Tool> listTools() {
        // Проверяем, поддерживает ли сервер tools
        if (serverCapabilities.capabilities().tools() == null) {
            return Collections.emptyList();
        }
        
        // Запрашиваем список инструментов
        ListToolsResult result = session.listTools();
        return result.tools();
    }
    
    /**
     * Вызов инструмента на сервере.
     * 
     * @param toolName имя инструмента
     * @param arguments параметры для инструмента
     * @return результат выполнения инструмента
     */
    public String callTool(String toolName, Map<String, Object> arguments) {
        // Формируем запрос на вызов инструмента
        CallToolRequest request = CallToolRequest.builder()
            .params(CallToolParams.builder()
                .name(toolName)
                .arguments(arguments)
                .build())
            .build();
        
        // Вызываем инструмент
        CallToolResult result = session.callTool(request);
        
        // Проверяем на ошибки
        if (result.isError() != null && result.isError()) {
            throw new RuntimeException("Tool execution failed");
        }
        
        // Извлекаем текстовый результат
        if (result.content() != null && !result.content().isEmpty()) {
            Content firstContent = result.content().get(0);
            if (firstContent instanceof TextContent textContent) {
                return textContent.text();
            }
        }
        
        return "No result";
    }
    
    /**
     * Закрытие соединения с сервером.
     */
    public void disconnect() {
        if (session != null) {
            session.close();
            System.out.println("Соединение закрыто");
        }
    }
}
```

### 3. Server (Сервер)

**Определение**: Сервис, который предоставляет контекст, данные и возможности клиентам через протокол MCP.

**Примеры MCP-серверов**:
- Database MCP Server — предоставляет доступ к базам данных
- Filesystem MCP Server — операции с файловой системой
- Web Search MCP Server — поиск информации в интернете
- Custom Business Logic Server — специфичная бизнес-логика

**Ответственность Server**:
- Регистрация и предоставление возможностей (tools, resources, prompts)
- Обработка запросов от клиентов
- Управление доступом к данным и операциям
- Отправка уведомлений клиентам (опционально)

**Пример кода Server**:

```java
package com.example.mcp.server;

import java.util.List;
import java.util.Map;

/**
 * Пример реализации MCP Server — сервиса, который предоставляет
 * инструменты для получения информации о погоде.
 */
public class WeatherMcpServer {
    
    // Сервис для получения данных о погоде (может быть API, БД, и т.д.)
    private final WeatherService weatherService;
    
    public WeatherMcpServer(WeatherService weatherService) {
        this.weatherService = weatherService;
    }
    
    /**
     * Настройка и запуск MCP-сервера.
     * 
     * Сервер регистрирует свои возможности и обработчики запросов.
     */
    public McpServer setupServer() {
        // Создаем спецификацию инструмента "получить погоду"
        Tool weatherTool = Tool.builder()
            .name("get_weather")
            .description("Получить текущую погоду для указанного города")
            // JSON Schema для параметров инструмента
            .inputSchema(JsonSchema.builder()
                .type("object")
                .properties(Map.of(
                    "city", JsonSchema.builder()
                        .type("string")
                        .description("Название города (например, Moscow, London)")
                        .build(),
                    "units", JsonSchema.builder()
                        .type("string")
                        .enumValues(List.of("celsius", "fahrenheit"))
                        .description("Единицы измерения температуры")
                        .build()
                ))
                .required(List.of("city")) // city — обязательный параметр
                .build())
            .build();
        
        // Создаем и настраиваем сервер
        return McpServer.builder()
            // Информация о сервере
            .serverInfo(Implementation.builder()
                .name("weather-server")
                .version("1.0.0")
                .build())
            // Объявляем наши возможности
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder()
                    .listChanged(true) // Поддержка уведомлений об изменении списка tools
                    .build())
                .build())
            // Регистрируем provider для списка инструментов
            .toolsProvider(() -> List.of(weatherTool))
            // Регистрируем обработчик вызова инструментов
            .callToolHandler(this::handleToolCall)
            .build();
    }
    
    /**
     * Обработчик вызова инструмента.
     * 
     * Этот метод вызывается когда клиент хочет выполнить один из наших tools.
     * 
     * @param request запрос на вызов инструмента от клиента
     * @return результат выполнения инструмента
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        String toolName = request.params().name();
        
        // Проверяем, что вызывается наш инструмент
        if ("get_weather".equals(toolName)) {
            // Извлекаем параметры из запроса
            Map<String, JsonNode> args = request.params().arguments();
            String city = args.get("city").asText();
            
            // units — опциональный параметр, по умолчанию celsius
            String units = args.containsKey("units") 
                ? args.get("units").asText() 
                : "celsius";
            
            // Выполняем бизнес-логику — получаем данные о погоде
            WeatherData weather = weatherService.getWeather(city);
            
            // Формируем текстовый ответ
            String responseText = formatWeatherResponse(weather, units);
            
            // Возвращаем результат в формате MCP
            return CallToolResult.builder()
                .content(List.of(
                    TextContent.builder()
                        .type("text")
                        .text(responseText)
                        .build()
                ))
                .build();
        }
        
        // Если инструмент неизвестен — выбрасываем ошибку
        throw new IllegalArgumentException("Unknown tool: " + toolName);
    }
    
    /**
     * Форматирование данных о погоде в текстовое представление.
     */
    private String formatWeatherResponse(WeatherData weather, String units) {
        double temperature = "fahrenheit".equals(units)
            ? celsiusToFahrenheit(weather.getTemperature())
            : weather.getTemperature();
        
        String unit = "celsius".equals(units) ? "°C" : "°F";
        
        return String.format(
            "Погода в %s:\\n" +
            "Температура: %.1f%s\\n" +
            "Условия: %s\\n" +
            "Влажность: %d%%\\n" +
            "Ветер: %.1f м/с",
            weather.getCity(),
            temperature,
            unit,
            weather.getConditions(),
            weather.getHumidity(),
            weather.getWindSpeed()
        );
    }
    
    /**
     * Преобразование температуры из Цельсия в Фаренгейт.
     */
    private double celsiusToFahrenheit(double celsius) {
        return celsius * 9.0 / 5.0 + 32.0;
    }
    
    /**
     * Запуск сервера с STDIO транспортом.
     * 
     * Используется для локальных интеграций (например, с Claude Desktop).
     */
    public static void main(String[] args) {
        // Создаем зависимости
        WeatherService weatherService = new WeatherService();
        WeatherMcpServer weatherServer = new WeatherMcpServer(weatherService);
        
        // Настраиваем сервер
        McpServer server = weatherServer.setupServer();
        
        // Создаем STDIO транспорт
        StdioTransport transport = new StdioTransport();
        
        // Запускаем сервер
        server.connect(transport);
        
        // Логируем в stderr (stdout используется для протокола)
        System.err.println("Weather MCP Server запущен");
    }
}
```

---

## Взаимодействие компонентов

Рассмотрим типичный flow взаимодействия между компонентами:

```
1. Инициализация
   Host создает MCP Client → Client подключается к Server

2. Согласование возможностей
   Client отправляет свои capabilities → Server отвечает своими capabilities

3. Обнаружение
   Client запрашивает у Server список tools/resources/prompts

4. Использование
   User вводит запрос → Host отправляет в LLM с доступными tools →
   LLM решает вызвать tool → Client вызывает tool на Server →
   Server выполняет и возвращает результат → Host показывает User
```

---

## Уровни протокола

MCP состоит из **двух основных уровней**:

### 1. Transport Layer (Транспортный уровень)

**Ответственность**:
- Управление каналами связи между клиентом и сервером
- Аутентификация и авторизация
- Установление и поддержка соединений
- Обрамление сообщений (message framing)

**Поддерживаемые транспорты**:
- **STDIO** — для локальных процессов
- **HTTP/SSE** — для удаленных соединений

### 2. Data Layer (Уровень данных)

**Ответственность**:
- Определение JSON-RPC протокола для коммуникации
- Управление жизненным циклом сессии
- Основные примитивы: tools, resources, prompts, notifications

**Типы сообщений**:
- **Request** — запрос, требующий ответа
- **Response** — ответ на запрос
- **Notification** — уведомление без ответа

---

## Принципы безопасности

MCP разработан с учетом **безопасности как основополагающего принципа**.

### 1. Согласие и контроль пользователя

- ✅ Пользователь должен **явно дать согласие** на доступ к данным и операции
- ✅ Пользователь сохраняет **полный контроль** над тем, какие данные передаются
- ✅ Необходим **понятный UI** для авторизации действий
- ✅ Пользователь может **отменить** любую операцию в любой момент

**Пример**: Перед тем как AI выполнит SQL-запрос или отправит email, пользователь должен увидеть детали операции и явно её одобрить.

### 2. Приватность данных

- ✅ Host должен получить **явное согласие пользователя** перед передачей данных серверу
- ✅ Данные пользователя должны быть защищены **соответствующими средствами контроля доступа**
- ✅ Серверы не должны хранить данные пользователя без **явного разрешения**
- ✅ Логирование должно **исключать** чувствительную информацию

### 3. Безопасность инструментов

- ⚠️ **Tools представляют собой выполнение произвольного кода** и требуют осторожности
- ✅ Host должен получить **явное согласие пользователя** перед вызовом любого tool
- ✅ Пользователь должен **понимать, что делает каждый tool**
- ✅ Опасные операции (удаление, изменение данных) должны требовать **дополнительного подтверждения**

**Пример опасных операций**:
- Удаление файлов
- Выполнение системных команд
- Изменение данных в базе
- Отправка сообщений

### 4. Контроль LLM Sampling

- ✅ Пользователь должен **явно одобрить** любые запросы на sampling (когда сервер хочет обратиться к LLM через клиента)
- ✅ Пользователь должен контролировать, **какие результаты видит сервер**
- ✅ Sampling должен быть **логируемым и аудируемым**

**Примечание**: Sampling позволяет серверу инициировать LLM-запросы, что может привести к неожиданным затратам или утечке данных.

---

## Резюме модуля

### Что вы узнали:

✅ **MCP** — это открытый протокол для стандартизированной интеграции LLM с внешними данными и инструментами

✅ MCP решает проблему **фрагментированной интеграции** в AI-экосистеме, создавая единый стандарт

✅ **Архитектура MCP** включает три роли:
   - **Host** — LLM-приложение, управляющее workflow
   - **Client** — коннектор внутри Host для связи с серверами
   - **Server** — сервис, предоставляющий данные и инструменты

✅ Протокол базируется на **JSON-RPC 2.0** и поддерживает **STDIO** и **HTTP/SSE** транспорты

✅ **Безопасность и контроль пользователя** — основополагающие принципы MCP

### Следующие шаги:

В следующем модуле вы узнаете детали протокола MCP:
- Типы сообщений (Request, Response, Error, Notification)
- Client и Server capabilities
- Работа с транспортами
- Utilities (Progress, Cancellation, Ping)

---

## Дополнительные материалы

- [Официальная спецификация MCP](https://modelcontextprotocol.io/specification/)
- [MCP Architecture Documentation](https://modelcontextprotocol.io/docs/learn/architecture)
- [Getting Started with MCP](https://modelcontextprotocol.io/docs/getting-started)
"""

with open("mcp-java-course/lectures/module-01-introduction/lecture.md", "w", encoding="utf-8") as f:
    f.write(module01_lecture)

print("✓ Файл создан: module-01-introduction/lecture.md")
