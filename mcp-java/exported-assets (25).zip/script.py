
import os
import json

# Создаем структуру директорий для сессии 1
session1_dirs = [
    "mcp-java-course/lectures/module-01-introduction/diagrams",
    "mcp-java-course/lectures/module-02-protocol/diagrams",
]

for dir_path in session1_dirs:
    os.makedirs(dir_path, exist_ok=True)

print("Сессия 1: Структура создана")
print("Будут созданы файлы для Модулей 1-2")
print("\nСписок файлов для создания:")
print("- README.md")
print("- Модуль 1: lecture.md, mindmap.puml, 3 диаграммы")
print("- Модуль 2: lecture.md, mindmap.puml, 4 диаграммы")
