# Курс: Model Context Protocol (MCP) и Java

Полноценный обучающий курс по работе с Model Context Protocol в экосистеме Java.

## О курсе

Model Context Protocol (MCP) — это открытый протокол, разработанный Anthropic, который обеспечивает стандартизированный способ интеграции LLM-приложений с внешними источниками данных и инструментами.

## Структура курса

### Теоретические модули (lectures/)

1. **Модуль 1: Введение в MCP**
   - Основы протокола
   - Архитектура и роли
   - Применение в экосистеме LLM

2. **Модуль 2: MCP-протокол**
   - Транспортный уровень (STDIO, HTTP/SSE)
   - Типы сообщений (Request, Response, Error, Notification)
   - Возможности клиента и сервера
   - Utilities (Cancellation, Progress, Ping)
   - MCP Inspector

3. **Модуль 3: MCP SDK на Java**
   - Обзор библиотеки
   - Реализация клиента
   - Реализация сервера

4. **Модуль 4: Отладка и мониторинг**
   - Логирование
   - Диагностика проблем
   - Best practices

5. **Модуль 5: Взаимодействие с LLM-хостом**
   - Архитектура взаимодействия
   - Конфигурация хостов

6. **Модуль 6: Интеграция с моделями**
   - Модели с fine-tuning
   - Модели без fine-tuning

7. **Модуль 7: Spring AI и MCP**
   - Spring Boot стартеры
   - Аннотации MCP
   - Конфигурация

8. **Модуль 8: Практика**
   - Комплексные примеры
   - Best practices

### Практические лабораторные работы (labs/)

- **Lab 01**: Создание простого MCP-сервера
- **Lab 02**: Реализация MCP-клиента
- **Lab 03**: Работа с Tools
- **Lab 04**: Работа с Resources
- **Lab 05**: Работа с Prompts
- **Lab 06**: Spring AI MCP Server
- **Lab 07**: Spring AI MCP Client
- **Lab 08**: Полная интеграция

## Требования

- Java 17+
- Maven 3.8+
- IntelliJ IDEA / VS Code
- Node.js 18+ (для MCP Inspector)
- Базовые знания Spring Boot (для модулей 7-8)

## Как использовать курс

1. Последовательно изучайте материалы модулей в папке `lectures/`
2. Каждая лекция содержит:
   - Теоретический материал с объяснениями
   - Примеры кода на Java с подробными комментариями
   - Mindmap для визуализации структуры
   - PlantUML диаграммы для понимания архитектуры
3. Выполняйте соответствующие лабораторные работы из папки `labs/`
4. Используйте примеры кода из папки `examples/`

## Визуализация диаграмм

Для просмотра PlantUML диаграмм используйте:

- **VS Code**: установите расширение "PlantUML"
- **IntelliJ IDEA**: встроенная поддержка PlantUML
- **Online**: https://www.plantuml.com/plantuml/uml/

## Дополнительные ресурсы

- [Официальная документация MCP](https://modelcontextprotocol.io/)
- [Спецификация протокола](https://modelcontextprotocol.io/specification/)
- [MCP Java SDK на GitHub](https://github.com/modelcontextprotocol/java-sdk)
- [Spring AI MCP Reference](https://docs.spring.io/spring-ai/reference/api/mcp/mcp-overview.html)
- [MCP Inspector](https://github.com/modelcontextprotocol/inspector)

## Прогресс курса

- ✅ Модуль 1: Введение в MCP
- ✅ Модуль 2: MCP-протокол
- 🔄 Модуль 3: MCP SDK на Java (в разработке)
- 🔄 Модуль 4-8: Скоро будут добавлены

## Авторы

Курс подготовлен для глубокого изучения Model Context Protocol в Java-экосистеме.

## Обратная связь

Если вы найдете ошибки или у вас есть предложения по улучшению курса, пожалуйста, сообщите об этом.

## Лицензия

Материалы курса предоставляются для образовательных целей.
