
# Модуль 1 - Диаграмма взаимодействия ролей
roles_diagram = """@startuml
!theme plain

title Взаимодействие компонентов MCP: Сценарий запроса к БД

actor "Пользователь" as User
participant "HOST\\n(Claude Desktop)" as Host
participant "CLIENT\\n(MCP Connector)" as Client
participant "SERVER\\n(Database MCP)" as Server
database "PostgreSQL" as DB

User -> Host : "Покажи продажи за 2024 год"
activate Host

Host -> Client : initialize connection
activate Client

Client -> Server : initialize(capabilities)
activate Server
Server --> Client : server capabilities\\n{tools, resources}
deactivate Server

Client --> Host : connection established
deactivate Client

Host -> Host : LLM анализирует запрос\\nи определяет нужные tools

Host -> Client : list_tools()
activate Client

Client -> Server : tools/list
activate Server
Server --> Client : [get_sales, get_customers,\\nget_products, ...]
deactivate Server

Client --> Host : available tools
deactivate Client

Host -> Host : LLM выбирает tool:\\nget_sales(year=2024)

Host -> User : "AI хочет выполнить запрос к БД.\\nРазрешить?"
User -> Host : "Да"

Host -> Client : call_tool("get_sales", {year: 2024})
activate Client

Client -> Server : tools/call\\n{name: "get_sales",\\narguments: {year: 2024}}
activate Server

Server -> DB : SELECT * FROM sales\\nWHERE year = 2024
activate DB
DB --> Server : результаты запроса\\n(1000 строк)
deactivate DB

Server --> Client : tool result\\n{content: sales_data}
deactivate Server

Client --> Host : execution result
deactivate Client

Host -> Host : LLM форматирует ответ\\nна основе данных

Host -> User : "Продажи за 2024 год:\\nQ1: 1.2M руб\\nQ2: 1.5M руб\\nQ3: 1.8M руб\\nQ4: 2.1M руб\\nИтого: 6.6M руб"
deactivate Host

note over Host, Server
  **Ключевые моменты:**
  - HOST управляет общим workflow
  - CLIENT обеспечивает коммуникацию
  - SERVER выполняет бизнес-логику
  - Пользователь контролирует операции
end note

@enduml
"""

with open("mcp-java-course/lectures/module-01-introduction/diagrams/roles.puml", "w", encoding="utf-8") as f:
    f.write(roles_diagram)

print("✓ Файл создан: module-01-introduction/diagrams/roles.puml")
