
# Модуль 1 - Диаграмма архитектуры
architecture_diagram = """@startuml
!define RECTANGLE class

skinparam componentStyle rectangle
skinparam backgroundColor #FEFEFE
skinparam component {
    BackgroundColor<<host>> LightBlue
    BackgroundColor<<client>> LightGreen
    BackgroundColor<<server>> LightYellow
    BorderColor Black
    ArrowColor DarkBlue
    FontSize 12
}

title Архитектура Model Context Protocol

package "HOST (LLM Application)" <<host>> {
    [User Interface] as UI
    [LLM Engine] as LLM
    [MCP Client] as Client <<client>>
}

package "MCP Servers Ecosystem" {
    [Database Server] as DB <<server>>
    [Filesystem Server] as FS <<server>>
    [Web Search Server] as WS <<server>>
    [Custom Server] as CS <<server>>
}

UI --> LLM : "user query"
LLM --> Client : "request tools"
Client --> DB : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> FS : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> WS : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> CS : "MCP Protocol\\n(JSON-RPC 2.0)"

note right of Client
  **Client Responsibilities:**
  - Connection management
  - Capability negotiation
  - Request/Response handling
  - Session lifecycle
  - Error handling
end note

note bottom of DB
  **Server Capabilities:**
  - Tools (actions)
  - Resources (data)
  - Prompts (templates)
  - Logging
  - Sampling
end note

note left of UI
  **Host Responsibilities:**
  - User interaction
  - LLM coordination
  - Security & consent
  - Lifecycle management
end note

@enduml
"""

with open("mcp-java-course/lectures/module-01-introduction/diagrams/architecture.puml", "w", encoding="utf-8") as f:
    f.write(architecture_diagram)

print("✓ Файл создан: module-01-introduction/diagrams/architecture.puml")
