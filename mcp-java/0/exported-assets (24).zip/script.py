
import os

# Создаем базовую структуру директорий
base_dirs = [
    "mcp-java-course/lectures/module-01-introduction/diagrams",
    "mcp-java-course/lectures/module-02-protocol/diagrams",
    "mcp-java-course/lectures/module-03-java-sdk/diagrams",
    "mcp-java-course/lectures/module-04-debugging/diagrams",
    "mcp-java-course/lectures/module-05-llm-host/diagrams",
    "mcp-java-course/lectures/module-06-model-integration/diagrams",
    "mcp-java-course/lectures/module-07-spring-ai/diagrams",
    "mcp-java-course/lectures/module-08-practice",
    "mcp-java-course/labs/lab-01-simple-server/solution",
    "mcp-java-course/labs/lab-02-client/solution",
    "mcp-java-course/labs/lab-03-tools/solution",
    "mcp-java-course/labs/lab-04-resources/solution",
    "mcp-java-course/labs/lab-05-prompts/solution",
    "mcp-java-course/labs/lab-06-spring-server/solution",
    "mcp-java-course/labs/lab-07-spring-client/solution",
    "mcp-java-course/labs/lab-08-full-integration/solution",
    "mcp-java-course/examples/src/main/java/com/example/mcp",
]

for dir_path in base_dirs:
    os.makedirs(dir_path, exist_ok=True)

print("Структура директорий создана успешно")
print("\nСоздано директорий:", len(base_dirs))
