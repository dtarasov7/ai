
# Модуль 1 - Лекция
module01_lecture = """# Модуль 1: Введение в Model Context Protocol

## Что такое MCP (Model Context Protocol)

Model Context Protocol (MCP) — это открытый стандартизированный протокол, который обеспечивает бесшовную интеграцию между LLM-приложениями и внешними источниками данных и инструментами. Протокол был разработан Anthropic и предоставляет универсальный способ для AI-моделей взаимодействовать с внешним миром через согласованный интерфейс.

### Основная идея

MCP решает проблему фрагментированной интеграции AI-систем. Вместо того чтобы создавать отдельные интеграции для каждой комбинации LLM и источника данных, MCP предлагает единый протокол, который работает везде.

**Аналогия**: Представьте MCP как USB-порт для AI. Точно так же, как USB стандартизировал подключение периферийных устройств к компьютерам, MCP стандартизирует подключение AI-моделей к данным и инструментам.

### Ключевые возможности MCP

MCP позволяет приложениям:

- **Делиться контекстной информацией** с языковыми моделями
- **Предоставлять инструменты и возможности** AI-системам
- **Строить композиционные интеграции** и рабочие процессы

### Основной протокол

MCP базируется на следующих принципах:

- **Формат сообщений**: JSON-RPC 2.0
- **Соединения**: Stateful (с сохранением состояния)
- **Согласование возможностей**: Между сервером и клиентом

## Роль MCP в экосистеме LLM

### Проблема без MCP

Традиционно, для интеграции LLM с внешними системами требуется создавать отдельную интеграцию для каждой пары "приложение-источник данных". Это приводит к:

- Дублированию кода
- Сложности поддержки
- Несовместимости между решениями
- Высокой стоимости разработки

### Решение с MCP

MCP создает единый стандарт взаимодействия, который:

- Уменьшает сложность интеграции
- Обеспечивает переиспользование компонентов
- Создает экосистему совместимых инструментов
- Ускоряет разработку AI-приложений

### Применение в экосистеме

MCP используется для:

1. **AI-powered IDE** — интеграция с системами контроля версий, базами кодов
2. **Чат-интерфейсы** — доступ к корпоративным базам данных
3. **Кастомные AI-workflow** — автоматизация бизнес-процессов
4. **Agentic системы** — построение автономных агентов с доступом к инструментам

## Архитектура: клиент, сервер, хост

### Три основные роли

MCP определяет три ключевые роли в своей архитектуре:

#### 1. Host (Хост)

**Определение**: LLM-приложение, которое инициирует соединения.

**Примеры**:
- Claude Desktop
- IDE (Cursor, VS Code с расширениями)
- Custom AI-приложения

**Ответственность**:
- Управление жизненным циклом приложения
- Отправка запросов к LLM
- Управление пользовательским интерфейсом

```java
// Пример: Host инициирует работу с MCP
public class AIApplicationHost {
    
    private final ChatClient chatClient;
    private final McpClient mcpClient;
    
    /**
     * Конструктор хоста AI-приложения.
     * Хост управляет взаимодействием между пользователем, LLM и MCP-серверами.
     * 
     * @param chatClient клиент для взаимодействия с LLM
     * @param mcpClient клиент для подключения к MCP-серверам
     */
    public AIApplicationHost(ChatClient chatClient, McpClient mcpClient) {
        this.chatClient = chatClient;
        this.mcpClient = mcpClient;
    }
    
    /**
     * Обработка пользовательского запроса.
     * Хост координирует получение дополнительных возможностей через MCP
     * и отправку расширенного запроса в LLM.
     */
    public String processUserQuery(String query) {
        // Получаем доступные инструменты от MCP-серверов
        List<Tool> tools = mcpClient.listTools();
        
        // Отправляем запрос в LLM с доступными инструментами
        return chatClient.call(query, tools);
    }
}
```

#### 2. Client (Клиент)

**Определение**: Коннектор внутри host-приложения, который управляет соединением с MCP-серверами.

**Ответственность**:
- Установление соединения с серверами
- Согласование возможностей (capability negotiation)
- Управление сессией
- Отправка запросов к серверам

```java
// Пример: MCP Client устанавливает соединение с сервером
public class SimpleMcpClient {
    
    private McpSession session;
    private InitializeResult serverCapabilities;
    
    /**
     * Инициализация соединения с MCP-сервером.
     * Клиент отправляет свои возможности и получает возможности сервера.
     * 
     * @param transport транспортный механизм (STDIO, HTTP, SSE)
     * @throws Exception если инициализация не удалась
     */
    public void connect(McpTransport transport) throws Exception {
        // Создаем сессию
        this.session = McpSession.create(transport);
        
        // Отправляем запрос инициализации с нашими возможностями
        InitializeRequest request = InitializeRequest.builder()
            .protocolVersion("2024-11-05")
            .clientInfo(Implementation.builder()
                .name("my-mcp-client")
                .version("1.0.0")
                .build())
            .capabilities(ClientCapabilities.builder()
                .roots(RootsCapability.builder().listChanged(true).build())
                .sampling(SamplingCapability.builder().build())
                .build())
            .build();
        
        // Получаем возможности сервера
        this.serverCapabilities = session.initialize(request);
        
        System.out.println("Подключено к серверу: " + 
            serverCapabilities.serverInfo().name());
    }
    
    /**
     * Получение списка доступных инструментов с сервера.
     * 
     * @return список инструментов, предоставляемых сервером
     */
    public List<Tool> listTools() {
        if (serverCapabilities.capabilities().tools() == null) {
            return Collections.emptyList();
        }
        
        ListToolsResult result = session.listTools();
        return result.tools();
    }
}
```

#### 3. Server (Сервер)

**Определение**: Сервис, который предоставляет контекст и возможности клиентам.

**Примеры**:
- Database MCP Server (доступ к БД)
- Filesystem MCP Server (операции с файлами)
- Web Search MCP Server (поиск в интернете)
- Custom Business Logic Server

**Ответственность**:
- Регистрация и предоставление возможностей (tools, resources, prompts)
- Обработка запросов от клиентов
- Управление доступом к данным

```java
// Пример: MCP Server предоставляет инструменты
public class WeatherMcpServer {
    
    /**
     * Настройка MCP-сервера с инструментами для получения погоды.
     * Сервер регистрирует свои возможности и обработчики.
     */
    public McpServer setupServer() {
        // Создаем спецификацию инструмента "получить погоду"
        Tool weatherTool = Tool.builder()
            .name("get_weather")
            .description("Получить текущую погоду для указанного города")
            .inputSchema(JsonSchema.builder()
                .type("object")
                .properties(Map.of(
                    "city", JsonSchema.builder()
                        .type("string")
                        .description("Название города")
                        .build(),
                    "units", JsonSchema.builder()
                        .type("string")
                        .enumValues(List.of("celsius", "fahrenheit"))
                        .description("Единицы измерения температуры")
                        .build()
                ))
                .required(List.of("city"))
                .build())
            .build();
        
        // Создаем сервер с возможностями
        return McpServer.builder()
            .serverInfo(Implementation.builder()
                .name("weather-server")
                .version("1.0.0")
                .build())
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder()
                    .listChanged(true)
                    .build())
                .build())
            // Регистрируем обработчик вызова инструмента
            .toolsProvider(() -> List.of(weatherTool))
            .callToolHandler(this::handleToolCall)
            .build();
    }
    
    /**
     * Обработчик вызова инструмента.
     * Выполняет запрошенную операцию и возвращает результат.
     * 
     * @param request запрос на вызов инструмента
     * @return результат выполнения инструмента
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        if ("get_weather".equals(request.params().name())) {
            // Извлекаем параметры
            String city = request.params().arguments().get("city").asText();
            String units = request.params().arguments()
                .getOrDefault("units", JsonNode.of("celsius")).asText();
            
            // Выполняем бизнес-логику (здесь - заглушка)
            String weather = fetchWeatherData(city, units);
            
            // Возвращаем результат
            return CallToolResult.builder()
                .content(List.of(TextContent.builder()
                    .text(weather)
                    .build()))
                .build();
        }
        
        throw new IllegalArgumentException("Unknown tool: " + request.params().name());
    }
    
    /**
     * Получение данных о погоде (заглушка для примера).
     */
    private String fetchWeatherData(String city, String units) {
        return String.format("Погода в %s: 22°%s, облачно", 
            city, 
            "celsius".equals(units) ? "C" : "F");
    }
}
```

## Уровни протокола

MCP состоит из двух основных уровней:

### Data Layer (Уровень данных)

- Определяет JSON-RPC протокол для коммуникации клиент-сервер
- Управление жизненным циклом
- Основные примитивы: tools, resources, prompts, notifications

### Transport Layer (Транспортный уровень)

- Управляет каналами связи и аутентификацией
- Устанавливает соединения
- Обрамление сообщений (message framing)
- Поддерживает: STDIO, HTTP/SSE

## Принципы безопасности

MCP разработан с учетом следующих принципов безопасности:

### Согласие и контроль пользователя

- Пользователь должен явно дать согласие на доступ к данным и операции
- Пользователь сохраняет контроль над тем, какие данные передаются
- Необходим понятный UI для авторизации действий

### Приватность данных

- Хост должен получить явное согласие пользователя перед передачей данных серверу
- Данные пользователя должны быть защищены соответствующими средствами контроля доступа

### Безопасность инструментов

- Tools представляют собой выполнение произвольного кода и требуют осторожности
- Хост должен получить явное согласие пользователя перед вызовом любого tool
- Пользователь должен понимать, что делает каждый tool

### Контроль LLM Sampling

- Пользователь должен явно одобрить любые запросы на sampling
- Пользователь должен контролировать, какие результаты видит сервер

## Резюме модуля

В этом модуле вы узнали:

✅ MCP — это открытый протокол для стандартизированной интеграции LLM с внешними данными и инструментами  
✅ MCP решает проблему фрагментированной интеграции в AI-экосистеме  
✅ Архитектура MCP включает три роли: Host, Client, Server  
✅ Протокол базируется на JSON-RPC 2.0 и поддерживает множество транспортов  
✅ Безопасность и контроль пользователя — основополагающие принципы MCP  

## Дополнительные материалы

- [Официальная спецификация MCP](https://modelcontextprotocol.io/specification/)
- [MCP Architecture Documentation](https://modelcontextprotocol.io/docs/learn/architecture)
"""

with open("mcp-java-course/lectures/module-01-introduction/lecture.md", "w", encoding="utf-8") as f:
    f.write(module01_lecture)

print("✓ Модуль 1: Лекция создана")
