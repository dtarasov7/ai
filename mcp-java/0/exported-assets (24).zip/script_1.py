
# README.md - главный файл курса
readme_content = """# Курс: Model Context Protocol (MCP) и Java

Полноценный обучающий курс по работе с Model Context Protocol в экосистеме Java.

## О курсе

Model Context Protocol (MCP) — это открытый протокол, разработанный Anthropic, который обеспечивает стандартизированный способ интеграции LLM-приложений с внешними источниками данных и инструментами.

## Структура курса

### Теоретические модули (lectures/)

1. **Модуль 1: Введение в MCP**
   - Основы протокола
   - Архитектура и роли
   - Применение в экосистеме LLM

2. **Модуль 2: MCP-протокол**
   - Транспортный уровень
   - Типы сообщений
   - Возможности клиента и сервера

3. **Модуль 3: MCP SDK на Java**
   - Обзор библиотеки
   - Реализация клиента
   - Реализация сервера

4. **Модуль 4: Отладка и мониторинг**
   - Логирование
   - Диагностика проблем
   - MCP Inspector

5. **Модуль 5: Взаимодействие с LLM-хостом**
   - Архитектура взаимодействия
   - Конфигурация хостов

6. **Модуль 6: Интеграция с моделями**
   - Модели с fine-tuning
   - Модели без fine-tuning

7. **Модуль 7: Spring AI и MCP**
   - Spring Boot стартеры
   - Аннотации MCP
   - Конфигурация

8. **Модуль 8: Практика**
   - Комплексные примеры
   - Best practices

### Практические лабораторные работы (labs/)

- **Lab 01**: Создание простого MCP-сервера
- **Lab 02**: Реализация MCP-клиента
- **Lab 03**: Работа с Tools
- **Lab 04**: Работа с Resources
- **Lab 05**: Работа с Prompts
- **Lab 06**: Spring AI MCP Server
- **Lab 07**: Spring AI MCP Client
- **Lab 08**: Полная интеграция

## Требования

- Java 17+
- Maven 3.8+
- IntelliJ IDEA / VS Code
- Node.js (для MCP Inspector)
- Базовые знания Spring Boot (для модулей 7-8)

## Как использовать курс

1. Последовательно изучайте материалы модулей в папке `lectures/`
2. Выполняйте соответствующие лабораторные работы из папки `labs/`
3. Используйте примеры кода из папки `examples/`
4. Изучайте диаграммы PlantUML и mindmap для визуализации концепций

## Дополнительные ресурсы

- [Официальная документация MCP](https://modelcontextprotocol.io/)
- [MCP Java SDK](https://github.com/modelcontextprotocol/java-sdk)
- [Spring AI MCP Reference](https://docs.spring.io/spring-ai/reference/api/mcp/mcp-overview.html)

## Авторы

Курс подготовлен для изучения Model Context Protocol в Java-экосистеме.

## Лицензия

Материалы курса предоставляются для образовательных целей.
"""

with open("mcp-java-course/README.md", "w", encoding="utf-8") as f:
    f.write(readme_content)

print("✓ README.md создан")
