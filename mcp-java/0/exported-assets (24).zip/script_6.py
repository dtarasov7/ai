
# Добавляю продолжение лекции модуля 2
module02_lecture_continuation = """
#### Пример обработки ошибок

```java
import io.modelcontextprotocol.sdk.McpError;

public class ErrorHandlingExample {
    
    /**
     * Обработка ошибок при взаимодействии с MCP-сервером.
     * Важно различать сетевые ошибки, ошибки протокола
     * и ошибки бизнес-логики.
     */
    public void callToolWithErrorHandling(McpSession session) {
        try {
            // Попытка вызвать инструмент
            CallToolRequest request = CallToolRequest.builder()
                .params(CallToolParams.builder()
                    .name("non_existent_tool")
                    .build())
                .build();
            
            CallToolResult result = session.callTool(request);
            System.out.println("Успех: " + result.content());
            
        } catch (McpError e) {
            // MCP protocol error
            handleMcpError(e);
        } catch (IOException e) {
            // Transport/network error
            System.err.println("Ошибка соединения: " + e.getMessage());
        } catch (Exception e) {
            // Unexpected error
            System.err.println("Неожиданная ошибка: " + e.getMessage());
        }
    }
    
    /**
     * Детальная обработка MCP-ошибок по кодам.
     */
    private void handleMcpError(McpError error) {
        int code = error.getCode();
        String message = error.getMessage();
        
        switch (code) {
            case -32601 -> System.err.println("Метод не найден: " + message);
            case -32602 -> System.err.println("Невалидные параметры: " + message);
            case -32603 -> System.err.println("Внутренняя ошибка сервера: " + message);
            default -> System.err.println("MCP ошибка [" + code + "]: " + message);
        }
        
        // Вывод дополнительных данных об ошибке
        if (error.getData() != null) {
            System.err.println("Детали: " + error.getData());
        }
    }
}
```

### 4. Notification (Уведомление)

Сообщение, которое не требует ответа. Используется для асинхронных событий.

#### Структура Notification

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "task-123",
    "progress": 50,
    "total": 100
  }
}
```

#### Пример отправки Notification

```java
public class NotificationExample {
    
    /**
     * Отправка уведомления о прогрессе выполнения задачи.
     * Notification не ожидает ответа от получателя.
     */
    public void sendProgressNotification(
            McpSession session, 
            String progressToken,
            int progress, 
            int total) {
        
        // Формируем уведомление о прогрессе
        ProgressNotification notification = ProgressNotification.builder()
            .method("notifications/progress")
            .params(ProgressParams.builder()
                .progressToken(progressToken)
                .progress(progress)
                .total(total)
                .build())
            .build();
        
        // Отправляем без ожидания ответа
        session.sendNotification(notification);
        
        System.out.println("Прогресс отправлен: " + progress + "/" + total);
    }
}
```

## Резюме модуля

В этом модуле вы изучили:

✅ **Transport layer**: STDIO и HTTP/SSE транспорты  
✅ **Message types**: Request, Response, Error, Notification  
✅ **Client capabilities**: Roots, Sampling, Elicitation, Experimental  
✅ **Server capabilities**: Prompts, Resources, Tools, Logging, Completions  
✅ **Utilities**: Cancellation, Progress, Ping  
✅ **Inspector**: Инструмент для отладки MCP-серверов  

## Дополнительные материалы

- [MCP Protocol Specification](https://modelcontextprotocol.io/specification/)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)
- [MCP Inspector Documentation](https://github.com/modelcontextprotocol/inspector)
"""

# Читаем существующий файл и добавляем продолжение
with open("mcp-java-course/lectures/module-02-protocol/lecture.md", "r", encoding="utf-8") as f:
    existing_content = f.read()

with open("mcp-java-course/lectures/module-02-protocol/lecture.md", "w", encoding="utf-8") as f:
    f.write(existing_content + module02_lecture_continuation)

print("✓ Модуль 2: Лекция дополнена")
