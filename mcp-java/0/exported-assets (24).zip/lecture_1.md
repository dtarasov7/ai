# Модуль 2: MCP-протокол

## Transport (stdio, HTTP/SSE)

MCP поддерживает несколько транспортных механизмов для обмена сообщениями между клиентом и сервером. Транспортный уровень отвечает за установление соединения, фреймирование сообщений и безопасную коммуникацию.

### STDIO Transport

**STDIO** (Standard Input/Output) транспорт использует стандартные потоки ввода-вывода для прямой коммуникации между процессами на одной машине.

#### Характеристики STDIO

- ✅ **Производительность**: Оптимальная, без сетевых накладных расходов
- ✅ **Простота**: Легко реализовать и отлаживать
- ✅ **Локальность**: Только для процессов на одной машине
- ❌ **Ограничение**: Не подходит для удаленного доступа

#### Пример STDIO Transport в Java

```java
import io.modelcontextprotocol.sdk.transport.StdioTransport;
import io.modelcontextprotocol.sdk.McpServer;

public class StdioServerExample {

    /**
     * Запуск MCP-сервера с STDIO транспортом.
     * STDIO идеален для локальных интеграций, например,
     * когда Claude Desktop запускает сервер как дочерний процесс.
     */
    public static void main(String[] args) {
        // Создаем транспорт, использующий stdin/stdout
        StdioTransport transport = new StdioTransport();

        // Настраиваем сервер
        McpServer server = McpServer.builder()
            .serverInfo(Implementation.builder()
                .name("stdio-example-server")
                .version("1.0.0")
                .build())
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder().build())
                .build())
            .build();

        // Запускаем сервер с STDIO транспортом
        server.connect(transport);

        System.err.println("Сервер запущен с STDIO транспортом");
        // Примечание: System.err используется для логов,
        // т.к. stdout зарезервирован для MCP-протокола
    }
}
```

#### Конфигурация STDIO для Claude Desktop

```json
{
  "mcpServers": {
    "my-java-server": {
      "command": "java",
      "args": [
        "-jar",
        "/path/to/my-server.jar"
      ]
    }
  }
}
```

### HTTP/SSE Transport

**HTTP** транспорт использует HTTP POST для отправки сообщений от клиента к серверу, с опциональной поддержкой **Server-Sent Events (SSE)** для потоковой передачи.

#### Характеристики HTTP/SSE

- ✅ **Удаленный доступ**: Работает через сеть
- ✅ **Стандартная аутентификация**: Bearer tokens, API keys, custom headers
- ✅ **Потоковая передача**: SSE для real-time обновлений
- ✅ **Масштабируемость**: Можно использовать load balancers
- ⚠️ **Сложность**: Требует настройки сервера и аутентификации

#### Пример HTTP Transport в Java

```java
import io.modelcontextprotocol.sdk.transport.HttpTransport;
import io.modelcontextprotocol.sdk.McpServer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/mcp")
public class HttpMcpServerController {

    private final McpServer mcpServer;

    /**
     * Конструктор для HTTP-based MCP сервера.
     * HTTP транспорт позволяет удаленным клиентам подключаться к серверу.
     * 
     * @param mcpServer настроенный MCP-сервер
     */
    public HttpMcpServerController(McpServer mcpServer) {
        this.mcpServer = mcpServer;
    }

    /**
     * Endpoint для обработки MCP-запросов через HTTP POST.
     * Клиент отправляет JSON-RPC запросы, сервер возвращает ответы.
     * 
     * @param request JSON-RPC запрос в виде строки
     * @param authorization токен аутентификации из заголовка
     * @return JSON-RPC ответ
     */
    @PostMapping(value = "/messages", 
                 consumes = "application/json", 
                 produces = "application/json")
    public String handleMessage(
            @RequestBody String request,
            @RequestHeader(value = "Authorization", required = false) 
            String authorization) {

        // Проверка аутентификации
        if (!isValidToken(authorization)) {
            return createErrorResponse("Unauthorized");
        }

        // Обработка MCP-запроса
        return mcpServer.handleRequest(request);
    }

    /**
     * SSE endpoint для потоковых уведомлений от сервера к клиенту.
     * Используется для асинхронных событий: прогресс, логи, уведомления.
     * 
     * @return поток Server-Sent Events
     */
    @GetMapping(value = "/sse", produces = "text/event-stream")
    public SseEmitter subscribeToEvents(
            @RequestHeader(value = "Authorization", required = false) 
            String authorization) {

        if (!isValidToken(authorization)) {
            throw new UnauthorizedException("Invalid token");
        }

        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);

        // Регистрируем emitter для получения событий от сервера
        mcpServer.registerEventEmitter(emitter);

        return emitter;
    }

    /**
     * Валидация токена аутентификации.
     * В production используйте OAuth2, JWT или другие стандартные методы.
     */
    private boolean isValidToken(String authorization) {
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            return false;
        }
        String token = authorization.substring(7);
        return token.equals(System.getenv("MCP_API_KEY"));
    }

    /**
     * Создание JSON-RPC error response.
     */
    private String createErrorResponse(String message) {
        return String.format(
            "{\"jsonrpc\":\"2.0\",\"error\":{\"code\":-32000,\"message\":\"%s\"},\"id\":null}",
            message
        );
    }
}
```

### Сравнение транспортов

| Характеристика | STDIO | HTTP/SSE |
|----------------|-------|----------|
| **Расположение** | Только локально | Удаленно и локально |
| **Производительность** | Отличная | Хорошая (сетевая задержка) |
| **Аутентификация** | Не требуется | OAuth, Bearer tokens, API keys |
| **Сложность** | Низкая | Средняя/Высокая |
| **Use case** | Desktop приложения | Web сервисы, микросервисы |
| **Масштабируемость** | Ограничена | Высокая |

## Message Types

MCP использует JSON-RPC 2.0 для обмена сообщениями. Существует четыре основных типа сообщений:

### 1. Request (Запрос)

Сообщение, требующее ответа от получателя.

#### Структура Request

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "method": "tools/call",
  "params": {
    "name": "get_weather",
    "arguments": {
      "city": "Moscow"
    }
  }
}
```

#### Поля Request

- **jsonrpc**: Версия протокола (всегда "2.0")
- **id**: Уникальный идентификатор запроса (string | number)
- **method**: Имя вызываемого метода
- **params**: Параметры метода (optional)

#### Пример отправки Request в Java

```java
import io.modelcontextprotocol.sdk.schema.*;

public class RequestExample {

    /**
     * Создание и отправка запроса на вызов инструмента.
     * Request всегда имеет id и ожидает Response.
     */
    public void sendToolCallRequest(McpSession session) {
        // Формируем параметры вызова инструмента
        Map<String, Object> arguments = Map.of(
            "city", "Moscow",
            "units", "celsius"
        );

        // Создаем запрос
        CallToolRequest request = CallToolRequest.builder()
            .method("tools/call")
            .params(CallToolParams.builder()
                .name("get_weather")
                .arguments(arguments)
                .build())
            .build();

        // Отправляем запрос и получаем ответ
        CallToolResult result = session.callTool(request);

        System.out.println("Результат: " + result.content());
    }
}
```

### 2. Response (Ответ)

Ответ на Request, содержащий либо результат, либо ошибку.

#### Структура Success Response

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Температура в Москве: 5°C, облачно"
      }
    ]
  }
}
```

#### Пример обработки Response

```java
public class ResponseExample {

    /**
     * Обработка ответа от MCP-сервера.
     * Response всегда связан с Request через id.
     */
    public void handleResponse(CallToolResult result) {
        // Проверяем наличие контента
        if (result.content() == null || result.content().isEmpty()) {
            System.out.println("Пустой ответ");
            return;
        }

        // Обрабатываем каждый элемент контента
        for (var content : result.content()) {
            if (content instanceof TextContent textContent) {
                System.out.println("Текст: " + textContent.text());
            } else if (content instanceof ImageContent imageContent) {
                System.out.println("Изображение: " + imageContent.data());
            } else if (content instanceof ResourceContent resourceContent) {
                System.out.println("Ресурс: " + resourceContent.uri());
            }
        }

        // Проверяем флаг isError
        if (result.isError() != null && result.isError()) {
            System.err.println("Инструмент вернул ошибку");
        }
    }
}
```

### 3. Error (Ошибка)

Специальный тип Response, указывающий на ошибку выполнения.

#### Структура Error Response

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": {
      "method": "unknown/method"
    }
  }
}
```

#### Стандартные коды ошибок JSON-RPC

| Код | Значение | Описание |
|-----|----------|----------|
| -32700 | Parse error | Невалидный JSON |
| -32600 | Invalid Request | Невалидная структура запроса |
| -32601 | Method not found | Метод не существует |
| -32602 | Invalid params | Невалидные параметры |
| -32603 | Internal error | Внутренняя ошибка сервера |
| -32000 to -32099 | Server error | Серверные ошибки (custom) |

