
# Модуль 1 - Диаграммы
architecture_diagram = """@startuml
!define RECTANGLE class

skinparam componentStyle rectangle
skinparam backgroundColor #FEFEFE
skinparam component {
    BackgroundColor<<host>> LightBlue
    BackgroundColor<<client>> LightGreen
    BackgroundColor<<server>> LightYellow
    BorderColor Black
    ArrowColor DarkBlue
}

package "HOST (LLM Application)" <<host>> {
    [User Interface] as UI
    [LLM Engine] as LLM
    [MCP Client] as Client <<client>>
}

package "MCP Servers" {
    [Database Server] as DB <<server>>
    [Filesystem Server] as FS <<server>>
    [Web Search Server] as WS <<server>>
    [Custom Server] as CS <<server>>
}

UI --> LLM : "user query"
LLM --> Client : "request tools"
Client --> DB : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> FS : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> WS : "MCP Protocol\\n(JSON-RPC 2.0)"
Client --> CS : "MCP Protocol\\n(JSON-RPC 2.0)"

note right of Client
  **Client Responsibilities:**
  - Connection management
  - Capability negotiation
  - Request/Response handling
  - Session lifecycle
end note

note bottom of DB
  **Server Capabilities:**
  - Tools
  - Resources
  - Prompts
  - Sampling
end note

@enduml
"""

roles_diagram = """@startuml
!theme plain

actor User
participant "HOST\\n(Claude Desktop)" as Host
participant "CLIENT\\n(MCP Connector)" as Client
participant "SERVER\\n(Database MCP)" as Server
database "PostgreSQL" as DB

User -> Host : "Покажи продажи за 2024"
activate Host

Host -> Client : initialize connection
activate Client

Client -> Server : initialize(capabilities)
activate Server
Server --> Client : server capabilities
deactivate Server

Client --> Host : connection established
deactivate Client

Host -> Host : LLM анализирует запрос
Host -> Client : list_tools()
activate Client

Client -> Server : tools/list
activate Server
Server --> Client : [get_sales, get_customers, ...]
deactivate Server

Client --> Host : available tools
deactivate Client

Host -> Host : LLM выбирает tool:\\nget_sales(year=2024)

Host -> Client : call_tool(get_sales, {year: 2024})
activate Client

Client -> Server : tools/call\\n{name: "get_sales",\\narguments: {year: 2024}}
activate Server

Server -> DB : SELECT * FROM sales\\nWHERE year = 2024
activate DB
DB --> Server : результаты запроса
deactivate DB

Server --> Client : tool result\\n(sales data)
deactivate Server

Client --> Host : execution result
deactivate Client

Host -> Host : LLM форматирует ответ
Host -> User : "Продажи за 2024:\\nQ1: 1.2M\\nQ2: 1.5M\\n..."
deactivate Host

note over Host, Server
  **Роли в MCP:**
  - HOST: управляет приложением и UI
  - CLIENT: коннектор внутри Host
  - SERVER: предоставляет возможности
end note

@enduml
"""

with open("mcp-java-course/lectures/module-01-introduction/diagrams/architecture.puml", "w", encoding="utf-8") as f:
    f.write(architecture_diagram)

with open("mcp-java-course/lectures/module-01-introduction/diagrams/roles.puml", "w", encoding="utf-8") as f:
    f.write(roles_diagram)

print("✓ Модуль 1: Диаграммы созданы (architecture.puml, roles.puml)")
