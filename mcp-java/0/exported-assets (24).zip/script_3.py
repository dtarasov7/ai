
# Модуль 1 - Mindmap
module01_mindmap = """@startmindmap
* Model Context Protocol
** Что такое MCP
*** Открытый протокол
*** Стандартизация интеграции
*** LLM ↔ External Data
*** Разработан Anthropic
** Применение
*** AI-powered IDE
*** Чат-интерфейсы
*** Custom AI workflows
*** Agentic системы
** Архитектура
*** Host
**** LLM Application
**** UI Management
**** Lifecycle Control
*** Client
**** Connection Manager
**** Capability Negotiation
**** Session Management
*** Server
**** Tools Provider
**** Resources Provider
**** Prompts Provider
** Протокол
*** JSON-RPC 2.0
*** Stateful connections
*** Transport Layer
**** STDIO
**** HTTP/SSE
*** Data Layer
**** Tools
**** Resources
**** Prompts
** Безопасность
*** User Consent
*** Data Privacy
*** Tool Safety
*** LLM Sampling Control
@endmindmap
"""

with open("mcp-java-course/lectures/module-01-introduction/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module01_mindmap)

print("✓ Модуль 1: Mindmap создана")
