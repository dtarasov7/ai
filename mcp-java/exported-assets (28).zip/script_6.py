
# Lab 02 - Решение
lab02_solution = """package com.example.mcp.lab02;

import io.modelcontextprotocol.sdk.client.McpClient;
import io.modelcontextprotocol.sdk.client.StdioClientTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.util.List;
import java.util.Map;

/**
 * Lab 02 Solution: MCP-клиент для подключения к Calculator Server.
 * 
 * Демонстрирует:
 * - Создание STDIO клиента
 * - Подключение к серверу
 * - Получение списка инструментов
 * - Вызов инструментов с параметрами
 * - Обработку уведомлений
 */
public class CalculatorClient {
    
    private final McpClient client;
    
    /**
     * Создание клиента с STDIO транспортом.
     * 
     * @param serverJarPath путь к JAR-файлу сервера
     */
    public CalculatorClient(String serverJarPath) {
        // Создаем STDIO транспорт, который запустит сервер как дочерний процесс
        StdioClientTransport transport = StdioClientTransport.builder()
            .command("java")
            .args(List.of("-jar", serverJarPath))
            .build();
        
        // Создаем клиента
        this.client = McpClient.builder()
            .transport(transport)
            // Информация о нашем клиенте
            .clientInfo(Implementation.builder()
                .name("calculator-client")
                .version("1.0.0")
                .build())
            .build();
        
        // Настраиваем обработчики уведомлений
        setupNotificationHandlers();
    }
    
    /**
     * Настройка обработчиков для уведомлений от сервера.
     */
    private void setupNotificationHandlers() {
        // Обработчик логов от сервера
        client.setLogHandler((level, message, logger) -> {
            // Выбираем эмодзи в зависимости от уровня
            String emoji = switch (level) {
                case "error", "critical" -> "❌";
                case "warning" -> "⚠️";
                case "info" -> "ℹ️";
                case "debug" -> "🔍";
                default -> "📝";
            };
            
            System.out.printf("%s [%s] %s: %s\\n", 
                emoji, level.toUpperCase(), logger, message);
        });
        
        // Обработчик прогресса (если сервер будет отправлять)
        client.setProgressHandler((token, progress, total) -> {
            double percentage = (progress * 100.0) / total;
            System.out.printf("⏳ [PROGRESS] %s: %.1f%% (%d/%d)\\n",
                token, percentage, progress, total);
        });
    }
    
    /**
     * Подключение к серверу и инициализация.
     * 
     * @throws Exception если подключение не удалось
     */
    public void connect() throws Exception {
        System.out.println("🔌 Подключение к серверу...");
        
        // Выполняем handshake
        InitializeResult result = client.initialize();
        
        // Выводим информацию о сервере
        System.out.println("\\n✅ Подключено к серверу:");
        System.out.println("  Имя: " + result.serverInfo().name());
        System.out.println("  Версия: " + result.serverInfo().version());
        
        // Выводим capabilities сервера
        ServerCapabilities caps = result.capabilities();
        System.out.println("\\nВозможности сервера:");
        
        if (caps.tools() != null) {
            System.out.println("  ✓ Tools (инструменты)");
        }
        if (caps.resources() != null) {
            System.out.println("  ✓ Resources (ресурсы)");
        }
        if (caps.prompts() != null) {
            System.out.println("  ✓ Prompts (шаблоны)");
        }
        if (caps.logging() != null) {
            System.out.println("  ✓ Logging (логирование)");
        }
    }
    
    /**
     * Получение списка доступных инструментов.
     * 
     * @return список инструментов
     * @throws Exception если запрос не удался
     */
    public List<Tool> listTools() throws Exception {
        System.out.println("\\n📋 Получение списка инструментов...");
        
        ListToolsResult result = client.listTools();
        List<Tool> tools = result.tools();
        
        System.out.println("\\nДоступные инструменты:");
        for (int i = 0; i < tools.size(); i++) {
            Tool tool = tools.get(i);
            System.out.printf("  %d. %s - %s\\n", 
                i + 1, tool.name(), tool.description());
        }
        
        return tools;
    }
    
    /**
     * Тестирование инструмента сложения.
     * 
     * @return текстовый результат
     * @throws Exception если вызов не удался
     */
    public String testAdd() throws Exception {
        System.out.println("\\n➕ Тестирование calculator_add...");
        
        CallToolResult result = client.callTool(
            "calculator_add",
            Map.of("a", 10, "b", 25)
        );
        
        return extractTextResult(result);
    }
    
    /**
     * Тестирование инструмента умножения.
     * 
     * @return текстовый результат
     * @throws Exception если вызов не удался
     */
    public String testMultiply() throws Exception {
        System.out.println("\\n✖️ Тестирование calculator_multiply...");
        
        CallToolResult result = client.callTool(
            "calculator_multiply",
            Map.of("a", 7, "b", 8)
        );
        
        return extractTextResult(result);
    }
    
    /**
     * Тестирование инструмента получения времени.
     * 
     * @return текущее время
     * @throws Exception если вызов не удался
     */
    public String testGetTime() throws Exception {
        System.out.println("\\n⏰ Тестирование get_current_time...");
        
        CallToolResult result = client.callTool(
            "get_current_time",
            Map.of()  // Без параметров
        );
        
        return extractTextResult(result);
    }
    
    /**
     * Извлечение текстового результата из CallToolResult.
     * 
     * @param result результат вызова инструмента
     * @return текст из первого TextContent
     * @throws RuntimeException если результат пустой или содержит ошибку
     */
    private String extractTextResult(CallToolResult result) {
        // Проверяем на ошибку
        if (result.isError() != null && result.isError()) {
            throw new RuntimeException("Tool execution failed");
        }
        
        // Проверяем наличие контента
        if (result.content() == null || result.content().isEmpty()) {
            throw new RuntimeException("Empty result from tool");
        }
        
        // Извлекаем текст из первого элемента
        Content content = result.content().get(0);
        if (content instanceof TextContent textContent) {
            return textContent.text();
        }
        
        throw new RuntimeException("Unexpected content type: " + content.getClass());
    }
    
    /**
     * Закрытие соединения с сервером.
     */
    public void disconnect() {
        if (client != null) {
            try {
                client.close();
                System.out.println("\\n🔌 Соединение закрыто");
            } catch (Exception e) {
                System.err.println("⚠️ Ошибка при закрытии соединения: " + e.getMessage());
            }
        }
    }
    
    /**
     * Главный метод - запуск всех тестов.
     */
    public static void main(String[] args) {
        // Проверяем аргументы командной строки
        if (args.length == 0) {
            System.err.println("❌ Использование: java CalculatorClient <путь-к-server.jar>");
            System.err.println("\\nПример:");
            System.err.println("  java CalculatorClient ../lab01-simple-server/target/lab01-simple-server-1.0-SNAPSHOT.jar");
            System.exit(1);
        }
        
        String serverJarPath = args[0];
        CalculatorClient client = new CalculatorClient(serverJarPath);
        
        try {
            System.out.println("=================================");
            System.out.println("   Calculator MCP Client v1.0   ");
            System.out.println("=================================");
            
            // Подключаемся к серверу
            client.connect();
            
            // Получаем список инструментов
            client.listTools();
            
            // Тестируем все инструменты
            System.out.println("\\n=================================");
            System.out.println("   Тестирование инструментов    ");
            System.out.println("=================================");
            
            String addResult = client.testAdd();
            System.out.println("  Результат: " + addResult);
            
            String multiplyResult = client.testMultiply();
            System.out.println("  Результат: " + multiplyResult);
            
            String timeResult = client.testGetTime();
            System.out.println("  Результат: " + timeResult);
            
            // Итоги
            System.out.println("\\n=================================");
            System.out.println("✅ Все тесты пройдены успешно!");
            System.out.println("=================================");
            
        } catch (Exception e) {
            System.err.println("\\n❌ Ошибка выполнения:");
            System.err.println("   " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
            
        } finally {
            // Всегда закрываем соединение
            client.disconnect();
        }
    }
}
"""

lab02_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab02-client</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Maven Compiler Plugin -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>
            
            <!-- Exec Maven Plugin для удобного запуска -->
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.1.0</version>
                <configuration>
                    <mainClass>com.example.mcp.lab02.CalculatorClient</mainClass>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
"""

# Создаем директорию и записываем решение
os.makedirs("mcp-java-course/labs/lab-02-client/solution", exist_ok=True)

with open("mcp-java-course/labs/lab-02-client/solution/CalculatorClient.java", "w", encoding="utf-8") as f:
    f.write(lab02_solution)

with open("mcp-java-course/labs/lab-02-client/solution/pom.xml", "w", encoding="utf-8") as f:
    f.write(lab02_pom)

print("✓ Файл создан: labs/lab-02-client/solution/CalculatorClient.java")
print("✓ Файл создан: labs/lab-02-client/solution/pom.xml")
print("\n🎉 Сессия 2 завершена!")
print("\n📊 Статистика созданных файлов:")
print("  ✅ Модуль 2: lecture.md, mindmap, 4 диаграммы")
print("  ✅ Модуль 3: lecture.md, mindmap, 2 диаграммы")  
print("  ✅ Lab 01: README.md + полное решение")
print("  ✅ Lab 02: README.md + полное решение")
