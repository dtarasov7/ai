
# Lab 02 - Создание MCP-клиента
lab02_readme = """# Lab 02: Реализация MCP-клиента

## Цель работы

Создать MCP-клиента, который подключается к серверу из Lab 01 и вызывает его инструменты.

## Задачи

1. Создать STDIO клиента для подключения к Calculator Server
2. Реализовать обработчики уведомлений (progress, logs)
3. Вызвать все три инструмента сервера
4. Обработать возможные ошибки
5. Вывести результаты в консоль

## Предварительные требования

Выполните Lab 01 и соберите `lab01-simple-server-1.0-SNAPSHOT.jar`

## Шаг 1: Создание проекта

### pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab02-client</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
    </dependencies>
</project>
```

## Шаг 2: Создание класса клиента

Создайте файл `src/main/java/com/example/mcp/lab02/CalculatorClient.java`

### Задание

Реализуйте следующие методы:

```java
package com.example.mcp.lab02;

import io.modelcontextprotocol.sdk.client.McpClient;
import io.modelcontextprotocol.sdk.client.StdioClientTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.util.List;
import java.util.Map;

public class CalculatorClient {
    
    private final McpClient client;
    
    /**
     * TODO: Создайте клиента с STDIO транспортом
     * 
     * Требования:
     * 1. Команда: "java"
     * 2. Аргументы: ["-jar", "путь/к/lab01-simple-server-1.0-SNAPSHOT.jar"]
     * 3. Client info: name="calculator-client", version="1.0.0"
     * 4. Настройте notification handlers (onProgress, onLog)
     */
    public CalculatorClient(String serverJarPath) {
        // TODO: Ваш код здесь
        this.client = null;
    }
    
    /**
     * TODO: Реализуйте подключение к серверу
     * 
     * Требования:
     * 1. Вызовите client.initialize()
     * 2. Выведите информацию о сервере
     * 3. Выведите capabilities сервера
     */
    public void connect() throws Exception {
        // TODO: Ваш код здесь
    }
    
    /**
     * TODO: Реализуйте получение списка инструментов
     * 
     * Требования:
     * 1. Вызовите client.listTools()
     * 2. Выведите список в консоль в удобном формате
     * 3. Верните список инструментов
     */
    public List<Tool> listTools() throws Exception {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте вызов инструмента calculator_add
     * 
     * Требования:
     * 1. Вызовите с параметрами {"a": 10, "b": 25}
     * 2. Выведите результат
     * 3. Верните текстовый результат
     */
    public String testAdd() throws Exception {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте вызов инструмента calculator_multiply
     * 
     * Требования:
     * 1. Вызовите с параметрами {"a": 7, "b": 8}
     * 2. Выведите результат
     * 3. Верните текстовый результат
     */
    public String testMultiply() throws Exception {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте вызов инструмента get_current_time
     * 
     * Требования:
     * 1. Вызовите без параметров
     * 2. Выведите результат
     * 3. Верните текстовый результат
     */
    public String testGetTime() throws Exception {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * Закрытие соединения
     */
    public void disconnect() {
        if (client != null) {
            client.close();
            System.out.println("\\nСоединение закрыто");
        }
    }
    
    /**
     * Главный метод - запуск всех тестов
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Использование: java CalculatorClient <путь-к-server.jar>");
            System.exit(1);
        }
        
        String serverJarPath = args[0];
        CalculatorClient client = new CalculatorClient(serverJarPath);
        
        try {
            System.out.println("=================================");
            System.out.println("Calculator MCP Client");
            System.out.println("=================================\\n");
            
            // Подключаемся
            client.connect();
            
            // Получаем список инструментов
            client.listTools();
            
            // Тестируем все инструменты
            System.out.println("\\n=== Тестирование инструментов ===\\n");
            
            String addResult = client.testAdd();
            System.out.println("✓ Add: " + addResult);
            
            String multiplyResult = client.testMultiply();
            System.out.println("✓ Multiply: " + multiplyResult);
            
            String timeResult = client.testGetTime();
            System.out.println("✓ Time: " + timeResult);
            
            System.out.println("\\n✅ Все тесты пройдены успешно!");
            
        } catch (Exception e) {
            System.err.println("❌ Ошибка: " + e.getMessage());
            e.printStackTrace();
        } finally {
            client.disconnect();
        }
    }
}
```

## Шаг 3: Запуск и тестирование

### Компиляция

```bash
mvn clean compile
```

### Запуск

```bash
mvn exec:java -Dexec.mainClass="com.example.mcp.lab02.CalculatorClient" \\
    -Dexec.args="../lab01-simple-server/target/lab01-simple-server-1.0-SNAPSHOT.jar"
```

### Ожидаемый вывод

```
=================================
Calculator MCP Client
=================================

Подключено к серверу:
  Имя: calculator-server
  Версия: 1.0.0

Возможности сервера:
  ✓ Tools (инструменты)
  ✓ Logging (логирование)

Доступные инструменты:
  1. calculator_add - Складывает два числа и возвращает результат
  2. calculator_multiply - Умножает два числа и возвращает результат
  3. get_current_time - Возвращает текущее время в формате ISO 8601

=== Тестирование инструментов ===

✓ Add: 10.00 + 25.00 = 35.00
✓ Multiply: 7.00 × 8.00 = 56.00
✓ Time: Текущее время: 2026-01-02T08:53:15.123456Z

✅ Все тесты пройдены успешно!

Соединение закрыто
```

## Критерии оценки

- [ ] Клиент успешно подключается к серверу
- [ ] Список инструментов получен и отображен
- [ ] Все три инструмента вызваны успешно
- [ ] Notification handlers работают (видны логи от сервера)
- [ ] Обработка ошибок реализована
- [ ] Соединение корректно закрывается

## Подсказки

<details>
<summary>Подсказка 1: Создание клиента с STDIO</summary>

```java
StdioClientTransport transport = StdioClientTransport.builder()
    .command("java")
    .args(List.of("-jar", serverJarPath))
    .build();

this.client = McpClient.builder()
    .transport(transport)
    .clientInfo(Implementation.builder()
        .name("calculator-client")
        .version("1.0.0")
        .build())
    .build();
```
</details>

<details>
<summary>Подсказка 2: Настройка notification handlers</summary>

```java
client.setLogHandler((level, message, logger) -> {
    System.out.printf("[%s] %s: %s\\n", 
        level.toUpperCase(), logger, message);
});

client.setProgressHandler((token, progress, total) -> {
    System.out.printf("[PROGRESS] %s: %d/%d\\n", 
        token, progress, total);
});
```
</details>

<details>
<summary>Подсказка 3: Вызов инструмента</summary>

```java
CallToolResult result = client.callTool(
    "calculator_add",
    Map.of("a", 10, "b", 25)
);

if (result.content() != null && !result.content().isEmpty()) {
    Content content = result.content().get(0);
    if (content instanceof TextContent textContent) {
        return textContent.text();
    }
}
```
</details>

## Дополнительные задания (опционально)

1. **Retry логика**: Реализуйте автоматический retry при сетевых ошибках
2. **Интерактивный режим**: Добавьте возможность вводить команды через консоль
3. **Benchmark**: Измерьте время выполнения каждого инструмента
4. **Параллельные вызовы**: Вызовите несколько инструментов параллельно

## Следующие шаги

После успешного выполнения Lab 02, переходите к Lab 03, где вы создадите более сложный сервер с работой с файлами и базами данных.
"""

with open("mcp-java-course/labs/lab-02-client/README.md", "w", encoding="utf-8") as f:
    f.write(lab02_readme)

print("✓ Файл создан: labs/lab-02-client/README.md")
