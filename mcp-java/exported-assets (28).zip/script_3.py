
# Lab 01 - Создание простого MCP-сервера
lab01_readme = """# Lab 01: Создание простого MCP-сервера

## Цель работы

Создать простой MCP-сервер с базовыми инструментами, который работает через STDIO транспорт.

## Задачи

1. Настроить Maven/Gradle проект с MCP SDK
2. Создать сервер с 3 инструментами:
   - `calculator_add` - сложение двух чисел
   - `calculator_multiply` - умножение двух чисел
   - `get_current_time` - получение текущего времени
3. Реализовать обработчики для каждого инструмента
4. Запустить сервер и протестировать с MCP Inspector

## Шаг 1: Создание проекта

### pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab01-simple-server</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Maven Shade Plugin для создания fat JAR -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>com.example.mcp.lab01.CalculatorServer</mainClass>
                                </transformer>
                            </transformers>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

## Шаг 2: Создание класса сервера

Создайте файл `src/main/java/com/example/mcp/lab01/CalculatorServer.java`

### Задание

Реализуйте следующие методы:

```java
package com.example.mcp.lab01;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.server.StdioServerTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;

public class CalculatorServer {
    
    private final McpServer server;
    
    public CalculatorServer() {
        this.server = createServer();
    }
    
    /**
     * TODO: Создайте и настройте MCP-сервер
     * 
     * Требования:
     * 1. Имя сервера: "calculator-server"
     * 2. Версия: "1.0.0"
     * 3. Capabilities: tools, logging
     * 4. Зарегистрируйте toolsProvider и callToolHandler
     */
    private McpServer createServer() {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте метод, возвращающий список инструментов
     * 
     * Инструмент 1: calculator_add
     * - Параметры: a (number), b (number)
     * - Описание: "Складывает два числа"
     * 
     * Инструмент 2: calculator_multiply
     * - Параметры: a (number), b (number)
     * - Описание: "Умножает два числа"
     * 
     * Инструмент 3: get_current_time
     * - Параметры: нет
     * - Описание: "Возвращает текущее время в ISO 8601 формате"
     */
    private List<Tool> provideTools() {
        // TODO: Ваш код здесь
        return List.of();
    }
    
    /**
     * TODO: Реализуйте обработчик вызова инструментов
     * 
     * Требования:
     * 1. Используйте switch по имени инструмента
     * 2. Для calculator_add: верните сумму a + b
     * 3. Для calculator_multiply: верните произведение a * b
     * 4. Для get_current_time: верните Instant.now().toString()
     * 5. Оберните в try-catch и возвращайте ошибки через isError(true)
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * Запуск сервера
     */
    public void start() {
        StdioServerTransport transport = new StdioServerTransport();
        server.connect(transport);
        System.err.println("Calculator Server запущен");
    }
    
    public static void main(String[] args) {
        CalculatorServer server = new CalculatorServer();
        server.start();
    }
}
```

## Шаг 3: Сборка проекта

```bash
mvn clean package
```

После сборки в `target/` появится файл `lab01-simple-server-1.0-SNAPSHOT.jar`

## Шаг 4: Тестирование с MCP Inspector

### Установка Inspector (если еще не установлен)

```bash
npm install -g @modelcontextprotocol/inspector
```

### Запуск Inspector

```bash
mcp-inspector java -jar target/lab01-simple-server-1.0-SNAPSHOT.jar
```

Inspector откроет веб-интерфейс на http://localhost:5173

### Проверьте:

1. ✅ Список инструментов отображается корректно
2. ✅ Вызов `calculator_add` с параметрами `{"a": 5, "b": 3}` возвращает `8`
3. ✅ Вызов `calculator_multiply` с параметрами `{"a": 4, "b": 7}` возвращает `28`
4. ✅ Вызов `get_current_time` возвращает текущее время
5. ✅ Логи отображаются в Inspector

## Критерии оценки

- [ ] Сервер успешно собирается
- [ ] Все три инструмента работают корректно
- [ ] Обработка ошибок реализована (try-catch)
- [ ] JSON Schema для параметров корректная
- [ ] Логирование работает

## Подсказки

<details>
<summary>Подсказка 1: Создание Tool</summary>

```java
Tool.builder()
    .name("calculator_add")
    .description("Складывает два числа")
    .inputSchema(JsonSchema.builder()
        .type("object")
        .properties(Map.of(
            "a", JsonSchema.builder()
                .type("number")
                .description("Первое число")
                .build(),
            "b", JsonSchema.builder()
                .type("number")
                .description("Второе число")
                .build()
        ))
        .required(List.of("a", "b"))
        .build())
    .build()
```
</details>

<details>
<summary>Подсказка 2: Обработка вызова</summary>

```java
String toolName = request.params().name();
Map<String, JsonNode> arguments = request.params().arguments();

return switch (toolName) {
    case "calculator_add" -> {
        double a = arguments.get("a").asDouble();
        double b = arguments.get("b").asDouble();
        double result = a + b;
        
        yield CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text(String.format("%.2f + %.2f = %.2f", a, b, result))
                    .build()
            ))
            .build();
    }
    // ... остальные cases
};
```
</details>

## Следующие шаги

После успешного выполнения Lab 01, переходите к Lab 02, где вы создадите клиента для подключения к вашему серверу.
"""

with open("mcp-java-course/labs/lab-01-simple-server/README.md", "w", encoding="utf-8") as f:
    f.write(lab01_readme)

print("✓ Файл создан: labs/lab-01-simple-server/README.md")
