
# Проверяем и создаем все необходимые директории
import os

all_dirs = [
    "mcp-java-course/lectures/module-03-java-sdk/diagrams",
    "mcp-java-course/labs/lab-01-simple-server",
    "mcp-java-course/labs/lab-02-client",
    "mcp-java-course/labs/lab-03-tools",
]

for dir_path in all_dirs:
    os.makedirs(dir_path, exist_ok=True)
    
# Проверяем, что директории созданы
for dir_path in all_dirs:
    exists = os.path.exists(dir_path)
    print(f"{'✓' if exists else '✗'} {dir_path}")
