
print("Продолжаю создание файлов Сессии 2...\n")

# Модуль 3 - Mindmap
module03_mindmap = """@startmindmap
* MCP Java SDK
** Компоненты SDK
*** Transport Layer
**** StdioTransport
**** HttpTransport
*** Session Management
**** McpSession
**** Connection lifecycle
*** Server API
**** McpServer
**** Builder pattern
*** Client API
**** McpClient
**** Builder pattern
*** Schema
**** Data types
**** JSON-RPC models
left side
** Создание клиента
*** StdioClientTransport
**** command
**** args
*** HttpClientTransport
**** endpoint
**** authentication
**** SSE support
*** Client Capabilities
**** roots
**** sampling
*** Notification handlers
**** onProgress
**** onLog
**** onResourcesChanged
**** onToolsChanged
** Создание сервера
*** ServerInfo
**** name
**** version
*** Server Capabilities
**** tools
**** resources
**** prompts
**** logging
*** Providers
**** toolsProvider
**** resourcesProvider
**** promptsProvider
*** Handlers
**** callToolHandler
**** readResourceHandler
**** getPromptHandler
** Best Practices
*** Error Handling
**** try-catch blocks
**** meaningful errors
**** isError flag
*** Validation
**** parameter validation
**** security checks
**** path traversal protection
*** Logging
**** structured logs
**** different levels
**** security events
*** Progress Tracking
**** long operations
**** progress tokens
**** percentage updates
@endmindmap
"""

# Модуль 3 - Диаграмма архитектуры SDK
sdk_architecture_diagram = """@startuml

title MCP Java SDK Architecture

package "Application Layer" {
    component [Your Server Logic] as ServerLogic
    component [Your Client Logic] as ClientLogic
}

package "MCP Java SDK" {
    
    package "Server API" {
        component [McpServer] as Server
        component [Server Builders] as ServerBuilder
        interface "Tool Handlers" as ToolHandlers
        interface "Resource Handlers" as ResourceHandlers
    }
    
    package "Client API" {
        component [McpClient] as Client
        component [Client Builders] as ClientBuilder
        interface "Notification Handlers" as NotifHandlers
    }
    
    package "Core" {
        component [McpSession] as Session
        component [Message Router] as Router
        component [JSON-RPC Handler] as JsonRpc
    }
    
    package "Schema" {
        component [Data Models] as Models
        component [Capabilities] as Capabilities
        component [Content Types] as Content
    }
}

package "Transport Layer" {
    component [StdioTransport] as Stdio
    component [HttpTransport] as Http
    component [SSE Handler] as SSE
}

package "I/O" {
    component [stdin/stdout] as StdIO
    component [HTTP Client/Server] as HTTPNet
}

' Connections
ServerLogic --> Server : implements handlers
ClientLogic --> Client : uses API

Server --> Session : manages
Client --> Session : manages

Session --> Router : uses
Router --> JsonRpc : delegates

Server --> ServerBuilder : created by
Client --> ClientBuilder : created by

Server ..> ToolHandlers : registers
Server ..> ResourceHandlers : registers
Client ..> NotifHandlers : registers

Session --> Models : uses
Session --> Capabilities : negotiates

Session --> Stdio : can use
Session --> Http : can use

Stdio --> StdIO : wraps
Http --> HTTPNet : wraps
Http --> SSE : supports

note right of Server
  **McpServer API:**
  - toolsProvider()
  - resourcesProvider()
  - promptsProvider()
  - callToolHandler()
  - sendNotification()
  - sendLog()
end note

note left of Client
  **McpClient API:**
  - initialize()
  - listTools()
  - callTool()
  - listResources()
  - readResource()
  - onProgress()
  - onLog()
end note

@enduml
"""

# Модуль 3 - Диаграмма Client Flow
client_flow_diagram = """@startuml

title MCP Client Usage Flow

actor Developer
participant "McpClient" as Client
participant "Transport" as Transport
participant "McpServer" as Server

== Initialization ==
Developer -> Client : create with builder
activate Client

Developer -> Client : transport(stdio/http)
Developer -> Client : clientInfo(name, version)
Developer -> Client : capabilities(roots, sampling)
Developer -> Client : build()

Developer -> Client : initialize()
Client -> Transport : connect()
activate Transport

Transport -> Server : initialize request
activate Server
Server --> Transport : server capabilities
deactivate Server

Transport --> Client : InitializeResult
deactivate Transport

Client --> Developer : connection ready
deactivate Client

== Setup Handlers ==
Developer -> Client : onProgress(handler)
Developer -> Client : onLog(handler)
Developer -> Client : onResourcesChanged(handler)

== List Tools ==
Developer -> Client : listTools()
activate Client
Client -> Server : tools/list
activate Server
Server --> Client : [Tool1, Tool2, ...]
deactivate Server
Client --> Developer : List<Tool>
deactivate Client

== Call Tool ==
Developer -> Client : callTool(name, args)
activate Client
Client -> Server : tools/call
activate Server

Server -> Client : progress notification
Client -> Developer : onProgress callback

Server --> Client : CallToolResult
deactivate Server
Client --> Developer : result
deactivate Client

== Cleanup ==
Developer -> Client : close()
activate Client
Client -> Transport : disconnect()
Transport -> Server : close connection
Client --> Developer : closed
deactivate Client

@enduml
"""

# Модуль 3 - Диаграмма Server Flow
server_flow_diagram = """@startuml

title MCP Server Implementation Flow

actor Developer
participant "McpServer" as Server
participant "Transport" as Transport
participant "Handlers" as Handlers

== Server Creation ==
Developer -> Server : builder()
activate Server

Developer -> Server : serverInfo(name, version)
Developer -> Server : capabilities(tools, resources, prompts)

Developer -> Server : toolsProvider(lambda)
note right: Provides list of tools

Developer -> Server : callToolHandler(lambda)
note right: Handles tool execution

Developer -> Server : resourcesProvider(lambda)
Developer -> Server : readResourceHandler(lambda)

Developer -> Server : build()
Server --> Developer : configured server
deactivate Server

== Server Start ==
Developer -> Server : connect(transport)
activate Server
Server -> Transport : start listening
activate Transport

note over Transport
  Waiting for client
  connections...
end note

== Client Connects ==
Transport -> Server : initialize request
Server -> Developer : (validate capabilities)
Server --> Transport : server capabilities
note right: Handshake complete

== Tool Call ==
Transport -> Server : tools/list request
Server -> Handlers : toolsProvider()
activate Handlers
Handlers --> Server : List<Tool>
deactivate Handlers
Server --> Transport : tools list response

Transport -> Server : tools/call request
Server -> Handlers : callToolHandler(request)
activate Handlers

Handlers -> Server : sendLog(info, "executing...")
Server --> Transport : log notification

Handlers -> Server : sendProgress(50, 100)
Server --> Transport : progress notification

Handlers --> Server : CallToolResult
deactivate Handlers
Server --> Transport : tool result response

== Server Running ==
note over Server, Transport
  Server continues to handle
  requests until shutdown
end note

deactivate Transport
deactivate Server

@enduml
"""

# Записываем файлы модуля 3
with open("mcp-java-course/lectures/module-03-java-sdk/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module03_mindmap)

with open("mcp-java-course/lectures/module-03-java-sdk/diagrams/sdk-architecture.puml", "w", encoding="utf-8") as f:
    f.write(sdk_architecture_diagram)

with open("mcp-java-course/lectures/module-03-java-sdk/diagrams/client-flow.puml", "w", encoding="utf-8") as f:
    f.write(client_flow_diagram)

with open("mcp-java-course/lectures/module-03-java-sdk/diagrams/server-flow.puml", "w", encoding="utf-8") as f:
    f.write(server_flow_diagram)

print("✓ Файл создан: module-03-java-sdk/mindmap.puml")
print("✓ Файл создан: module-03-java-sdk/diagrams/sdk-architecture.puml")
print("✓ Файл создан: module-03-java-sdk/diagrams/client-flow.puml")
print("✓ Файл создан: module-03-java-sdk/diagrams/server-flow.puml")
