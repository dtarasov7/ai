
# Lab 01 - Решение
lab01_solution = """package com.example.mcp.lab01;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.server.StdioServerTransport;
import io.modelcontextprotocol.sdk.schema.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Lab 01 Solution: Простой MCP-сервер с калькулятором.
 * 
 * Этот сервер предоставляет три инструмента:
 * 1. calculator_add - сложение
 * 2. calculator_multiply - умножение
 * 3. get_current_time - текущее время
 */
public class CalculatorServer {
    
    private final McpServer server;
    
    public CalculatorServer() {
        this.server = createServer();
    }
    
    /**
     * Создание и настройка MCP-сервера.
     */
    private McpServer createServer() {
        return McpServer.builder()
            // Информация о сервере
            .serverInfo(Implementation.builder()
                .name("calculator-server")
                .version("1.0.0")
                .build())
            
            // Объявляем возможности сервера
            .capabilities(ServerCapabilities.builder()
                // Поддержка инструментов
                .tools(ToolsCapability.builder()
                    .listChanged(false)  // Список не меняется динамически
                    .build())
                // Поддержка логирования
                .logging(LoggingCapability.builder()
                    .build())
                .build())
            
            // Регистрируем provider для списка инструментов
            .toolsProvider(this::provideTools)
            
            // Регистрируем handler для вызова инструментов
            .callToolHandler(this::handleToolCall)
            
            .build();
    }
    
    /**
     * Предоставление списка доступных инструментов.
     * 
     * @return список из трех инструментов
     */
    private List<Tool> provideTools() {
        return List.of(
            // Инструмент 1: Сложение
            Tool.builder()
                .name("calculator_add")
                .description("Складывает два числа и возвращает результат")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "a", JsonSchema.builder()
                            .type("number")
                            .description("Первое число")
                            .build(),
                        "b", JsonSchema.builder()
                            .type("number")
                            .description("Второе число")
                            .build()
                    ))
                    .required(List.of("a", "b"))
                    .build())
                .build(),
            
            // Инструмент 2: Умножение
            Tool.builder()
                .name("calculator_multiply")
                .description("Умножает два числа и возвращает результат")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "a", JsonSchema.builder()
                            .type("number")
                            .description("Первое число")
                            .build(),
                        "b", JsonSchema.builder()
                            .type("number")
                            .description("Второе число")
                            .build()
                    ))
                    .required(List.of("a", "b"))
                    .build())
                .build(),
            
            // Инструмент 3: Текущее время
            Tool.builder()
                .name("get_current_time")
                .description("Возвращает текущее время в формате ISO 8601")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of())  // Нет параметров
                    .build())
                .build()
        );
    }
    
    /**
     * Обработчик вызова инструментов.
     * 
     * @param request запрос на вызов инструмента
     * @return результат выполнения инструмента
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        String toolName = request.params().name();
        Map<String, JsonNode> arguments = request.params().arguments();
        
        // Логируем вызов инструмента
        server.sendLog("info", 
            "Tool called: " + toolName + " with args: " + arguments,
            "CalculatorServer");
        
        try {
            // Маршрутизация на соответствующий обработчик
            return switch (toolName) {
                case "calculator_add" -> handleAdd(arguments);
                case "calculator_multiply" -> handleMultiply(arguments);
                case "get_current_time" -> handleGetTime();
                default -> throw new IllegalArgumentException(
                    "Unknown tool: " + toolName
                );
            };
            
        } catch (Exception e) {
            // Логируем ошибку
            server.sendLog("error", 
                "Tool execution failed: " + e.getMessage(),
                "CalculatorServer");
            
            // Возвращаем ошибку в результате
            return CallToolResult.builder()
                .content(List.of(
                    TextContent.builder()
                        .text("Ошибка выполнения: " + e.getMessage())
                        .build()
                ))
                .isError(true)
                .build();
        }
    }
    
    /**
     * Обработка инструмента сложения.
     */
    private CallToolResult handleAdd(Map<String, JsonNode> arguments) {
        // Извлекаем параметры
        double a = arguments.get("a").asDouble();
        double b = arguments.get("b").asDouble();
        
        // Выполняем операцию
        double result = a + b;
        
        // Логируем результат
        server.sendLog("debug", 
            String.format("Calculated: %.2f + %.2f = %.2f", a, b, result),
            "CalculatorServer");
        
        // Формируем ответ
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(String.format("%.2f + %.2f = %.2f", a, b, result))
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента умножения.
     */
    private CallToolResult handleMultiply(Map<String, JsonNode> arguments) {
        // Извлекаем параметры
        double a = arguments.get("a").asDouble();
        double b = arguments.get("b").asDouble();
        
        // Выполняем операцию
        double result = a * b;
        
        // Логируем результат
        server.sendLog("debug", 
            String.format("Calculated: %.2f * %.2f = %.2f", a, b, result),
            "CalculatorServer");
        
        // Формируем ответ
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(String.format("%.2f × %.2f = %.2f", a, b, result))
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента получения времени.
     */
    private CallToolResult handleGetTime() {
        // Получаем текущее время
        String currentTime = Instant.now().toString();
        
        // Логируем
        server.sendLog("debug", 
            "Current time requested: " + currentTime,
            "CalculatorServer");
        
        // Формируем ответ
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text("Текущее время: " + currentTime)
                    .build()
            ))
            .build();
    }
    
    /**
     * Запуск сервера с STDIO транспортом.
     */
    public void start() {
        // Создаем STDIO транспорт
        StdioServerTransport transport = new StdioServerTransport();
        
        // Подключаем транспорт к серверу
        server.connect(transport);
        
        // Логируем запуск (в stderr, т.к. stdout занят протоколом)
        System.err.println("=================================");
        System.err.println("Calculator MCP Server v1.0.0");
        System.err.println("=================================");
        System.err.println("Сервер запущен и готов к работе");
        System.err.println("Доступные инструменты:");
        System.err.println("  • calculator_add");
        System.err.println("  • calculator_multiply");
        System.err.println("  • get_current_time");
    }
    
    /**
     * Точка входа приложения.
     */
    public static void main(String[] args) {
        CalculatorServer server = new CalculatorServer();
        server.start();
    }
}
"""

# pom.xml для решения
lab01_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab01-simple-server</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- Maven Compiler Plugin -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>
            
            <!-- Maven Shade Plugin для создания fat JAR -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>com.example.mcp.lab01.CalculatorServer</mainClass>
                                </transformer>
                            </transformers>
                            <filters>
                                <filter>
                                    <artifact>*:*</artifact>
                                    <excludes>
                                        <exclude>META-INF/*.SF</exclude>
                                        <exclude>META-INF/*.DSA</exclude>
                                        <exclude>META-INF/*.RSA</exclude>
                                    </excludes>
                                </filter>
                            </filters>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
"""

# Создаем директорию для решения
import os
os.makedirs("mcp-java-course/labs/lab-01-simple-server/solution/src/main/java/com/example/mcp/lab01", exist_ok=True)

# Записываем файлы решения
with open("mcp-java-course/labs/lab-01-simple-server/solution/CalculatorServer.java", "w", encoding="utf-8") as f:
    f.write(lab01_solution)

with open("mcp-java-course/labs/lab-01-simple-server/solution/pom.xml", "w", encoding="utf-8") as f:
    f.write(lab01_pom)

print("✓ Файл создан: labs/lab-01-simple-server/solution/CalculatorServer.java")
print("✓ Файл создан: labs/lab-01-simple-server/solution/pom.xml")
