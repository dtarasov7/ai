
# Теперь создаем файлы модуля 3
module03_mindmap = """@startmindmap
* MCP Java SDK
** Компоненты SDK
*** Transport Layer
**** StdioTransport
**** HttpTransport
*** Session Management
**** McpSession
**** Connection lifecycle
*** Server API
**** McpServer
**** Builder pattern
*** Client API
**** McpClient
**** Builder pattern
*** Schema
**** Data types
**** JSON-RPC models
left side
** Создание клиента
*** StdioClientTransport
**** command
**** args
*** HttpClientTransport
**** endpoint
**** authentication
**** SSE support
*** Client Capabilities
**** roots
**** sampling
*** Notification handlers
**** onProgress
**** onLog
**** onResourcesChanged
**** onToolsChanged
** Создание сервера
*** ServerInfo
**** name
**** version
*** Server Capabilities
**** tools
**** resources
**** prompts
**** logging
*** Providers
**** toolsProvider
**** resourcesProvider
**** promptsProvider
*** Handlers
**** callToolHandler
**** readResourceHandler
**** getPromptHandler
** Best Practices
*** Error Handling
**** try-catch blocks
**** meaningful errors
**** isError flag
*** Validation
**** parameter validation
**** security checks
**** path traversal protection
*** Logging
**** structured logs
**** different levels
**** security events
*** Progress Tracking
**** long operations
**** progress tokens
**** percentage updates
@endmindmap
"""

sdk_architecture_diagram = """@startuml

title MCP Java SDK Architecture

package "Application Layer" {
    component [Your Server Logic] as ServerLogic
    component [Your Client Logic] as ClientLogic
}

package "MCP Java SDK" {
    
    package "Server API" {
        component [McpServer] as Server
        component [Server Builders] as ServerBuilder
        interface "Tool Handlers" as ToolHandlers
        interface "Resource Handlers" as ResourceHandlers
    }
    
    package "Client API" {
        component [McpClient] as Client
        component [Client Builders] as ClientBuilder
        interface "Notification Handlers" as NotifHandlers
    }
    
    package "Core" {
        component [McpSession] as Session
        component [Message Router] as Router
        component [JSON-RPC Handler] as JsonRpc
    }
    
    package "Schema" {
        component [Data Models] as Models
        component [Capabilities] as Capabilities
        component [Content Types] as Content
    }
}

package "Transport Layer" {
    component [StdioTransport] as Stdio
    component [HttpTransport] as Http
}

' Connections
ServerLogic --> Server
ClientLogic --> Client

Server --> Session
Client --> Session

Session --> Router
Router --> JsonRpc

Server --> ServerBuilder
Client --> ClientBuilder

Server ..> ToolHandlers
Server ..> ResourceHandlers
Client ..> NotifHandlers

Session --> Models
Session --> Capabilities

Session --> Stdio
Session --> Http

note right of Server
  **McpServer API:**
  - toolsProvider()
  - resourcesProvider()
  - callToolHandler()
  - sendNotification()
  - sendLog()
end note

note left of Client
  **McpClient API:**
  - initialize()
  - listTools()
  - callTool()
  - onProgress()
  - onLog()
end note

@enduml
"""

# Записываем в файлы
files_to_create = {
    "mcp-java-course/lectures/module-03-java-sdk/mindmap.puml": module03_mindmap,
    "mcp-java-course/lectures/module-03-java-sdk/diagrams/sdk-architecture.puml": sdk_architecture_diagram,
}

for filepath, content in files_to_create.items():
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"✓ Файл создан: {filepath.replace('mcp-java-course/', '')}")
