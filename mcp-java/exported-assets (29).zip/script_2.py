
# Lab 03 - Решение (часть 1 - основной класс)
lab03_solution_part1 = """package com.example.mcp.lab03;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.server.StdioServerTransport;
import io.modelcontextprotocol.sdk.schema.*;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/**
 * Lab 03 Solution: Продвинутый MCP-сервер для работы с файлами.
 * 
 * Демонстрирует:
 * - Работу с файловой системой
 * - Progress tracking для долгих операций
 * - Валидацию путей (защита от path traversal)
 * - Обработку бинарных данных
 * - Детальное логирование
 */
public class FileToolsServer {
    
    private final McpServer server;
    private final Path allowedDirectory;
    
    // Константы
    private static final long MAX_FILE_SIZE = 1024 * 1024; // 1 МБ
    private static final int PROGRESS_UPDATE_INTERVAL = 10; // Каждые 10 файлов
    
    /**
     * Создание сервера с разрешенной директорией.
     * 
     * @param allowedDirectory директория, в которой разрешены операции
     */
    public FileToolsServer(Path allowedDirectory) {
        this.allowedDirectory = allowedDirectory.toAbsolutePath().normalize();
        this.server = createServer();
        
        // Логируем инициализацию
        System.err.println("FileToolsServer инициализирован");
        System.err.println("Разрешенная директория: " + this.allowedDirectory);
    }
    
    /**
     * Создание и настройка MCP-сервера.
     */
    private McpServer createServer() {
        return McpServer.builder()
            .serverInfo(Implementation.builder()
                .name("file-tools-server")
                .version("1.0.0")
                .build())
            
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder()
                    .listChanged(false)
                    .build())
                .logging(LoggingCapability.builder()
                    .build())
                .build())
            
            .toolsProvider(this::provideTools)
            .callToolHandler(this::handleToolCall)
            
            .build();
    }
    
    /**
     * Предоставление списка инструментов.
     */
    private List<Tool> provideTools() {
        return List.of(
            // 1. Поиск файлов
            Tool.builder()
                .name("file_search")
                .description("Поиск файлов в разрешенной директории по паттерну")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "pattern", JsonSchema.builder()
                            .type("string")
                            .description("Паттерн поиска (case-insensitive)")
                            .build(),
                        "max_results", JsonSchema.builder()
                            .type("number")
                            .description("Максимальное количество результатов (опционально)")
                            .build()
                    ))
                    .required(List.of("pattern"))
                    .build())
                .build(),
            
            // 2. Чтение файла
            Tool.builder()
                .name("file_read")
                .description("Читает содержимое файла (текстовые файлы до 1 МБ)")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "path", JsonSchema.builder()
                            .type("string")
                            .description("Относительный путь к файлу")
                            .build()
                    ))
                    .required(List.of("path"))
                    .build())
                .build(),
            
            // 3. Анализ текста
            Tool.builder()
                .name("text_analyze")
                .description("Анализирует текст: подсчитывает символы, слова, строки")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "text", JsonSchema.builder()
                            .type("string")
                            .description("Текст для анализа")
                            .build()
                    ))
                    .required(List.of("text"))
                    .build())
                .build(),
            
            // 4. Вычисление хеша
            Tool.builder()
                .name("hash_calculate")
                .description("Вычисляет хеш файла (MD5 или SHA-256)")
                .inputSchema(JsonSchema.builder()
                    .type("object")
                    .properties(Map.of(
                        "path", JsonSchema.builder()
                            .type("string")
                            .description("Относительный путь к файлу")
                            .build(),
                        "algorithm", JsonSchema.builder()
                            .type("string")
                            .description("Алгоритм хеширования: md5 или sha256")
                            .enumValues(List.of("md5", "sha256"))
                            .build()
                    ))
                    .required(List.of("path", "algorithm"))
                    .build())
                .build()
        );
    }
    
    /**
     * Обработка вызова инструмента.
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        String toolName = request.params().name();
        Map<String, JsonNode> arguments = request.params().arguments();
        
        // Генерируем токен для отслеживания прогресса
        String progressToken = generateProgressToken();
        
        // Логируем вызов
        server.sendLog("info",
            String.format("Tool '%s' called with args: %s", toolName, arguments),
            "FileToolsServer");
        
        long startTime = System.currentTimeMillis();
        
        try {
            CallToolResult result = switch (toolName) {
                case "file_search" -> handleFileSearch(arguments, progressToken);
                case "file_read" -> handleFileRead(arguments);
                case "text_analyze" -> handleTextAnalyze(arguments);
                case "hash_calculate" -> handleHashCalculate(arguments);
                default -> throw new IllegalArgumentException("Unknown tool: " + toolName);
            };
            
            // Логируем успешное выполнение
            long duration = System.currentTimeMillis() - startTime;
            server.sendLog("info",
                String.format("Tool '%s' completed in %d ms", toolName, duration),
                "FileToolsServer");
            
            return result;
            
        } catch (SecurityException e) {
            // Логируем попытку нарушения безопасности
            server.sendLog("warning",
                String.format("Security violation in '%s': %s", toolName, e.getMessage()),
                "Security");
            
            return createErrorResult("Нарушение безопасности: " + e.getMessage());
            
        } catch (Exception e) {
            // Логируем ошибку выполнения
            server.sendLog("error",
                String.format("Tool '%s' failed: %s", toolName, e.getMessage()),
                "FileToolsServer");
            
            return createErrorResult("Ошибка выполнения: " + e.getMessage());
        }
    }
    
    /**
     * Обработка инструмента file_search.
     * Поиск файлов с отправкой прогресса.
     */
    private CallToolResult handleFileSearch(
            Map<String, JsonNode> arguments, 
            String progressToken) throws IOException {
        
        String pattern = arguments.get("pattern").asText().toLowerCase();
        int maxResults = arguments.containsKey("max_results")
            ? arguments.get("max_results").asInt()
            : Integer.MAX_VALUE;
        
        server.sendLog("debug",
            String.format("Searching for pattern '%s', max results: %d", pattern, maxResults),
            "file_search");
        
        List<String> foundFiles = new ArrayList<>();
        int filesProcessed = 0;
        
        // Обходим все файлы в разрешенной директории
        try (Stream<Path> paths = Files.walk(allowedDirectory)) {
            
            List<Path> allFiles = paths
                .filter(Files::isRegularFile)
                .toList();
            
            int totalFiles = allFiles.size();
            
            for (Path file : allFiles) {
                filesProcessed++;
                
                // Отправляем прогресс каждые N файлов
                if (filesProcessed % PROGRESS_UPDATE_INTERVAL == 0) {
                    server.sendProgress(progressToken, filesProcessed, totalFiles);
                }
                
                // Проверяем соответствие паттерну
                String fileName = file.getFileName().toString().toLowerCase();
                if (fileName.contains(pattern)) {
                    // Получаем путь относительно allowedDirectory
                    String relativePath = allowedDirectory.relativize(file).toString();
                    foundFiles.add(relativePath);
                    
                    // Прерываем если достигли лимита
                    if (foundFiles.size() >= maxResults) {
                        break;
                    }
                }
            }
            
            // Отправляем финальный прогресс
            server.sendProgress(progressToken, filesProcessed, totalFiles);
        }
        
        // Формируем результат
        String resultText = String.format(
            "Найдено файлов: %d (обработано: %d)\\n\\nФайлы:\\n%s",
            foundFiles.size(),
            filesProcessed,
            String.join("\\n", foundFiles)
        );
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(resultText)
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента file_read.
     * Чтение файла с валидацией.
     */
    private CallToolResult handleFileRead(Map<String, JsonNode> arguments) 
            throws IOException {
        
        String relativePath = arguments.get("path").asText();
        
        // Валидируем путь
        Path filePath = validatePath(relativePath);
        
        // Проверяем существование
        if (!Files.exists(filePath)) {
            throw new IOException("Файл не найден: " + relativePath);
        }
        
        // Проверяем что это файл, а не директория
        if (!Files.isRegularFile(filePath)) {
            throw new IOException("Путь не указывает на файл: " + relativePath);
        }
        
        // Проверяем размер
        long fileSize = Files.size(filePath);
        if (fileSize > MAX_FILE_SIZE) {
            throw new IOException(
                String.format("Файл слишком большой: %d байт (макс: %d)", 
                    fileSize, MAX_FILE_SIZE)
            );
        }
        
        server.sendLog("debug",
            String.format("Reading file '%s' (%d bytes)", relativePath, fileSize),
            "file_read");
        
        // Читаем содержимое
        String content = Files.readString(filePath);
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(String.format("Файл: %s\\n\\nСодержимое:\\n%s", 
                        relativePath, content))
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента text_analyze.
     * Анализ текстовых данных.
     */
    private CallToolResult handleTextAnalyze(Map<String, JsonNode> arguments) {
        String text = arguments.get("text").asText();
        
        // Подсчет метрик
        int totalChars = text.length();
        int lines = text.isEmpty() ? 0 : text.split("\\n").length;
        
        // Разбиваем на слова
        String[] words = text.split("\\s+");
        int wordCount = text.isEmpty() ? 0 : words.length;
        
        // Находим самое длинное слово
        String longestWord = Arrays.stream(words)
            .max(Comparator.comparingInt(String::length))
            .orElse("");
        
        // Подсчитываем уникальные слова
        Set<String> uniqueWords = new HashSet<>(Arrays.asList(words));
        
        server.sendLog("debug",
            String.format("Analyzed text: %d chars, %d words, %d lines", 
                totalChars, wordCount, lines),
            "text_analyze");
        
        // Формируем результат
        String result = String.format(
            "📊 Анализ текста\\n" +
            "================\\n\\n" +
            "📝 Символов: %d\\n" +
            "📖 Слов: %d\\n" +
            "🔤 Уникальных слов: %d\\n" +
            "📄 Строк: %d\\n" +
            "📏 Самое длинное слово: \\\"%s\\\" (%d символов)\\n" +
            "📊 Средняя длина слова: %.1f символов",
            totalChars,
            wordCount,
            uniqueWords.size(),
            lines,
            longestWord,
            longestWord.length(),
            wordCount > 0 ? (double) totalChars / wordCount : 0.0
        );
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(result)
                    .build()
            ))
            .build();
    }
    
    /**
     * Обработка инструмента hash_calculate.
     * Вычисление хеша файла.
     */
    private CallToolResult handleHashCalculate(Map<String, JsonNode> arguments) 
            throws IOException {
        
        String relativePath = arguments.get("path").asText();
        String algorithm = arguments.get("algorithm").asText().toLowerCase();
        
        // Валидируем путь
        Path filePath = validatePath(relativePath);
        
        // Проверяем существование
        if (!Files.exists(filePath)) {
            throw new IOException("Файл не найден: " + relativePath);
        }
        
        server.sendLog("debug",
            String.format("Calculating %s hash for '%s'", algorithm, relativePath),
            "hash_calculate");
        
        // Вычисляем хеш
        String hash;
        try (InputStream is = Files.newInputStream(filePath)) {
            hash = switch (algorithm) {
                case "md5" -> DigestUtils.md5Hex(is);
                case "sha256" -> DigestUtils.sha256Hex(is);
                default -> throw new IllegalArgumentException(
                    "Неизвестный алгоритм: " + algorithm
                );
            };
        }
        
        String result = String.format(
            "🔐 Хеш файла\\n" +
            "============\\n\\n" +
            "Файл: %s\\n" +
            "Алгоритм: %s\\n" +
            "Хеш: %s",
            relativePath,
            algorithm.toUpperCase(),
            hash
        );
        
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text(result)
                    .build()
            ))
            .build();
    }
"""

print("Создаю решение Lab 03 (большой файл, часть 1)...")
