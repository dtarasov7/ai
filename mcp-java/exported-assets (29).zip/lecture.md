# Модуль 4: Debugging и Testing MCP-приложений

## Цели модуля

После изучения этого модуля вы:
- Научитесь использовать MCP Inspector для отладки
- Узнаете лучшие практики логирования
- Научитесь писать unit и integration тесты
- Познакомитесь с инструментами мониторинга

---

## MCP Inspector

MCP Inspector — это официальный инструмент для отладки и тестирования MCP-серверов.

### Установка

```bash
npm install -g @modelcontextprotocol/inspector
```

### Запуск

```bash
# STDIO сервер
mcp-inspector java -jar your-server.jar

# С аргументами
mcp-inspector java -jar your-server.jar /path/to/data

# HTTP сервер
mcp-inspector --url http://localhost:8080/mcp
```

### Возможности Inspector

1. **Интерактивное тестирование**
   - Просмотр списка инструментов, ресурсов, промптов
   - Вызов инструментов с custom параметрами
   - Просмотр результатов в реальном времени

2. **Мониторинг**
   - Просмотр логов от сервера
   - Отслеживание progress notifications
   - Анализ производительности

3. **Отладка**
   - Просмотр JSON-RPC сообщений
   - Валидация схем данных
   - Анализ ошибок

### Пример использования

```java
/**
 * Серверный код с детальным логированием для Inspector.
 */
public class DebugFriendlyServer {

    private final McpServer server;

    private CallToolResult handleToolCall(CallToolRequest request) {
        String toolName = request.params().name();

        // Логируем начало операции
        server.sendLog("info", 
            "Tool execution started: " + toolName,
            "ToolHandler");

        try {
            // Выполняем операцию
            CallToolResult result = executeToolLogic(request);

            // Логируем успешное завершение
            server.sendLog("debug",
                "Tool execution completed successfully",
                "ToolHandler");

            return result;

        } catch (Exception e) {
            // Логируем ошибку с stack trace
            server.sendLog("error",
                "Tool execution failed: " + e.getMessage() + "\n" +
                "Stack trace: " + getStackTrace(e),
                "ToolHandler");

            throw e;
        }
    }

    private String getStackTrace(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }
}
```

---

## Лучшие практики логирования

### Уровни логирования

```java
/**
 * Правильное использование уровней логов.
 */
public class LoggingBestPractices {

    private McpServer server;

    /**
     * DEBUG - детальная информация для отладки
     */
    private void logDebug() {
        server.sendLog("debug",
            "Processing file: /path/to/file.txt, size: 1024 bytes",
            "FileProcessor");
    }

    /**
     * INFO - важные события в приложении
     */
    private void logInfo() {
        server.sendLog("info",
            "Tool 'calculate_sum' executed successfully in 125ms",
            "ToolHandler");
    }

    /**
     * WARNING - потенциальные проблемы
     */
    private void logWarning() {
        server.sendLog("warning",
            "File size exceeds recommended limit: 5MB > 1MB",
            "FileValidator");
    }

    /**
     * ERROR - ошибки выполнения
     */
    private void logError() {
        server.sendLog("error",
            "Failed to connect to database: Connection timeout after 30s",
            "DatabaseClient");
    }

    /**
     * CRITICAL - критические ошибки, требующие немедленного внимания
     */
    private void logCritical() {
        server.sendLog("critical",
            "Out of memory: heap space exhausted (used: 98%)",
            "SystemMonitor");
    }
}
```

### Structured Logging

```java
/**
 * Структурированное логирование для анализа.
 */
public class StructuredLogging {

    /**
     * Логируем операцию с метриками.
     */
    private void logOperationWithMetrics(
            String operation,
            long durationMs,
            boolean success,
            Map<String, Object> metadata) {

        // Формируем структурированное сообщение
        String message = String.format(
            "operation=%s duration=%dms success=%b metadata=%s",
            operation,
            durationMs,
            success,
            toJson(metadata)
        );

        server.sendLog(
            success ? "info" : "error",
            message,
            "OperationLogger"
        );
    }

    /**
     * Логируем с контекстом пользователя.
     */
    private void logWithContext(String action, String userId, String sessionId) {
        String message = String.format(
            "action=%s user_id=%s session_id=%s timestamp=%s",
            action,
            userId,
            sessionId,
            Instant.now()
        );

        server.sendLog("info", message, "AuditLog");
    }
}
```

---

## Unit Testing

### Настройка JUnit 5

```xml
<dependencies>
    <!-- JUnit 5 -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.10.1</version>
        <scope>test</scope>
    </dependency>

    <!-- Mockito для моков -->
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <version>5.8.0</version>
        <scope>test</scope>
    </dependency>

    <!-- AssertJ для удобных assertions -->
    <dependency>
        <groupId>org.assertj</groupId>
        <artifactId>assertj-core</artifactId>
        <version>3.24.2</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

### Тестирование Tool Handlers

```java
package com.example.mcp.server;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.assertj.core.assertions.Assertions.*;

/**
 * Unit тесты для обработчиков инструментов.
 */
class ToolHandlerTest {

    private CalculatorToolHandler handler;

    @BeforeEach
    void setUp() {
        handler = new CalculatorToolHandler();
    }

    @Test
    void testAddition_ValidNumbers_ReturnsSum() {
        // Arrange
        Map<String, JsonNode> args = Map.of(
            "a", new DoubleNode(5.0),
            "b", new DoubleNode(3.0)
        );

        // Act
        CallToolResult result = handler.handleAdd(args);

        // Assert
        assertThat(result.isError()).isFalse();
        assertThat(result.content()).hasSize(1);

        TextContent content = (TextContent) result.content().get(0);
        assertThat(content.text()).contains("8.00");
    }

    @Test
    void testAddition_MissingParameter_ThrowsException() {
        // Arrange
        Map<String, JsonNode> args = Map.of(
            "a", new DoubleNode(5.0)
            // "b" отсутствует
        );

        // Act & Assert
        assertThatThrownBy(() -> handler.handleAdd(args))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("Missing required parameter: b");
    }

    @Test
    void testDivision_DivideByZero_ReturnsError() {
        // Arrange
        Map<String, JsonNode> args = Map.of(
            "a", new DoubleNode(10.0),
            "b", new DoubleNode(0.0)
        );

        // Act
        CallToolResult result = handler.handleDivide(args);

        // Assert
        assertThat(result.isError()).isTrue();
        assertThat(result.content().get(0))
            .isInstanceOf(TextContent.class);
    }
}
```

### Тестирование с моками

```java
/**
 * Тестирование с использованием Mockito.
 */
class DatabaseToolHandlerTest {

    @Mock
    private DatabaseClient dbClient;

    @Mock
    private McpServer server;

    @InjectMocks
    private DatabaseToolHandler handler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testQueryExecution_ValidQuery_ReturnsResults() {
        // Arrange
        List<Map<String, Object>> mockResults = List.of(
            Map.of("id", 1, "name", "Alice"),
            Map.of("id", 2, "name", "Bob")
        );

        when(dbClient.executeQuery(anyString()))
            .thenReturn(mockResults);

        Map<String, JsonNode> args = Map.of(
            "query", new TextNode("SELECT * FROM users")
        );

        // Act
        CallToolResult result = handler.handleQuery(args);

        // Assert
        assertThat(result.isError()).isFalse();
        verify(dbClient).executeQuery("SELECT * FROM users");
        verify(server).sendLog(eq("info"), contains("Query executed"), any());
    }

    @Test
    void testQueryExecution_DatabaseError_LogsAndReturnsError() {
        // Arrange
        when(dbClient.executeQuery(anyString()))
            .thenThrow(new SQLException("Connection timeout"));

        Map<String, JsonNode> args = Map.of(
            "query", new TextNode("SELECT * FROM users")
        );

        // Act
        CallToolResult result = handler.handleQuery(args);

        // Assert
        assertThat(result.isError()).isTrue();
        verify(server).sendLog(eq("error"), contains("Connection timeout"), any());
    }
}
```

---

## Integration Testing

### Тестирование полного цикла клиент-сервер

```java
/**
 * Integration тест для проверки взаимодействия клиента и сервера.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ClientServerIntegrationTest {

    private McpServer server;
    private McpClient client;
    private Thread serverThread;

    @BeforeAll
    void startServer() throws Exception {
        // Запускаем сервер в отдельном потоке
        server = createTestServer();

        serverThread = new Thread(() -> {
            StdioServerTransport transport = new StdioServerTransport();
            server.connect(transport);
        });

        serverThread.start();
        Thread.sleep(1000); // Ждем запуска сервера
    }

    @AfterAll
    void stopServer() {
        if (client != null) {
            client.close();
        }
        if (serverThread != null) {
            serverThread.interrupt();
        }
    }

    @Test
    void testFullWorkflow_InitializeListCallTool_Success() throws Exception {
        // 1. Создаем клиента
        client = createTestClient();

        // 2. Инициализируем соединение
        InitializeResult initResult = client.initialize();
        assertThat(initResult.serverInfo().name()).isEqualTo("test-server");

        // 3. Получаем список инструментов
        ListToolsResult toolsResult = client.listTools();
        assertThat(toolsResult.tools()).hasSizeGreaterThan(0);

        // 4. Вызываем инструмент
        CallToolResult callResult = client.callTool(
            "echo",
            Map.of("message", "Hello, MCP!")
        );

        assertThat(callResult.isError()).isFalse();
        TextContent content = (TextContent) callResult.content().get(0);
        assertThat(content.text()).contains("Hello, MCP!");
    }

    @Test
    void testNotifications_ProgressAndLogs_ReceivedByClient() throws Exception {
        // Arrange
        List<String> receivedLogs = new ArrayList<>();
        List<Integer> progressUpdates = new ArrayList<>();

        client.setLogHandler((level, message, logger) -> {
            receivedLogs.add(message);
        });

        client.setProgressHandler((token, progress, total) -> {
            progressUpdates.add(progress);
        });

        // Act - вызываем долгую операцию
        client.callTool("long_operation", Map.of());

        Thread.sleep(2000); // Ждем завершения

        // Assert
        assertThat(receivedLogs).isNotEmpty();
        assertThat(progressUpdates).isNotEmpty();
    }
}
```

---

## Performance Testing

### Измерение производительности

```java
/**
 * Performance тесты для MCP-серверов.
 */
class PerformanceTest {

    @Test
    void testToolCallLatency_ShouldBeLessThan100ms() {
        // Arrange
        int iterations = 100;
        List<Long> latencies = new ArrayList<>();

        // Act
        for (int i = 0; i < iterations; i++) {
            long start = System.nanoTime();

            client.callTool("fast_operation", Map.of());

            long end = System.nanoTime();
            latencies.add((end - start) / 1_000_000); // Конвертируем в миллисекунды
        }

        // Assert
        double avgLatency = latencies.stream()
            .mapToLong(Long::longValue)
            .average()
            .orElse(0);

        double p95Latency = calculatePercentile(latencies, 0.95);

        assertThat(avgLatency).isLessThan(100.0);
        assertThat(p95Latency).isLessThan(200.0);

        System.out.printf("Average latency: %.2f ms\n", avgLatency);
        System.out.printf("P95 latency: %.2f ms\n", p95Latency);
    }

    @Test
    void testConcurrentRequests_10Threads_NoErrors() throws Exception {
        // Arrange
        int threadCount = 10;
        int requestsPerThread = 50;
        CountDownLatch latch = new CountDownLatch(threadCount);
        List<Exception> errors = Collections.synchronizedList(new ArrayList<>());

        // Act
        for (int i = 0; i < threadCount; i++) {
            new Thread(() -> {
                try {
                    for (int j = 0; j < requestsPerThread; j++) {
                        client.callTool("echo", Map.of("message", "test"));
                    }
                } catch (Exception e) {
                    errors.add(e);
                } finally {
                    latch.countDown();
                }
            }).start();
        }

        latch.await(30, TimeUnit.SECONDS);

        // Assert
        assertThat(errors).isEmpty();
    }

    private double calculatePercentile(List<Long> values, double percentile) {
        Collections.sort(values);
        int index = (int) Math.ceil(percentile * values.size());
        return values.get(index - 1);
    }
}
```

---

## Мониторинг в Production

### Метрики для отслеживания

```java
/**
 * Сбор метрик для мониторинга.
 */
public class MetricsCollector {

    private final AtomicLong totalRequests = new AtomicLong(0);
    private final AtomicLong failedRequests = new AtomicLong(0);
    private final ConcurrentHashMap<String, AtomicLong> toolCallCounts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, List<Long>> toolLatencies = new ConcurrentHashMap<>();

    /**
     * Записываем метрики вызова инструмента.
     */
    public void recordToolCall(String toolName, long durationMs, boolean success) {
        totalRequests.incrementAndGet();

        if (!success) {
            failedRequests.incrementAndGet();
        }

        // Подсчитываем вызовы по инструментам
        toolCallCounts.computeIfAbsent(toolName, k -> new AtomicLong(0))
            .incrementAndGet();

        // Записываем latency
        toolLatencies.computeIfAbsent(toolName, k -> Collections.synchronizedList(new ArrayList<>()))
            .add(durationMs);
    }

    /**
     * Получение текущих метрик.
     */
    public Map<String, Object> getMetrics() {
        Map<String, Object> metrics = new HashMap<>();

        metrics.put("total_requests", totalRequests.get());
        metrics.put("failed_requests", failedRequests.get());
        metrics.put("success_rate", calculateSuccessRate());
        metrics.put("tool_call_counts", new HashMap<>(toolCallCounts));
        metrics.put("average_latencies", calculateAverageLatencies());

        return metrics;
    }

    private double calculateSuccessRate() {
        long total = totalRequests.get();
        if (total == 0) return 100.0;

        long failed = failedRequests.get();
        return ((total - failed) * 100.0) / total;
    }

    private Map<String, Double> calculateAverageLatencies() {
        Map<String, Double> avgLatencies = new HashMap<>();

        toolLatencies.forEach((tool, latencies) -> {
            double avg = latencies.stream()
                .mapToLong(Long::longValue)
                .average()
                .orElse(0);
            avgLatencies.put(tool, avg);
        });

        return avgLatencies;
    }
}
```

---

## Резюме модуля

### Что вы узнали:

✅ **MCP Inspector** — интерактивная отладка и тестирование серверов

✅ **Logging Best Practices** — структурированное логирование с правильными уровнями

✅ **Unit Testing** — тестирование tool handlers с JUnit и Mockito

✅ **Integration Testing** — end-to-end тесты клиент-сервер

✅ **Performance Testing** — измерение latency и throughput

✅ **Monitoring** — сбор метрик для production

### Следующие шаги:

В следующем модуле вы узнаете про Production Deployment:
- Контейнеризация с Docker
- Deployment в Kubernetes
- Security best practices
- Масштабирование и высокая доступность
