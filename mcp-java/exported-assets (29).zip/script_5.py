
# Модуль 5 - Production Deployment (краткая версия из-за лимитов)
module05_lecture = """# Модуль 5: Production Deployment

## Цели модуля

После изучения этого модуля вы:
- Научитесь контейнеризировать MCP-серверы с Docker
- Узнаете как деплоить в Kubernetes
- Познакомитесь с security best practices
- Научитесь масштабировать и обеспечивать высокую доступность

---

## Контейнеризация с Docker

### Dockerfile для MCP-сервера

```dockerfile
# Multi-stage build для оптимизации размера образа
FROM maven:3.9-eclipse-temurin-17 AS build

# Копируем исходники
WORKDIR /app
COPY pom.xml .
COPY src ./src

# Собираем приложение
RUN mvn clean package -DskipTests

# Финальный образ
FROM eclipse-temurin:17-jre-alpine

# Создаем непривилегированного пользователя
RUN addgroup -g 1000 mcp && \\
    adduser -D -u 1000 -G mcp mcp

WORKDIR /app

# Копируем собранный JAR
COPY --from=build /app/target/*.jar app.jar

# Назначаем владельца
RUN chown -R mcp:mcp /app

# Переключаемся на непривилегированного пользователя
USER mcp

# Expose порт (если HTTP)
EXPOSE 8080

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \\
    CMD java -cp app.jar HealthCheck || exit 1

# Запуск приложения
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### Docker Compose для разработки

```yaml
version: '3.8'

services:
  mcp-server:
    build: .
    container_name: mcp-server
    ports:
      - "8080:8080"
    environment:
      - MCP_DATA_DIR=/data
      - LOG_LEVEL=info
    volumes:
      - ./data:/data:ro
    restart: unless-stopped
    networks:
      - mcp-network
    
  # PostgreSQL для хранения данных
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: mcpdata
      POSTGRES_USER: mcpuser
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres-data:/var/lib/postgresql/data
    networks:
      - mcp-network

networks:
  mcp-network:
    driver: bridge

volumes:
  postgres-data:
```

---

## Kubernetes Deployment

### Deployment манифест

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mcp-server
  namespace: mcp
  labels:
    app: mcp-server
spec:
  replicas: 3
  selector:
    matchLabels:
      app: mcp-server
  template:
    metadata:
      labels:
        app: mcp-server
    spec:
      containers:
      - name: mcp-server
        image: your-registry/mcp-server:latest
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: MCP_DATA_DIR
          value: "/data"
        - name: DB_HOST
          valueFrom:
            secretKeyRef:
              name: mcp-secrets
              key: db-host
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
        volumeMounts:
        - name: data
          mountPath: /data
          readOnly: true
      volumes:
      - name: data
        persistentVolumeClaim:
          claimName: mcp-data-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: mcp-server
  namespace: mcp
spec:
  selector:
    app: mcp-server
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
  type: LoadBalancer
```

---

## Security Best Practices

### 1. Аутентификация и авторизация

```java
/**
 * JWT-based аутентификация для HTTP MCP-серверов.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        
        // Извлекаем токен из заголовка
        String authHeader = request.getHeader("Authorization");
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }
        
        String token = authHeader.substring(7);
        
        try {
            // Валидируем JWT токен
            Claims claims = Jwts.parserBuilder()
                .setSigningKey(getSecretKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
            
            // Проверяем права доступа
            String userId = claims.getSubject();
            List<String> roles = claims.get("roles", List.class);
            
            if (!hasRequiredRole(roles)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            
            // Устанавливаем контекст аутентификации
            SecurityContextHolder.getContext().setAuthentication(
                new JwtAuthentication(userId, roles)
            );
            
            filterChain.doFilter(request, response);
            
        } catch (JwtException e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }
}
```

### 2. Rate Limiting

```java
/**
 * Rate limiting для защиты от злоупотреблений.
 */
@Component
public class RateLimitingFilter implements Filter {
    
    private final Map<String, RateLimiter> limiters = new ConcurrentHashMap<>();
    
    @Override
    public void doFilter(
            ServletRequest request,
            ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // Определяем ключ для rate limiting (IP или user ID)
        String key = getRateLimitKey(httpRequest);
        
        // Получаем или создаем limiter (5 req/sec)
        RateLimiter limiter = limiters.computeIfAbsent(
            key,
            k -> RateLimiter.create(5.0)
        );
        
        // Проверяем лимит
        if (!limiter.tryAcquire()) {
            httpResponse.setStatus(429); // Too Many Requests
            httpResponse.getWriter().write("Rate limit exceeded");
            return;
        }
        
        chain.doFilter(request, response);
    }
    
    private String getRateLimitKey(HttpServletRequest request) {
        // Используем user ID если аутентифицирован, иначе IP
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()) {
            return "user:" + auth.getName();
        }
        return "ip:" + request.getRemoteAddr();
    }
}
```

### 3. Input Validation

```java
/**
 * Валидация всех входных данных.
 */
public class InputValidator {
    
    /**
     * Валидация параметров tool call.
     */
    public void validateToolParameters(
            String toolName,
            Map<String, JsonNode> arguments) throws ValidationException {
        
        switch (toolName) {
            case "file_read" -> {
                validateRequired(arguments, "path");
                validatePath(arguments.get("path").asText());
            }
            
            case "database_query" -> {
                validateRequired(arguments, "query");
                validateSqlQuery(arguments.get("query").asText());
            }
            
            case "send_email" -> {
                validateRequired(arguments, "to", "subject", "body");
                validateEmail(arguments.get("to").asText());
                validateLength(arguments.get("body").asText(), 10000);
            }
        }
    }
    
    private void validatePath(String path) throws ValidationException {
        // Проверка на path traversal
        if (path.contains("..") || path.startsWith("/")) {
            throw new ValidationException("Invalid path: " + path);
        }
        
        // Проверка на допустимые символы
        if (!path.matches("^[a-zA-Z0-9/_.-]+$")) {
            throw new ValidationException("Path contains invalid characters");
        }
    }
    
    private void validateSqlQuery(String query) throws ValidationException {
        // Проверка на опасные операции
        String lowerQuery = query.toLowerCase();
        if (lowerQuery.contains("drop") || 
            lowerQuery.contains("delete") || 
            lowerQuery.contains("update")) {
            throw new ValidationException("Dangerous SQL operation not allowed");
        }
    }
}
```

---

## Мониторинг и Observability

### Prometheus Metrics

```java
/**
 * Экспорт метрик в Prometheus.
 */
@RestController
@RequestMapping("/metrics")
public class MetricsController {
    
    private final Counter totalRequests = Counter.build()
        .name("mcp_requests_total")
        .help("Total number of MCP requests")
        .labelNames("tool", "status")
        .register();
    
    private final Histogram requestDuration = Histogram.build()
        .name("mcp_request_duration_seconds")
        .help("MCP request duration in seconds")
        .labelNames("tool")
        .register();
    
    /**
     * Записываем метрики для каждого запроса.
     */
    public CallToolResult handleToolCallWithMetrics(CallToolRequest request) {
        String toolName = request.params().name();
        
        Histogram.Timer timer = requestDuration.labels(toolName).startTimer();
        
        try {
            CallToolResult result = actuallyHandleToolCall(request);
            
            totalRequests.labels(toolName, "success").inc();
            
            return result;
            
        } catch (Exception e) {
            totalRequests.labels(toolName, "error").inc();
            throw e;
            
        } finally {
            timer.observeDuration();
        }
    }
    
    @GetMapping(produces = "text/plain")
    public String metrics() {
        StringWriter writer = new StringWriter();
        try {
            TextFormat.write004(writer, CollectorRegistry.defaultRegistry.metricFamilySamples());
        } catch (IOException e) {
            // Handle error
        }
        return writer.toString();
    }
}
```

---

## Резюме модуля

### Что вы узнали:

✅ **Docker** — контейнеризация MCP-серверов с multi-stage builds

✅ **Kubernetes** — deployment, services, scaling

✅ **Security** — аутентификация, авторизация, input validation, rate limiting

✅ **Monitoring** — метрики Prometheus, health checks, logging

### Практические рекомендации:

1. **Всегда используйте HTTPS** в production
2. **Валидируйте все входные данные**
3. **Реализуйте rate limiting**
4. **Мониторьте метрики производительности**
5. **Логируйте все security события**
6. **Используйте secrets management** (Vault, K8s Secrets)
7. **Регулярно обновляйте зависимости**
"""

with open("mcp-java-course/lectures/module-05-production/lecture.md", "w", encoding="utf-8") as f:
    f.write(module05_lecture)

print("✓ Файл создан: lectures/module-05-production/lecture.md")
print("\nСоздаю финальный проект...")
