
print("=" * 60)
print("СЕССИЯ 3: Создание курса MCP + Java (финальная часть)")
print("=" * 60)
print("\n📚 Будут созданы:")
print("  - Lab 03: Работа с Tools (продвинутые возможности)")
print("  - Модуль 4: Debugging и Testing")
print("  - Модуль 5: Production Deployment")
print("  - Финальный проект")
print("\n🚀 Начинаем создание файлов...\n")

# Создаем структуру директорий для сессии 3
import os

session3_dirs = [
    "mcp-java-course/labs/lab-03-tools/solution",
    "mcp-java-course/lectures/module-04-debugging/diagrams",
    "mcp-java-course/lectures/module-05-production/diagrams",
    "mcp-java-course/final-project",
]

for dir_path in session3_dirs:
    os.makedirs(dir_path, exist_ok=True)
    
print("Директории созданы. Создаем Lab 03...\n")
