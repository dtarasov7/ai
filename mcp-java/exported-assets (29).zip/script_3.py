
# Lab 03 - Решение (часть 2 - вспомогательные методы)
lab03_solution_part2 = """    
    /**
     * Валидация пути для защиты от path traversal атак.
     * 
     * Эта функция критически важна для безопасности.
     * Она гарантирует, что все операции с файлами
     * происходят только внутри разрешенной директории.
     * 
     * @param relativePath относительный путь от клиента
     * @return валидированный абсолютный путь
     * @throws SecurityException если путь выходит за пределы разрешенной директории
     */
    private Path validatePath(String relativePath) throws IOException {
        // Резолвим путь относительно разрешенной директории
        Path resolved = allowedDirectory.resolve(relativePath);
        
        // Нормализуем путь (убираем .., ., symlinks)
        Path normalized = resolved.normalize().toRealPath(LinkOption.NOFOLLOW_LINKS);
        
        // ВАЖНАЯ ПРОВЕРКА: путь должен начинаться с allowedDirectory
        if (!normalized.startsWith(allowedDirectory)) {
            // Это попытка path traversal атаки!
            server.sendLog("warning",
                String.format(
                    "Path traversal attempt blocked: '%s' -> '%s' (allowed: '%s')",
                    relativePath, normalized, allowedDirectory
                ),
                "Security");
            
            throw new SecurityException(
                "Доступ запрещен: путь выходит за пределы разрешенной директории"
            );
        }
        
        return normalized;
    }
    
    /**
     * Создание результата с ошибкой.
     */
    private CallToolResult createErrorResult(String errorMessage) {
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .type("text")
                    .text("❌ " + errorMessage)
                    .build()
            ))
            .isError(true)
            .build();
    }
    
    /**
     * Генерация уникального токена для отслеживания прогресса.
     */
    private String generateProgressToken() {
        return "progress-" + UUID.randomUUID().toString().substring(0, 8);
    }
    
    /**
     * Запуск сервера с STDIO транспортом.
     */
    public void start() {
        StdioServerTransport transport = new StdioServerTransport();
        server.connect(transport);
        
        System.err.println("=================================");
        System.err.println("FileTools MCP Server v1.0.0");
        System.err.println("=================================");
        System.err.println("Сервер запущен и готов к работе");
        System.err.println("Разрешенная директория: " + allowedDirectory);
        System.err.println("\\nДоступные инструменты:");
        System.err.println("  • file_search - поиск файлов");
        System.err.println("  • file_read - чтение файлов");
        System.err.println("  • text_analyze - анализ текста");
        System.err.println("  • hash_calculate - вычисление хеша");
    }
    
    /**
     * Точка входа приложения.
     */
    public static void main(String[] args) {
        // Определяем разрешенную директорию
        Path directory;
        
        if (args.length > 0) {
            // Используем аргумент командной строки
            directory = Paths.get(args[0]);
        } else {
            // По умолчанию - текущая директория
            directory = Paths.get(System.getProperty("user.dir"));
        }
        
        // Проверяем что директория существует
        if (!Files.exists(directory)) {
            System.err.println("❌ Ошибка: директория не существует: " + directory);
            System.exit(1);
        }
        
        if (!Files.isDirectory(directory)) {
            System.err.println("❌ Ошибка: путь не является директорией: " + directory);
            System.exit(1);
        }
        
        // Создаем и запускаем сервер
        FileToolsServer server = new FileToolsServer(directory);
        server.start();
    }
}
"""

# Объединяем части и записываем
full_solution = lab03_solution_part1 + lab03_solution_part2

with open("mcp-java-course/labs/lab-03-tools/solution/FileToolsServer.java", "w", encoding="utf-8") as f:
    f.write(full_solution)

# pom.xml для Lab 03
lab03_pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab03-tools</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
        
        <!-- Apache Commons Codec для хеширования -->
        <dependency>
            <groupId>commons-codec</groupId>
            <artifactId>commons-codec</artifactId>
            <version>1.16.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.11.0</version>
                <configuration>
                    <source>17</source>
                    <target>17</target>
                </configuration>
            </plugin>
            
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>com.example.mcp.lab03.FileToolsServer</mainClass>
                                </transformer>
                            </transformers>
                            <filters>
                                <filter>
                                    <artifact>*:*</artifact>
                                    <excludes>
                                        <exclude>META-INF/*.SF</exclude>
                                        <exclude>META-INF/*.DSA</exclude>
                                        <exclude>META-INF/*.RSA</exclude>
                                    </excludes>
                                </filter>
                            </filters>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
"""

with open("mcp-java-course/labs/lab-03-tools/solution/pom.xml", "w", encoding="utf-8") as f:
    f.write(lab03_pom)

print("✓ Файл создан: labs/lab-03-tools/solution/FileToolsServer.java")
print("✓ Файл создан: labs/lab-03-tools/solution/pom.xml")
