
# Lab 03 - Работа с продвинутыми Tools
lab03_readme = """# Lab 03: Работа с продвинутыми Tools

## Цель работы

Создать MCP-сервер с продвинутыми инструментами, демонстрирующими:
- Работу с файловой системой
- Progress notifications для длительных операций
- Обработку бинарных данных
- Валидацию и безопасность

## Задачи

1. Создать сервер с 4 продвинутыми инструментами:
   - `file_search` - поиск файлов в директории (с progress)
   - `file_read` - чтение файла с валидацией
   - `text_analyze` - анализ текста (подсчет слов, символов)
   - `hash_calculate` - вычисление хеша файла
2. Реализовать Progress tracking для долгих операций
3. Реализовать валидацию путей (защита от path traversal)
4. Добавить детальное логирование

## Шаг 1: Создание проекта

### pom.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example.mcp</groupId>
    <artifactId>lab03-tools</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <!-- MCP SDK -->
        <dependency>
            <groupId>io.modelcontextprotocol</groupId>
            <artifactId>mcp-sdk</artifactId>
            <version>0.5.0</version>
        </dependency>
        
        <!-- Apache Commons Codec для хеширования -->
        <dependency>
            <groupId>commons-codec</groupId>
            <artifactId>commons-codec</artifactId>
            <version>1.16.0</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>com.example.mcp.lab03.FileToolsServer</mainClass>
                                </transformer>
                            </transformers>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

## Шаг 2: Реализация сервера

Создайте файл `src/main/java/com/example/mcp/lab03/FileToolsServer.java`

### Задание

```java
package com.example.mcp.lab03;

import io.modelcontextprotocol.sdk.server.McpServer;
import io.modelcontextprotocol.sdk.schema.*;
import org.apache.commons.codec.digest.DigestUtils;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public class FileToolsServer {
    
    private final McpServer server;
    private final Path allowedDirectory;
    
    /**
     * TODO: Инициализируйте сервер
     * 
     * Требования:
     * 1. Сохраните allowedDirectory из параметра
     * 2. Создайте сервер с tools и logging capabilities
     * 3. Зарегистрируйте 4 инструмента
     */
    public FileToolsServer(Path allowedDirectory) {
        this.allowedDirectory = allowedDirectory;
        this.server = createServer();
    }
    
    private McpServer createServer() {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте список инструментов
     * 
     * Инструменты:
     * 1. file_search - поиск файлов
     *    Параметры: pattern (string), max_results (number, optional)
     * 
     * 2. file_read - чтение файла
     *    Параметры: path (string)
     * 
     * 3. text_analyze - анализ текста
     *    Параметры: text (string)
     * 
     * 4. hash_calculate - вычисление хеша
     *    Параметры: path (string), algorithm (string: "md5"|"sha256")
     */
    private List<Tool> provideTools() {
        // TODO: Ваш код здесь
        return List.of();
    }
    
    /**
     * TODO: Реализуйте обработчик вызовов
     * 
     * Требования:
     * 1. Логируйте каждый вызов
     * 2. Валидируйте пути (защита от path traversal)
     * 3. Отправляйте progress для file_search
     * 4. Обрабатывайте все исключения
     */
    private CallToolResult handleToolCall(CallToolRequest request) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте поиск файлов
     * 
     * Требования:
     * 1. Используйте Files.walk() для обхода директории
     * 2. Фильтруйте по pattern (case-insensitive)
     * 3. Отправляйте progress каждые 10 файлов
     * 4. Ограничьте результаты max_results
     * 5. Возвращайте список путей
     */
    private CallToolResult handleFileSearch(
            Map<String, JsonNode> arguments,
            String progressToken) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте чтение файла
     * 
     * Требования:
     * 1. Валидируйте путь (validatePath)
     * 2. Проверьте существование файла
     * 3. Проверьте размер (макс 1 МБ)
     * 4. Читайте как UTF-8 текст
     * 5. Возвращайте содержимое
     */
    private CallToolResult handleFileRead(Map<String, JsonNode> arguments) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте анализ текста
     * 
     * Требования:
     * 1. Подсчитайте количество символов
     * 2. Подсчитайте количество слов
     * 3. Подсчитайте количество строк
     * 4. Найдите самое длинное слово
     * 5. Верните результат в формате JSON-like текста
     */
    private CallToolResult handleTextAnalyze(Map<String, JsonNode> arguments) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * TODO: Реализуйте вычисление хеша
     * 
     * Требования:
     * 1. Валидируйте путь
     * 2. Проверьте algorithm ("md5" или "sha256")
     * 3. Используйте DigestUtils для вычисления
     * 4. Верните хеш в hex формате
     */
    private CallToolResult handleHashCalculate(Map<String, JsonNode> arguments) {
        // TODO: Ваш код здесь
        return null;
    }
    
    /**
     * ВАЖНО: Реализуйте валидацию пути
     * 
     * Эта функция защищает от path traversal атак.
     * 
     * Требования:
     * 1. Резолвьте путь относительно allowedDirectory
     * 2. Нормализуйте путь (resolve symlinks)
     * 3. Проверьте, что результат внутри allowedDirectory
     * 4. Бросьте SecurityException если путь невалидный
     */
    private Path validatePath(String relativePath) throws IOException {
        // TODO: Ваш код здесь
        // Подсказка: используйте Path.normalize() и startsWith()
        return null;
    }
    
    /**
     * Генерация уникального токена для progress
     */
    private String generateProgressToken() {
        return "progress-" + UUID.randomUUID().toString().substring(0, 8);
    }
    
    public void start() {
        StdioServerTransport transport = new StdioServerTransport();
        server.connect(transport);
        System.err.println("FileTools Server запущен");
        System.err.println("Разрешенная директория: " + allowedDirectory);
    }
    
    public static void main(String[] args) {
        // Используем текущую директорию или аргумент командной строки
        Path directory = args.length > 0 
            ? Paths.get(args[0]) 
            : Paths.get(System.getProperty("user.dir"));
        
        FileToolsServer server = new FileToolsServer(directory);
        server.start();
    }
}
```

## Шаг 3: Тестирование

### Тестовые данные

Создайте тестовую директорию со следующей структурой:

```
test-data/
├── file1.txt  (содержит: "Hello World")
├── file2.txt  (содержит: "Lorem ipsum dolor sit amet")
├── important.txt
└── subdir/
    ├── nested.txt
    └── data.json
```

### Запуск с MCP Inspector

```bash
# Соберите проект
mvn clean package

# Запустите Inspector
mcp-inspector java -jar target/lab03-tools-1.0-SNAPSHOT.jar ./test-data
```

### Тестовые сценарии

1. **file_search**: Поиск файлов с паттерном "txt"
   ```json
   {
     "pattern": "txt",
     "max_results": 10
   }
   ```
   Ожидается: список всех .txt файлов с progress уведомлениями

2. **file_read**: Чтение file1.txt
   ```json
   {
     "path": "file1.txt"
   }
   ```
   Ожидается: "Hello World"

3. **text_analyze**: Анализ текста
   ```json
   {
     "text": "The quick brown fox jumps over the lazy dog"
   }
   ```
   Ожидается: статистика (слов: 9, символов: 44, и т.д.)

4. **hash_calculate**: MD5 хеш файла
   ```json
   {
     "path": "file1.txt",
     "algorithm": "md5"
   }
   ```
   Ожидается: MD5 хеш

5. **Проверка безопасности**: Попытка path traversal
   ```json
   {
     "path": "../../../etc/passwd"
   }
   ```
   Ожидается: ошибка безопасности

## Критерии оценки

- [ ] Все 4 инструмента работают корректно
- [ ] Progress notifications отправляются при поиске файлов
- [ ] Валидация путей защищает от path traversal
- [ ] Обработка ошибок реализована для всех случаев
- [ ] Логирование работает на разных уровнях
- [ ] Размер файлов проверяется перед чтением

## Подсказки

<details>
<summary>Подсказка 1: Валидация пути</summary>

```java
private Path validatePath(String relativePath) throws IOException {
    // Резолвим путь относительно разрешенной директории
    Path resolved = allowedDirectory.resolve(relativePath).normalize();
    
    // Проверяем, что путь внутри разрешенной директории
    if (!resolved.startsWith(allowedDirectory)) {
        throw new SecurityException(
            "Path traversal attempt detected: " + relativePath
        );
    }
    
    return resolved;
}
```
</details>

<details>
<summary>Подсказка 2: Отправка Progress</summary>

```java
int filesProcessed = 0;
int totalFiles = 100; // примерное количество
String progressToken = generateProgressToken();

for (Path file : files) {
    filesProcessed++;
    
    // Отправляем прогресс каждые 10 файлов
    if (filesProcessed % 10 == 0) {
        server.sendProgress(progressToken, filesProcessed, totalFiles);
    }
    
    // Обрабатываем файл...
}
```
</details>

<details>
<summary>Подсказка 3: Анализ текста</summary>

```java
String text = arguments.get("text").asText();

int chars = text.length();
int lines = text.split("\\n").length;
String[] words = text.split("\\s+");
int wordCount = words.length;

String longestWord = Arrays.stream(words)
    .max(Comparator.comparingInt(String::length))
    .orElse("");

String result = String.format(
    "Анализ текста:\\n" +
    "  Символов: %d\\n" +
    "  Слов: %d\\n" +
    "  Строк: %d\\n" +
    "  Самое длинное слово: %s (%d символов)",
    chars, wordCount, lines, longestWord, longestWord.length()
);
```
</details>

## Дополнительные задания (опционально)

1. **Кеширование**: Добавьте кеш для прочитанных файлов
2. **Фильтры**: Добавьте фильтры по размеру и дате модификации
3. **Batch операции**: Добавьте инструмент для обработки множества файлов
4. **Статистика**: Добавьте инструмент для сбора статистики директории

## Следующие шаги

После успешного выполнения Lab 03 переходите к изучению Модуля 4 (Debugging и Testing), где узнаете:
- Как использовать MCP Inspector для отладки
- Как писать тесты для MCP-серверов
- Лучшие практики мониторинга и логирования
"""

with open("mcp-java-course/labs/lab-03-tools/README.md", "w", encoding="utf-8") as f:
    f.write(lab03_readme)

print("✓ Файл создан: labs/lab-03-tools/README.md")
