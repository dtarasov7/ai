
import os

# Создаем структуру для Сессии 2
session2_dirs = [
    "mcp-java-course/lectures/module-02-protocol/diagrams",
    "mcp-java-course/lectures/module-03-java-sdk/diagrams",
    "mcp-java-course/labs/lab-01-simple-server",
    "mcp-java-course/labs/lab-02-client",
    "mcp-java-course/labs/lab-03-tools",
]

for dir_path in session2_dirs:
    os.makedirs(dir_path, exist_ok=True)

print("=" * 60)
print("СЕССИЯ 2: Создание курса MCP + Java")
print("=" * 60)
print("\n📚 Будут созданы:")
print("  - Модуль 2: MCP-протокол (полная версия)")
print("  - Модуль 3: MCP SDK на Java")
print("  - Lab 01: Создание простого MCP-сервера")
print("  - Lab 02: Реализация MCP-клиента")
print("  - Lab 03: Работа с Tools")
print("\n🚀 Начинаем создание файлов...\n")
