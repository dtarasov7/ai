# Модуль 2: MCP-протокол

## Цели модуля

После изучения этого модуля вы:
- Поймете транспортные механизмы MCP (STDIO, HTTP/SSE)
- Узнаете четыре типа сообщений протокола
- Изучите возможности клиента и сервера (capabilities)
- Научитесь использовать утилиты: Progress, Cancellation, Ping
- Познакомитесь с MCP Inspector для отладки

---

## Transport Layer (Транспортный уровень)

MCP поддерживает несколько транспортных механизмов для обмена сообщениями между клиентом и сервером. Транспортный уровень отвечает за установление соединения, фреймирование сообщений и безопасную коммуникацию.

### STDIO Transport

**STDIO** (Standard Input/Output) транспорт использует стандартные потоки ввода-вывода для прямой коммуникации между процессами на одной машине.

#### Характеристики STDIO

- ✅ **Производительность**: Оптимальная, без сетевых накладных расходов
- ✅ **Простота**: Легко реализовать и отлаживать
- ✅ **Локальность**: Только для процессов на одной машине
- ✅ **Безопасность**: Не требует аутентификации (процессы на одной машине)
- ❌ **Ограничение**: Не подходит для удаленного доступа

#### Когда использовать STDIO

- Desktop приложения (Claude Desktop, VS Code)
- Локальные инструменты разработки
- Быстрое прототипирование
- Отладка и тестирование

#### Пример STDIO Transport в Java

```java
package com.example.mcp.transport;

import io.modelcontextprotocol.sdk.transport.StdioTransport;
import io.modelcontextprotocol.sdk.server.McpServer;

/**
 * Пример запуска MCP-сервера с STDIO транспортом.
 * 
 * STDIO идеален для локальных интеграций, например,
 * когда Claude Desktop запускает сервер как дочерний процесс.
 */
public class StdioServerExample {

    public static void main(String[] args) {
        // Создаем транспорт, использующий stdin/stdout
        // stdin - для получения запросов от клиента
        // stdout - для отправки ответов клиенту
        StdioTransport transport = new StdioTransport();

        // Настраиваем сервер с базовыми возможностями
        McpServer server = McpServer.builder()
            .serverInfo(Implementation.builder()
                .name("stdio-example-server")
                .version("1.0.0")
                .build())
            .capabilities(ServerCapabilities.builder()
                .tools(ToolsCapability.builder().build())
                .build())
            .build();

        // Запускаем сервер с STDIO транспортом
        // После этого вызова сервер начнет слушать stdin
        server.connect(transport);

        // ВАЖНО: Логи выводим в stderr, т.к. stdout используется для протокола
        System.err.println("Сервер запущен с STDIO транспортом");
        System.err.println("Готов принимать MCP-запросы через stdin");
    }
}
```

#### Конфигурация STDIO для Claude Desktop

Чтобы Claude Desktop мог использовать ваш MCP-сервер, добавьте конфигурацию:

**Файл**: `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS)

```json
{
  "mcpServers": {
    "my-java-server": {
      "command": "java",
      "args": [
        "-jar",
        "/absolute/path/to/my-server.jar"
      ],
      "env": {
        "DATABASE_URL": "jdbc:postgresql://localhost/mydb"
      }
    }
  }
}
```

### HTTP/SSE Transport

**HTTP** транспорт использует HTTP POST для отправки сообщений от клиента к серверу, с опциональной поддержкой **Server-Sent Events (SSE)** для потоковой передачи данных от сервера.

#### Характеристики HTTP/SSE

- ✅ **Удаленный доступ**: Работает через сеть (интернет/интранет)
- ✅ **Стандартная аутентификация**: Bearer tokens, API keys, OAuth
- ✅ **Потоковая передача**: SSE для real-time обновлений
- ✅ **Масштабируемость**: Можно использовать load balancers, кластеризацию
- ✅ **Интеграция**: Легко интегрируется с существующими веб-сервисами
- ⚠️ **Сложность**: Требует настройки HTTP-сервера и аутентификации

#### Когда использовать HTTP/SSE

- Веб-приложения и SaaS решения
- Микросервисная архитектура
- Удаленный доступ к серверам
- Cloud deployments
- API-first подход

#### Пример HTTP Transport в Java (Spring Boot)

```java
package com.example.mcp.transport;

import io.modelcontextprotocol.sdk.server.McpServer;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * HTTP-контроллер для обработки MCP-запросов через REST API.
 * 
 * Endpoints:
 * - POST /mcp/messages - отправка JSON-RPC запросов
 * - GET /mcp/sse - подписка на Server-Sent Events
 */
@RestController
@RequestMapping("/mcp")
public class HttpMcpController {

    private final McpServer mcpServer;

    /**
     * Конструктор с внедрением зависимости MCP-сервера.
     * 
     * @param mcpServer настроенный MCP-сервер
     */
    public HttpMcpController(McpServer mcpServer) {
        this.mcpServer = mcpServer;
    }

    /**
     * Endpoint для обработки MCP-запросов через HTTP POST.
     * 
     * Клиент отправляет JSON-RPC запросы в теле POST-запроса,
     * сервер обрабатывает их и возвращает JSON-RPC ответы.
     * 
     * Пример запроса:
     * POST /mcp/messages
     * Authorization: Bearer <token>
     * Content-Type: application/json
     * 
     * {"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}
     * 
     * @param request JSON-RPC запрос в виде строки
     * @param authorization токен аутентификации из заголовка
     * @return JSON-RPC ответ
     */
    @PostMapping(
        value = "/messages", 
        consumes = "application/json", 
        produces = "application/json"
    )
    public String handleMessage(
            @RequestBody String request,
            @RequestHeader(value = "Authorization", required = false) 
            String authorization) {

        // Проверка аутентификации
        if (!isValidToken(authorization)) {
            return createErrorResponse(-32000, "Unauthorized");
        }

        // Обработка MCP-запроса через сервер
        // Сервер парсит JSON-RPC, вызывает нужный handler и формирует ответ
        try {
            return mcpServer.handleRequest(request);
        } catch (Exception e) {
            return createErrorResponse(-32603, "Internal error: " + e.getMessage());
        }
    }

    /**
     * SSE endpoint для потоковых уведомлений от сервера к клиенту.
     * 
     * Используется для асинхронных событий:
     * - Progress notifications (прогресс выполнения)
     * - Log messages (логи)
     * - Resource updates (изменения ресурсов)
     * - Tool list changes (изменения списка инструментов)
     * 
     * Пример использования:
     * GET /mcp/sse
     * Authorization: Bearer <token>
     * Accept: text/event-stream
     * 
     * @return поток Server-Sent Events
     */
    @GetMapping(value = "/sse", produces = "text/event-stream")
    public SseEmitter subscribeToEvents(
            @RequestHeader(value = "Authorization", required = false) 
            String authorization) {

        // Проверка аутентификации
        if (!isValidToken(authorization)) {
            throw new UnauthorizedException("Invalid token");
        }

        // Создаем SSE emitter с бесконечным таймаутом
        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);

        // Регистрируем emitter в сервере для получения событий
        mcpServer.registerEventEmitter(emitter);

        // При закрытии соединения удаляем emitter
        emitter.onCompletion(() -> mcpServer.unregisterEventEmitter(emitter));
        emitter.onTimeout(() -> mcpServer.unregisterEventEmitter(emitter));
        emitter.onError((e) -> mcpServer.unregisterEventEmitter(emitter));

        return emitter;
    }

    /**
     * Валидация токена аутентификации.
     * 
     * В production используйте:
     * - OAuth2 / OpenID Connect
     * - JWT (JSON Web Tokens)
     * - API Keys с rate limiting
     * 
     * @param authorization заголовок Authorization
     * @return true если токен валидный
     */
    private boolean isValidToken(String authorization) {
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            return false;
        }

        String token = authorization.substring(7);

        // Проверяем токен (в примере - простая проверка по env variable)
        // В production используйте proper token validation
        return token.equals(System.getenv("MCP_API_KEY"));
    }

    /**
     * Создание JSON-RPC error response.
     * 
     * @param code код ошибки
     * @param message сообщение об ошибке
     * @return JSON-RPC error response
     */
    private String createErrorResponse(int code, String message) {
        return String.format(
            "{"jsonrpc":"2.0","error":{"code":%d,"message":"%s"},"id":null}",
            code,
            message.replace(""", "\"")
        );
    }
}
```

#### Пример HTTP Client

```java
package com.example.mcp.client;

import io.modelcontextprotocol.sdk.client.McpClient;
import io.modelcontextprotocol.sdk.transport.HttpTransport;

/**
 * Пример создания MCP-клиента с HTTP транспортом
 * для подключения к удаленному серверу.
 */
public class HttpClientExample {

    /**
     * Создание и настройка HTTP MCP-клиента.
     * 
     * @return настроенный клиент, готовый к работе
     */
    public McpClient createHttpClient() {
        // Настраиваем HTTP транспорт с аутентификацией
        HttpTransport transport = HttpTransport.builder()
            .endpoint("https://api.example.com/mcp/messages")
            .sseEndpoint("https://api.example.com/mcp/sse")
            // Добавляем заголовок аутентификации
            .header("Authorization", "Bearer " + System.getenv("API_KEY"))
            // Включаем SSE для получения уведомлений
            .sseEnabled(true)
            // Настраиваем таймауты
            .connectTimeout(10000) // 10 секунд на подключение
            .readTimeout(30000)    // 30 секунд на чтение
            .build();

        // Создаем клиента с настроенным транспортом
        McpClient client = McpClient.builder()
            .transport(transport)
            .clientInfo(Implementation.builder()
                .name("my-http-client")
                .version("1.0.0")
                .build())
            .build();

        return client;
    }

    /**
     * Использование HTTP клиента.
     */
    public void useClient() throws Exception {
        McpClient client = createHttpClient();

        // Подключаемся к серверу
        client.connect();

        // Теперь можем использовать клиента
        List<Tool> tools = client.listTools();
        System.out.println("Доступно инструментов: " + tools.size());

        // Закрываем соединение по завершению работы
        client.disconnect();
    }
}
```

### Сравнение транспортов

| Характеристика | STDIO | HTTP/SSE |
|----------------|-------|----------|
| **Расположение** | Только локально | Удаленно и локально |
| **Производительность** | Отличная (без сети) | Хорошая (сетевая задержка) |
| **Аутентификация** | Не требуется | OAuth, Bearer tokens, API keys |
| **Сложность реализации** | Низкая | Средняя/Высокая |
| **Use case** | Desktop приложения | Web сервисы, микросервисы |
| **Масштабируемость** | Один процесс | Высокая (load balancing) |
| **Отладка** | Простая (логи в stderr) | Требует HTTP tools (curl, Postman) |
| **Deployment** | Executable jar | Docker, Kubernetes, Cloud |

---

## Message Types (Типы сообщений)

MCP использует **JSON-RPC 2.0** для обмена сообщениями. Существует **четыре основных типа** сообщений:

### 1. Request (Запрос)

**Request** — сообщение, требующее ответа от получателя.

#### Структура Request

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "method": "tools/call",
  "params": {
    "name": "get_weather",
    "arguments": {
      "city": "Moscow"
    }
  }
}
```

#### Поля Request

- **jsonrpc**: Версия протокола (всегда "2.0")
- **id**: Уникальный идентификатор запроса (string | number | null)
- **method**: Имя вызываемого метода
- **params**: Параметры метода (optional, object или array)

#### Важные методы MCP

| Метод | Описание | Вызывает |
|-------|----------|----------|
| `initialize` | Инициализация соединения | Client |
| `tools/list` | Получить список инструментов | Client |
| `tools/call` | Вызвать инструмент | Client |
| `resources/list` | Получить список ресурсов | Client |
| `resources/read` | Прочитать ресурс | Client |
| `prompts/list` | Получить список промптов | Client |
| `prompts/get` | Получить промпт | Client |
| `sampling/createMessage` | Запрос к LLM | Server |
| `ping` | Проверка соединения | Client/Server |

#### Пример отправки Request в Java

```java
package com.example.mcp.protocol;

import io.modelcontextprotocol.sdk.schema.*;
import java.util.Map;

/**
 * Примеры создания и отправки различных типов Request.
 */
public class RequestExamples {

    /**
     * Отправка запроса на вызов инструмента.
     * Request всегда имеет id и ожидает Response.
     */
    public void sendToolCallRequest(McpSession session) {
        // Формируем параметры вызова инструмента
        Map<String, Object> arguments = Map.of(
            "city", "Moscow",
            "units", "celsius"
        );

        // Создаем запрос с помощью builder pattern
        CallToolRequest request = CallToolRequest.builder()
            .method("tools/call")
            .params(CallToolParams.builder()
                .name("get_weather")
                .arguments(arguments)
                .build())
            .build();

        // Отправляем запрос и ОЖИДАЕМ ответ
        // Метод блокирующий - будет ждать, пока сервер не ответит
        CallToolResult result = session.callTool(request);

        System.out.println("Результат: " + result.content());
    }

    /**
     * Запрос списка доступных ресурсов.
     */
    public void listResources(McpSession session) {
        // Создаем запрос без параметров
        ListResourcesRequest request = ListResourcesRequest.builder()
            .method("resources/list")
            .build();

        // Отправляем и получаем список ресурсов
        ListResourcesResult result = session.listResources(request);

        // Обрабатываем результат
        for (Resource resource : result.resources()) {
            System.out.println("Ресурс: " + resource.name());
            System.out.println("  URI: " + resource.uri());
            System.out.println("  Тип: " + resource.mimeType());
        }
    }

    /**
     * Чтение содержимого ресурса.
     */
    public void readResource(McpSession session, String uri) {
        // Создаем запрос с URI ресурса
        ReadResourceRequest request = ReadResourceRequest.builder()
            .method("resources/read")
            .params(ReadResourceParams.builder()
                .uri(uri)
                .build())
            .build();

        // Читаем ресурс
        ReadResourceResult result = session.readResource(request);

        // Обрабатываем содержимое
        for (ResourceContents content : result.contents()) {
            if (content.text() != null) {
                System.out.println("Текст: " + content.text());
            }
            if (content.blob() != null) {
                System.out.println("Бинарные данные: " + content.blob().length + " байт");
            }
        }
    }
}
```

### 2. Response (Ответ)

**Response** — ответ на Request, содержащий либо результат, либо ошибку.

#### Структура Success Response

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Температура в Москве: 5°C, облачно"
      }
    ]
  }
}
```

#### Поля Response

- **jsonrpc**: "2.0"
- **id**: Соответствует id из Request
- **result**: Результат выполнения (при успехе)
- **error**: Объект ошибки (при неудаче) - **взаимоисключающее с result**

#### Пример обработки Response

```java
package com.example.mcp.protocol;

/**
 * Примеры обработки различных типов Response.
 */
public class ResponseExamples {

    /**
     * Обработка ответа от вызова инструмента.
     * Response всегда связан с Request через id.
     */
    public void handleToolCallResponse(CallToolResult result) {
        // Проверяем наличие контента
        if (result.content() == null || result.content().isEmpty()) {
            System.out.println("Пустой ответ от инструмента");
            return;
        }

        // Обрабатываем каждый элемент контента
        // Контент может быть разных типов
        for (Content content : result.content()) {
            if (content instanceof TextContent textContent) {
                // Текстовый контент - самый распространенный
                System.out.println("Текст: " + textContent.text());

            } else if (content instanceof ImageContent imageContent) {
                // Изображение в base64
                System.out.println("Изображение: " + imageContent.mimeType());
                System.out.println("Размер: " + imageContent.data().length() + " символов");

            } else if (content instanceof ResourceContent resourceContent) {
                // Ссылка на ресурс
                System.out.println("Ресурс: " + resourceContent.uri());

            } else if (content instanceof EmbeddedResource embeddedResource) {
                // Встроенный ресурс с данными
                System.out.println("Встроенный ресурс: " + embeddedResource.resource().uri());
            }
        }

        // Проверяем флаг isError
        // Даже если tool выполнился, он может вернуть логическую ошибку
        if (result.isError() != null && result.isError()) {
            System.err.println("Инструмент вернул ошибку (но не exception)");
        }
    }

    /**
     * Извлечение текста из результата.
     * Utility метод для получения простого текстового ответа.
     */
    public String extractText(CallToolResult result) {
        if (result.content() == null || result.content().isEmpty()) {
            return "";
        }

        // Ищем первый текстовый контент
        return result.content().stream()
            .filter(c -> c instanceof TextContent)
            .map(c -> ((TextContent) c).text())
            .findFirst()
            .orElse("");
    }

    /**
     * Проверка успешности выполнения.
     */
    public boolean isSuccess(CallToolResult result) {
        // Проверяем, что есть контент и нет флага ошибки
        boolean hasContent = result.content() != null && !result.content().isEmpty();
        boolean noError = result.isError() == null || !result.isError();

        return hasContent && noError;
    }
}
```

### 3. Error (Ошибка)

**Error** — специальный тип Response, указывающий на ошибку выполнения запроса.

#### Структура Error Response

```json
{
  "jsonrpc": "2.0",
  "id": "123",
  "error": {
    "code": -32601,
    "message": "Method not found",
    "data": {
      "method": "unknown/method"
    }
  }
}
```

#### Стандартные коды ошибок JSON-RPC

| Код | Константа | Описание |
|-----|-----------|----------|
| -32700 | Parse error | Невалидный JSON |
| -32600 | Invalid Request | Невалидная структура запроса |
| -32601 | Method not found | Метод не существует |
| -32602 | Invalid params | Невалидные параметры метода |
| -32603 | Internal error | Внутренняя ошибка сервера |
| -32000 to -32099 | Server error | Серверные ошибки (custom) |

#### Пример обработки ошибок

```java
package com.example.mcp.protocol;

import io.modelcontextprotocol.sdk.McpError;
import java.io.IOException;

/**
 * Комплексная обработка ошибок при работе с MCP.
 */
public class ErrorHandlingExamples {

    /**
     * Обработка ошибок при вызове инструмента.
     * 
     * Важно различать:
     * - Сетевые ошибки (IOException)
     * - Ошибки протокола (McpError)
     * - Логические ошибки бизнес-логики (isError flag)
     */
    public void callToolWithErrorHandling(McpSession session) {
        try {
            // Попытка вызвать несуществующий инструмент
            CallToolRequest request = CallToolRequest.builder()
                .params(CallToolParams.builder()
                    .name("non_existent_tool")
                    .build())
                .build();

            CallToolResult result = session.callTool(request);

            // Проверяем логические ошибки
            if (result.isError() != null && result.isError()) {
                System.err.println("Логическая ошибка выполнения tool");
                return;
            }

            // Успешный результат
            System.out.println("Успех: " + result.content());

        } catch (McpError e) {
            // MCP protocol error - сервер вернул JSON-RPC error
            handleMcpError(e);

        } catch (IOException e) {
            // Transport/network error - проблемы с соединением
            System.err.println("Ошибка соединения: " + e.getMessage());
            System.err.println("Попытка переподключения...");
            // Здесь можно реализовать retry logic

        } catch (Exception e) {
            // Unexpected error - непредвиденная ошибка
            System.err.println("Неожиданная ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Детальная обработка MCP-ошибок по кодам.
     */
    private void handleMcpError(McpError error) {
        int code = error.getCode();
        String message = error.getMessage();

        switch (code) {
            case -32700 -> {
                // Parse error - проблема с JSON
                System.err.println("Ошибка парсинга JSON: " + message);
                System.err.println("Проверьте формат отправляемых данных");
            }

            case -32600 -> {
                // Invalid Request
                System.err.println("Невалидный запрос: " + message);
                System.err.println("Проверьте структуру JSON-RPC запроса");
            }

            case -32601 -> {
                // Method not found
                System.err.println("Метод не найден: " + message);
                System.err.println("Доступные методы:");
                // Можно вывести список доступных методов
            }

            case -32602 -> {
                // Invalid params
                System.err.println("Невалидные параметры: " + message);
                if (error.getData() != null) {
                    System.err.println("Ожидаемые параметры: " + error.getData());
                }
            }

            case -32603 -> {
                // Internal error
                System.err.println("Внутренняя ошибка сервера: " + message);
                System.err.println("Свяжитесь с администратором сервера");
            }

            default -> {
                // Custom server error
                if (code >= -32099 && code <= -32000) {
                    System.err.println("Ошибка сервера [" + code + "]: " + message);
                } else {
                    System.err.println("MCP ошибка [" + code + "]: " + message);
                }
            }
        }

        // Вывод дополнительных данных об ошибке
        if (error.getData() != null) {
            System.err.println("Дополнительная информация:");
            System.err.println(error.getData());
        }
    }

    /**
     * Retry logic с экспоненциальным backoff.
     */
    public <T> T retryWithBackoff(
            Callable<T> operation,
            int maxAttempts,
            long initialDelayMs) throws Exception {

        Exception lastException = null;
        long delay = initialDelayMs;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return operation.call();

            } catch (IOException e) {
                // Сетевая ошибка - можно повторить
                lastException = e;

                if (attempt < maxAttempts) {
                    System.err.println(
                        String.format("Попытка %d/%d не удалась, повтор через %d мс", 
                        attempt, maxAttempts, delay)
                    );
                    Thread.sleep(delay);
                    delay *= 2; // Экспоненциальный backoff
                }

            } catch (McpError e) {
                // Protocol error - обычно не имеет смысла повторять
                throw e;
            }
        }

        throw lastException;
    }
}
```

### 4. Notification (Уведомление)

**Notification** — сообщение, которое не требует ответа. Используется для асинхронных событий.

#### Структура Notification

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "task-123",
    "progress": 50,
    "total": 100
  }
}
```

#### Отличия Notification от Request

- ❌ **Нет поля `id`** — получатель не отправляет ответ
- ✅ **Односторонняя коммуникация** — fire-and-forget
- ✅ **Асинхронные события** — прогресс, логи, изменения состояния
- ✅ **Не блокирует** — отправитель продолжает работу сразу

#### Типы уведомлений в MCP

| Notification | Направление | Назначение |
|--------------|-------------|------------|
| `notifications/initialized` | Client → Server | Клиент завершил инициализацию |
| `notifications/progress` | Server → Client | Обновление прогресса операции |
| `notifications/message` | Server → Client | Лог-сообщение |
| `notifications/resources/updated` | Server → Client | Ресурс изменился |
| `notifications/resources/list_changed` | Server → Client | Список ресурсов изменился |
| `notifications/tools/list_changed` | Server → Client | Список инструментов изменился |
| `notifications/prompts/list_changed` | Server → Client | Список промптов изменился |
| `notifications/cancelled` | Client → Server | Запрос отменен |
| `notifications/roots/list_changed` | Client → Server | Список корневых директорий изменился |

#### Пример отправки Notifications

```java
package com.example.mcp.protocol;

/**
 * Примеры отправки различных типов уведомлений.
 */
public class NotificationExamples {

    /**
     * Отправка уведомления о прогрессе выполнения задачи.
     * 
     * Используется для длительных операций, чтобы клиент
     * мог показывать пользователю прогресс-бар.
     */
    public void sendProgressNotification(
            McpSession session, 
            String progressToken,
            int progress, 
            int total) {

        // Формируем уведомление о прогрессе
        ProgressNotification notification = ProgressNotification.builder()
            .method("notifications/progress")
            .params(ProgressParams.builder()
                .progressToken(progressToken)
                .progress(progress)
                .total(total)
                .build())
            .build();

        // Отправляем БЕЗ ожидания ответа
        // Метод возвращается сразу после отправки
        session.sendNotification(notification);

        System.err.println(
            String.format("Прогресс отправлен: %d/%d (%.1f%%)", 
            progress, total, (progress * 100.0 / total))
        );
    }

    /**
     * Отправка лог-сообщения клиенту.
     * Используется для отладки и мониторинга.
     */
    public void sendLogNotification(
            McpSession session,
            String level,
            String message,
            String logger) {

        LoggingMessageNotification notification = 
            LoggingMessageNotification.builder()
                .method("notifications/message")
                .params(LoggingMessageParams.builder()
                    // Уровни: debug, info, notice, warning, error, critical, alert, emergency
                    .level(level)
                    .data(message)
                    .logger(logger)
                    .build())
                .build();

        session.sendNotification(notification);
    }

    /**
     * Уведомление об изменении ресурса.
     * Клиент может перечитать ресурс для получения актуальных данных.
     */
    public void notifyResourceUpdated(McpSession session, String uri) {
        ResourceUpdatedNotification notification = 
            ResourceUpdatedNotification.builder()
                .method("notifications/resources/updated")
                .params(ResourceUpdatedParams.builder()
                    .uri(uri)
                    .build())
                .build();

        session.sendNotification(notification);

        System.err.println("Клиент уведомлен об изменении ресурса: " + uri);
    }

    /**
     * Уведомление об изменении списка инструментов.
     * Клиент должен вызвать tools/list для получения обновленного списка.
     */
    public void notifyToolsListChanged(McpSession session) {
        ToolListChangedNotification notification = 
            ToolListChangedNotification.builder()
                .method("notifications/tools/list_changed")
                .build();

        session.sendNotification(notification);

        System.err.println("Клиент уведомлен об изменении списка tools");
    }

    /**
     * Пример использования Progress в длительной операции.
     */
    public CallToolResult longRunningOperationWithProgress(
            CallToolRequest request,
            McpSession session) {

        // Генерируем уникальный токен для отслеживания прогресса
        String progressToken = "operation-" + UUID.randomUUID();
        int totalSteps = 100;

        // Отправляем начальный прогресс
        sendProgressNotification(session, progressToken, 0, totalSteps);

        List<String> results = new ArrayList<>();

        for (int i = 0; i < totalSteps; i++) {
            // Выполняем шаг обработки
            String stepResult = processStep(i);
            results.add(stepResult);

            // Отправляем обновление прогресса каждые 10 шагов
            if ((i + 1) % 10 == 0) {
                sendProgressNotification(session, progressToken, i + 1, totalSteps);
            }

            // Имитация работы
            Thread.sleep(100);
        }

        // Отправляем финальный прогресс
        sendProgressNotification(session, progressToken, totalSteps, totalSteps);

        // Возвращаем результат
        return CallToolResult.builder()
            .content(List.of(
                TextContent.builder()
                    .text("Обработано шагов: " + totalSteps + "\n" +
                          String.join("\n", results))
                    .build()
            ))
            .build();
    }
}
```

#### Пример получения Notifications

```java
package com.example.mcp.client;

/**
 * Регистрация обработчиков уведомлений на клиенте.
 */
public class NotificationHandlerExamples {

    /**
     * Настройка всех handlers для уведомлений от сервера.
     * Клиент подписывается на различные типы событий.
     */
    public void setupNotificationHandlers(McpClient client) {

        // Обработчик прогресса
        client.onProgress((progressToken, progress, total) -> {
            double percentage = (progress * 100.0) / total;

            System.out.printf(
                "Задача %s: %.1f%% (%d/%d)%n",
                progressToken, percentage, progress, total
            );

            // Можно обновить UI прогресс-бар
            updateProgressBar(progressToken, percentage);
        });

        // Обработчик логов
        client.onLog((level, message, logger) -> {
            // Форматируем лог-сообщение с уровнем и временем
            String timestamp = Instant.now().toString();
            System.out.printf(
                "[%s] [%s] %s: %s%n", 
                timestamp, level, logger, message
            );

            // Можно направлять логи в файл или систему мониторинга
            if ("error".equals(level) || "critical".equals(level)) {
                sendToMonitoringSystem(level, message);
            }
        });

        // Обработчик изменения ресурсов
        client.onResourcesChanged((uri) -> {
            System.out.println("Ресурс изменен: " + uri);

            // Перечитываем ресурс для получения актуальных данных
            try {
                ReadResourceResult result = client.readResource(uri);
                System.out.println("Обновленные данные получены");
            } catch (Exception e) {
                System.err.println("Ошибка чтения обновленного ресурса: " + e);
            }
        });

        // Обработчик изменения списка инструментов
        client.onToolsChanged(() -> {
            System.out.println("Список инструментов изменен, обновляем...");

            try {
                // Запрашиваем обновленный список
                List<Tool> tools = client.listTools();
                System.out.println("Доступно инструментов: " + tools.size());

                // Обновляем UI или внутренний кеш
                updateToolsCache(tools);

            } catch (Exception e) {
                System.err.println("Ошибка обновления списка tools: " + e);
            }
        });

        // Обработчик изменения списка промптов
        client.onPromptsChanged(() -> {
            System.out.println("Список промптов изменен");

            try {
                List<Prompt> prompts = client.listPrompts();
                updatePromptsCache(prompts);
            } catch (Exception e) {
                System.err.println("Ошибка обновления списка prompts: " + e);
            }
        });

        System.out.println("Все notification handlers настроены");
    }

    // Заглушки для методов обновления UI
    private void updateProgressBar(String token, double percentage) {
        // Реализация обновления прогресс-бара в UI
    }

    private void sendToMonitoringSystem(String level, String message) {
        // Отправка критичных логов в систему мониторинга
    }

    private void updateToolsCache(List<Tool> tools) {
        // Обновление кеша инструментов
    }

    private void updatePromptsCache(List<Prompt> prompts) {
        // Обновление кеша промптов
    }
}
```

---

## Резюме модуля

### Что вы узнали:

✅ **Transport Layer**: STDIO для локальных процессов, HTTP/SSE для удаленного доступа

✅ **Message Types**:
   - **Request** — запрос с ожиданием ответа
   - **Response** — ответ с результатом или ошибкой
   - **Error** — структурированная обработка ошибок
   - **Notification** — асинхронные события без ответа

✅ **Error Handling**: Стандартные коды ошибок JSON-RPC и best practices

✅ **Notifications**: Прогресс, логи, обновления ресурсов и инструментов

### Следующие шаги:

В следующем модуле вы узнаете про MCP SDK на Java:
- Обзор официальной библиотеки
- Детальная реализация клиента
- Детальная реализация сервера
- Работа с capabilities

---

## Дополнительные материалы

- [MCP Protocol Specification](https://modelcontextprotocol.io/specification/)
- [JSON-RPC 2.0 Specification](https://www.jsonrpc.org/specification)
- [MCP Transport Documentation](https://modelcontextprotocol.io/docs/concepts/transports)
