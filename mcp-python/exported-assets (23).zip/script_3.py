
# Lab 3: Файловый менеджер (создам компактную версию из-за размера)

lab3_task = """# Лабораторная работа 3: Файловый менеджер

## Цель работы

Создать безопасный MCP-сервер для работы с файловой системой с акцентом на безопасность.

## Задание

Реализуйте "file-manager-server" с безопасным доступом к файлам.

### Инструменты

1. **list_directory** - Список файлов в директории
2. **read_file** - Чтение файла
3. **write_file** - Запись в файл
4. **search_files** - Поиск по имени
5. **get_file_info** - Метаданные файла
6. **create_directory** - Создание директории

### Безопасность

1. **Path traversal** защита - запретить `../`
2. **Root directory** ограничение
3. **File size** лимиты (10MB)
4. **Extensions whitelist** - только текстовые файлы

## Критерии оценки

- ✅ Все инструменты работают (40%)
- ✅ Безопасность реализована (40%)
- ✅ Обработка ошибок (20%)

## Время выполнения

**Ожидаемое время**: 3-4 часа
"""

lab3_solution = '''"""
Лабораторная работа 3: Файловый менеджер - Решение
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import List
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Server("file-manager-server")

# Конфигурация безопасности
ROOT_DIR = Path(os.getenv("ROOT_DIR", "./sandbox")).resolve()
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
ALLOWED_EXTENSIONS = {".txt", ".md", ".json", ".py", ".js", ".html", ".css"}


class FileSystemSecurity:
    """Модуль безопасности для работы с файлами"""
    
    @staticmethod
    def validate_path(path: str) -> Path:
        """Валидация пути - защита от path traversal"""
        # Резолвим путь относительно ROOT_DIR
        full_path = (ROOT_DIR / path).resolve()
        
        # Проверяем, что путь внутри ROOT_DIR
        if not str(full_path).startswith(str(ROOT_DIR)):
            raise ValueError(f"Доступ запрещен: путь за пределами root директории")
        
        return full_path
    
    @staticmethod
    def check_extension(path: Path) -> bool:
        """Проверка расширения файла"""
        if path.suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError(f"Расширение {path.suffix} не разрешено")
        return True
    
    @staticmethod
    def check_size(path: Path) -> bool:
        """Проверка размера файла"""
        if path.exists() and path.stat().st_size > MAX_FILE_SIZE:
            raise ValueError(f"Файл слишком большой (макс. {MAX_FILE_SIZE/1024/1024}MB)")
        return True


@app.list_tools()
async def list_tools() -> List[Tool]:
    return [
        Tool(
            name="list_directory",
            description="Список файлов и директорий",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Путь к директории", "default": "."}
                }
            }
        ),
        Tool(
            name="read_file",
            description="Читает содержимое текстового файла",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Путь к файлу"}
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="write_file",
            description="Записывает содержимое в файл",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Путь к файлу"},
                    "content": {"type": "string", "description": "Содержимое"}
                },
                "required": ["path", "content"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> List[TextContent]:
    security = FileSystemSecurity()
    
    try:
        if name == "list_directory":
            path = security.validate_path(arguments.get("path", "."))
            
            if not path.is_dir():
                return [TextContent(type="text", text=f"❌ {path} не является директорией")]
            
            items = []
            for item in sorted(path.iterdir()):
                icon = "📁" if item.is_dir() else "📄"
                items.append(f"{icon} {item.name}")
            
            return [TextContent(type="text", text="\\n".join(items) if items else "Директория пуста")]
        
        elif name == "read_file":
            path = security.validate_path(arguments["path"])
            security.check_extension(path)
            security.check_size(path)
            
            content = path.read_text(encoding="utf-8")
            return [TextContent(type="text", text=content)]
        
        elif name == "write_file":
            path = security.validate_path(arguments["path"])
            security.check_extension(path)
            content = arguments["content"]
            
            # Проверка размера содержимого
            if len(content.encode()) > MAX_FILE_SIZE:
                return [TextContent(type="text", text="❌ Содержимое слишком большое")]
            
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            
            return [TextContent(type="text", text=f"✅ Файл {path.name} сохранен")]
        
    except ValueError as e:
        return [TextContent(type="text", text=f"❌ {str(e)}")]
    except Exception as e:
        logger.error(f"Ошибка: {e}", exc_info=True)
        return [TextContent(type="text", text=f"❌ Ошибка: {str(e)}")]


async def main():
    # Создаем sandbox директорию
    ROOT_DIR.mkdir(exist_ok=True)
    logger.info(f"Root directory: {ROOT_DIR}")
    
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
'''

# Сохраняю Lab 3
with open("mcp_course/labs/lab_03_file_manager/task.md", "w", encoding="utf-8") as f:
    f.write(lab3_task)

with open("mcp_course/labs/lab_03_file_manager/solution/server.py", "w", encoding="utf-8") as f:
    f.write(lab3_solution)

print("✅ Лабораторная работа 3 создана (компактная версия)")
