
import os

# Проверяю и создаю структуру для лабораторных
labs_dirs = [
    "mcp_course/labs/lab_01_first_server/solution",
    "mcp_course/labs/lab_02_weather_service/solution",
    "mcp_course/labs/lab_03_file_manager/solution",
    "mcp_course/labs/lab_04_database_connector/solution",
    "mcp_course/labs/lab_05_full_application/solution",
]

for directory in labs_dirs:
    os.makedirs(directory, exist_ok=True)

print("✅ Структура для лабораторных работ готова")
print("\n🚀 Начинаю создание всех лабораторных работ...")
