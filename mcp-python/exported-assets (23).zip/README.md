# Полный курс по Model Context Protocol (MCP) и Python

Комплексный обучающий курс по разработке MCP-серверов и интеграции с языковыми моделями.

## 📚 Содержание курса

### Теоретические модули

#### Модуль 1: Введение в MCP
- **Лекция**: Архитектура MCP, роль в экосистеме LLM
- **Диаграммы**: Mindmap концепций, архитектура хост-клиент-сервер
- **Время изучения**: 1-2 часа

#### Модуль 2: MCP-протокол
- **Лекция**: JSON-RPC, транспорты (stdio/HTTP), типы сообщений, capabilities
- **Диаграммы**: Transport mechanisms, message types, capabilities
- **Время изучения**: 2-3 часа

#### Модуль 3: Python SDK
- **Лекция**: Работа с MCP Python SDK
- **Примеры кода**: 6 полностью рабочих серверов
  - Basic server (калькулятор)
  - Basic client
  - Server with multiple tools
  - Server with resources
  - Server with prompts
  - Full-featured server (заметки и задачи)
- **Диаграммы**: SDK architecture, mindmap
- **Время изучения**: 4-6 часов

#### Модуль 4: Отладка и мониторинг
- **Лекция**: Логирование, MCP Inspector, диагностика проблем
- **Примеры кода**: 
  - Logging example (все уровни логирования)
  - Error handling (retry, timeout, validation)
- **Диаграммы**: Debugging flow, mindmap
- **Время изучения**: 2-3 часа

#### Модуль 5: Интеграция с LLM-хостом
- **Лекция**: Claude Desktop, конфигурация, безопасность
- **Примеры кода**:
  - Claude Desktop config
  - Custom LLM host с Anthropic
- **Диаграммы**: Integration diagram, mindmap
- **Время изучения**: 2-3 часа

#### Модуль 6: Интеграция с LLM моделями
- **Лекция**: Anthropic Claude API, OpenAI GPT API
- **Примеры кода**:
  - Anthropic integration
  - OpenAI integration
- **Диаграммы**: Sequence diagram, mindmap
- **Время изучения**: 3-4 часа

#### Модуль 7: Практические проекты
- **Лекция**: Production-ready серверы, best practices, развертывание
- **Проекты**: Файловый менеджер, сервис погоды, БД коннектор, AI Coding Assistant
- **Время изучения**: 2-3 часа (теория)

### Практические лабораторные работы

#### Лабораторная 1: Первый MCP-сервер
- **Задание**: Создать калькулятор с 6 математическими операциями
- **Навыки**: Основы MCP SDK, JSON Schema, обработка ошибок
- **Файлы**: task.md, solution/server.py, solution/test_client.py
- **Время выполнения**: 1-2 часа

#### Лабораторная 2: Сервис погоды
- **Задание**: Интеграция с OpenWeatherMap API
- **Навыки**: Внешние API, кэширование, асинхронность, переменные окружения
- **Файлы**: task.md, solution/server.py, .env.example, requirements.txt
- **Время выполнения**: 2-3 часа

#### Лабораторная 3: Файловый менеджер
- **Задание**: Безопасная работа с файловой системой
- **Навыки**: Безопасность (path traversal), валидация, ограничения доступа
- **Файлы**: task.md, solution/server.py
- **Время выполнения**: 3-4 часа

#### Лабораторная 4: Коннектор к БД
- **Задание**: SQL запросы через MCP с безопасностью
- **Навыки**: SQLAlchemy, query sanitization, ограничения на запросы
- **Файлы**: task.md, solution/server.py
- **Время выполнения**: 3-4 часа

#### Лабораторная 5: Полное AI-приложение
- **Задание**: AI Coding Assistant с множественными MCP-серверами
- **Навыки**: Orchestration, интеграция Claude API, tool calling
- **Файлы**: task.md, solution/main.py
- **Время выполнения**: 5-6 часов

## 🚀 Начало работы

### Установка зависимостей

```bash
pip install -r requirements.txt
```

### Структура курса

```
mcp_course/
├── modules/              # Теоретические модули
│   ├── module_01_introduction/
│   ├── module_02_protocol/
│   ├── module_03_python_sdk/
│   ├── module_04_debugging/
│   ├── module_05_llm_host/
│   ├── module_06_llm_integration/
│   └── module_07_practice/
│
└── labs/                 # Практические работы
    ├── lab_01_first_server/
    ├── lab_02_weather_service/
    ├── lab_03_file_manager/
    ├── lab_04_database_connector/
    └── lab_05_full_application/
```

### Рекомендуемый порядок изучения

1. **Неделя 1**: Модули 1-3 + Лабораторная 1
2. **Неделя 2**: Модули 4-5 + Лабораторная 2
3. **Неделя 3**: Модули 6-7 + Лабораторные 3-4
4. **Неделя 4**: Лабораторная 5 + собственный проект

## 📖 Использование курса

### Теория

Каждый модуль содержит:
- `lecture.md` - подробная лекция с примерами
- `mindmap.puml` - интеллект-карта концепций (PlantUML)
- Дополнительные диаграммы архитектуры

Для просмотра PlantUML диаграмм используйте:
- VS Code с расширением PlantUML
- Online редактор: http://www.plantuml.com/plantuml/

### Практика

Каждая лабораторная работа содержит:
- `task.md` - описание задания, требования, критерии оценки
- `solution/` - эталонное решение с комментариями

**Рекомендация**: Сначала попробуйте решить самостоятельно, затем сверьтесь с решением.

### Запуск примеров

```bash
# Базовый сервер
cd modules/module_03_python_sdk/examples
python 01_basic_server.py

# Тестирование через Inspector
npx @modelcontextprotocol/inspector python 01_basic_server.py

# Запуск клиента
python 02_basic_client.py
```

### Тестирование лабораторных

```bash
# Лабораторная 1
cd labs/lab_01_first_server/solution
python test_client.py

# Лабораторная 2
cd labs/lab_02_weather_service/solution
cp .env.example .env
# Отредактируйте .env, добавьте API ключ
python server.py
```

## 🛠️ Требования

### Минимальные

- Python 3.11+
- pip или uv
- Git (опционально)

### Для всех возможностей

- Node.js 18+ (для MCP Inspector)
- Docker (опционально, для изоляции)
- Anthropic API ключ (для модуля 6 и лаб. 5)
- OpenWeatherMap API ключ (для лаб. 2)

## 📦 Зависимости

Основные библиотеки:
- `mcp>=0.1.0` - MCP Python SDK
- `anthropic>=0.18.0` - Anthropic Claude API
- `openai>=1.0.0` - OpenAI GPT API
- `aiohttp>=3.9.0` - Асинхронные HTTP запросы
- `sqlalchemy>=2.0.0` - Работа с БД
- `python-dotenv>=1.0.0` - Переменные окружения

Полный список: `requirements.txt`

## 📊 Статистика курса

- **Модулей**: 7
- **Лабораторных работ**: 5
- **Примеров кода**: 16+
- **Строк кода**: 3500+
- **Диаграмм**: 12
- **Общее время**: 40-50 часов

## 🎓 По завершении курса вы сможете

✅ Понимать архитектуру Model Context Protocol  
✅ Создавать MCP-серверы на Python с любой функциональностью  
✅ Интегрироваться с Claude, GPT и другими LLM  
✅ Работать с инструментами, ресурсами и промптами  
✅ Обеспечивать безопасность и производительность  
✅ Отлаживать и мониторить MCP-серверы  
✅ Развертывать production-ready решения  

## 🌟 Дополнительные ресурсы

- [Официальная документация MCP](https://modelcontextprotocol.io)
- [MCP GitHub](https://github.com/modelcontextprotocol)
- [Anthropic Documentation](https://docs.anthropic.com)
- [OpenAI Documentation](https://platform.openai.com/docs)

## 📝 Лицензия и использование

Этот курс создан в образовательных целях. Вы можете свободно использовать материалы для обучения.

## 🤝 Обратная связь

Курс постоянно улучшается. Если вы нашли ошибки или у вас есть предложения по улучшению - создайте issue или pull request.

## 🚀 Следующие шаги

После завершения курса рекомендуем:

1. **Создать собственный MCP-сервер** для вашей задачи
2. **Опубликовать его** для сообщества
3. **Интегрировать** с вашим любимым LLM
4. **Изучить продвинутые паттерны** архитектуры MCP
5. **Участвовать в развитии** экосистемы MCP

---

**Удачи в изучении Model Context Protocol! 🎉**
