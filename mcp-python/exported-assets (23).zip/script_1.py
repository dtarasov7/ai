
# Lab 1: Первый MCP-сервер

lab1_task = """# Лабораторная работа 1: Первый MCP-сервер

## Цель работы

Создать базовый MCP-сервер с математическими инструментами для освоения основ протокола.

## Задание

Реализуйте MCP-сервер "calculator-server" со следующими инструментами:

### Инструменты

1. **add** - Сложение двух чисел
   - Параметры: `a` (number), `b` (number)
   - Возвращает: Результат сложения

2. **subtract** - Вычитание
   - Параметры: `a` (number), `b` (number)
   - Возвращает: Результат вычитания

3. **multiply** - Умножение
   - Параметры: `a` (number), `b` (number)
   - Возвращает: Результат умножения

4. **divide** - Деление
   - Параметры: `a` (number), `b` (number)
   - Возвращает: Результат деления
   - Обработайте деление на ноль!

5. **power** - Возведение в степень
   - Параметры: `base` (number), `exponent` (number)
   - Возвращает: Результат возведения в степень

6. **sqrt** - Квадратный корень
   - Параметры: `number` (number, >= 0)
   - Возвращает: Квадратный корень
   - Обработайте отрицательные числа!

## Требования

1. **Используйте MCP Python SDK** - `pip install mcp`
2. **Все инструменты должны быть зарегистрированы** через `@app.list_tools()`
3. **Обработка ошибок**:
   - Деление на ноль
   - Квадратный корень из отрицательного числа
   - Некорректные входные данные
4. **Логирование** - добавьте базовое логирование операций
5. **JSON Schema** - корректно опишите все параметры

## Критерии оценки

- ✅ Все 6 инструментов работают корректно (40%)
- ✅ Обработка ошибок реализована (20%)
- ✅ JSON Schema корректно описывает параметры (20%)
- ✅ Код хорошо структурирован и закомментирован (10%)
- ✅ Логирование присутствует (10%)

## Тестирование

После реализации протестируйте сервер:

```bash
# Запустите MCP Inspector
npx @modelcontextprotocol/inspector python solution/server.py

# Или используйте тестовый клиент
python solution/test_client.py
```

## Подсказки

1. Используйте модуль `math` для математических операций
2. Для обработки ошибок возвращайте TextContent с описанием ошибки
3. Используйте `logging` модуль Python для логирования
4. JSON Schema типы: "number", "integer", "string", "boolean"

## Время выполнения

**Ожидаемое время**: 1-2 часа

## Дополнительное задание (необязательно)

Добавьте инструмент **calculate_expression**, который принимает математическое выражение в виде строки и вычисляет результат:

```python
# Пример
calculate_expression("2 + 3 * 4")  # Возвращает 14
```

**Важно**: Используйте безопасный парсинг (не `eval()`!), например библиотеку `ast` или `numexpr`.
"""

lab1_solution = '''"""
Лабораторная работа 1: Калькулятор MCP-сервер
Решение
"""

import asyncio
import logging
import math
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Создаем сервер
app = Server("calculator-server")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Регистрация математических инструментов"""
    return [
        Tool(
            name="add",
            description="Складывает два числа",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "Первое число"
                    },
                    "b": {
                        "type": "number",
                        "description": "Второе число"
                    }
                },
                "required": ["a", "b"]
            }
        ),
        
        Tool(
            name="subtract",
            description="Вычитает второе число из первого",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "Уменьшаемое"
                    },
                    "b": {
                        "type": "number",
                        "description": "Вычитаемое"
                    }
                },
                "required": ["a", "b"]
            }
        ),
        
        Tool(
            name="multiply",
            description="Умножает два числа",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "Первый множитель"
                    },
                    "b": {
                        "type": "number",
                        "description": "Второй множитель"
                    }
                },
                "required": ["a", "b"]
            }
        ),
        
        Tool(
            name="divide",
            description="Делит первое число на второе",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "Делимое"
                    },
                    "b": {
                        "type": "number",
                        "description": "Делитель (не должен быть 0)"
                    }
                },
                "required": ["a", "b"]
            }
        ),
        
        Tool(
            name="power",
            description="Возводит число в степень",
            inputSchema={
                "type": "object",
                "properties": {
                    "base": {
                        "type": "number",
                        "description": "Основание"
                    },
                    "exponent": {
                        "type": "number",
                        "description": "Показатель степени"
                    }
                },
                "required": ["base", "exponent"]
            }
        ),
        
        Tool(
            name="sqrt",
            description="Вычисляет квадратный корень числа",
            inputSchema={
                "type": "object",
                "properties": {
                    "number": {
                        "type": "number",
                        "description": "Число для извлечения корня (должно быть >= 0)",
                        "minimum": 0
                    }
                },
                "required": ["number"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Выполнение математических операций"""
    
    logger.info(f"Вызван инструмент: {name} с аргументами: {arguments}")
    
    try:
        # Сложение
        if name == "add":
            a = arguments["a"]
            b = arguments["b"]
            result = a + b
            
            logger.info(f"Сложение: {a} + {b} = {result}")
            return [TextContent(
                type="text",
                text=f"{a} + {b} = {result}"
            )]
        
        # Вычитание
        elif name == "subtract":
            a = arguments["a"]
            b = arguments["b"]
            result = a - b
            
            logger.info(f"Вычитание: {a} - {b} = {result}")
            return [TextContent(
                type="text",
                text=f"{a} - {b} = {result}"
            )]
        
        # Умножение
        elif name == "multiply":
            a = arguments["a"]
            b = arguments["b"]
            result = a * b
            
            logger.info(f"Умножение: {a} × {b} = {result}")
            return [TextContent(
                type="text",
                text=f"{a} × {b} = {result}"
            )]
        
        # Деление
        elif name == "divide":
            a = arguments["a"]
            b = arguments["b"]
            
            # Проверка деления на ноль
            if b == 0:
                logger.warning("Попытка деления на ноль")
                return [TextContent(
                    type="text",
                    text="❌ Ошибка: Деление на ноль невозможно"
                )]
            
            result = a / b
            logger.info(f"Деление: {a} ÷ {b} = {result}")
            return [TextContent(
                type="text",
                text=f"{a} ÷ {b} = {result}"
            )]
        
        # Возведение в степень
        elif name == "power":
            base = arguments["base"]
            exponent = arguments["exponent"]
            
            try:
                result = math.pow(base, exponent)
                logger.info(f"Степень: {base}^{exponent} = {result}")
                return [TextContent(
                    type="text",
                    text=f"{base}^{exponent} = {result}"
                )]
            except OverflowError:
                logger.error("Результат слишком большой")
                return [TextContent(
                    type="text",
                    text="❌ Ошибка: Результат слишком большой"
                )]
        
        # Квадратный корень
        elif name == "sqrt":
            number = arguments["number"]
            
            # Проверка отрицательного числа
            if number < 0:
                logger.warning(f"Попытка извлечь корень из отрицательного числа: {number}")
                return [TextContent(
                    type="text",
                    text=f"❌ Ошибка: Невозможно извлечь квадратный корень из отрицательного числа {number}"
                )]
            
            result = math.sqrt(number)
            logger.info(f"Корень: √{number} = {result}")
            return [TextContent(
                type="text",
                text=f"√{number} = {result}"
            )]
        
        else:
            logger.error(f"Неизвестный инструмент: {name}")
            raise ValueError(f"Неизвестный инструмент: {name}")
    
    except KeyError as e:
        logger.error(f"Отсутствует обязательный параметр: {e}")
        return [TextContent(
            type="text",
            text=f"❌ Ошибка: Отсутствует обязательный параметр {e}"
        )]
    
    except TypeError as e:
        logger.error(f"Некорректный тип данных: {e}")
        return [TextContent(
            type="text",
            text=f"❌ Ошибка: Некорректный тип данных"
        )]
    
    except Exception as e:
        logger.error(f"Неожиданная ошибка: {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=f"❌ Неожиданная ошибка: {str(e)}"
        )]


async def main():
    """Запуск сервера"""
    logger.info("Запуск калькулятор-сервера...")
    
    async with stdio_server() as (read_stream, write_stream):
        logger.info("Сервер готов к приему запросов")
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

lab1_test = '''"""
Тестовый клиент для лабораторной работы 1
"""

import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def test_calculator():
    """Тестирование калькулятора"""
    
    server_params = StdioServerParameters(
        command="python",
        args=["server.py"]
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Инициализация
            await session.initialize()
            print("✅ Подключено к серверу\\n")
            
            # Получаем список инструментов
            tools = await session.list_tools()
            print(f"📦 Доступно инструментов: {len(tools.tools)}")
            for tool in tools.tools:
                print(f"   - {tool.name}: {tool.description}")
            print()
            
            # Тесты
            tests = [
                ("add", {"a": 10, "b": 5}, "Сложение"),
                ("subtract", {"a": 10, "b": 5}, "Вычитание"),
                ("multiply", {"a": 10, "b": 5}, "Умножение"),
                ("divide", {"a": 10, "b": 5}, "Деление"),
                ("divide", {"a": 10, "b": 0}, "Деление на ноль (ошибка)"),
                ("power", {"base": 2, "exponent": 10}, "Степень"),
                ("sqrt", {"number": 16}, "Корень"),
                ("sqrt", {"number": -1}, "Корень из отрицательного (ошибка)"),
            ]
            
            print("🧪 Запуск тестов:\\n")
            
            for tool_name, args, description in tests:
                print(f"Тест: {description}")
                print(f"  Вызов: {tool_name}({args})")
                
                try:
                    result = await session.call_tool(tool_name, args)
                    
                    for content in result.content:
                        if hasattr(content, 'text'):
                            print(f"  Результат: {content.text}")
                    
                    print()
                
                except Exception as e:
                    print(f"  ❌ Ошибка: {e}\\n")
            
            print("=" * 50)
            print("✅ Тестирование завершено")


if __name__ == "__main__":
    asyncio.run(test_calculator())
'''

# Сохраняю файлы Lab 1
with open("mcp_course/labs/lab_01_first_server/task.md", "w", encoding="utf-8") as f:
    f.write(lab1_task)

with open("mcp_course/labs/lab_01_first_server/solution/server.py", "w", encoding="utf-8") as f:
    f.write(lab1_solution)

with open("mcp_course/labs/lab_01_first_server/solution/test_client.py", "w", encoding="utf-8") as f:
    f.write(lab1_test)

print("✅ Лабораторная работа 1 создана:")
print("  - task.md")
print("  - solution/server.py")
print("  - solution/test_client.py")
