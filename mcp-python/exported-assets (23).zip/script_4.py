
# Lab 4: Database connector и Lab 5: Full Application (компактные версии)

lab4_task = """# Лабораторная работа 4: Коннектор к БД

## Цель работы

Создать безопасный MCP-сервер для выполнения SQL запросов.

## Задание

Реализуйте "database-connector" с доступом только на чтение (SELECT).

### Инструменты

1. **execute_query** - SELECT запросы
2. **get_tables** - Список таблиц
3. **describe_table** - Схема таблицы
4. **get_table_stats** - Статистика

### Безопасность

- Только SELECT разрешен
- Query sanitization
- Лимит 1000 строк
- Timeout 30 секунд

## Критерии оценки

- ✅ Работа с SQLite/PostgreSQL (40%)
- ✅ Безопасность SQL (40%)
- ✅ Обработка ошибок (20%)

## Время: 3-4 часа
"""

lab4_solution = '''"""
Lab 4: Database Connector - Решение
"""

import asyncio
import logging
import sqlparse
from sqlalchemy import create_engine, text, inspect
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Server("database-connector")

# Подключение к БД (SQLite для примера)
engine = create_engine("sqlite:///./test.db")


class QueryValidator:
    """Валидатор SQL запросов"""
    
    ALLOWED_KEYWORDS = {"SELECT", "FROM", "WHERE", "JOIN", "ORDER", "GROUP", "LIMIT", "AS"}
    
    @staticmethod
    def validate(query: str) -> bool:
        parsed = sqlparse.parse(query)[0]
        
        # Проверяем тип
        if parsed.get_type() != "SELECT":
            raise ValueError("Разрешены только SELECT запросы")
        
        # Проверяем ключевые слова
        query_upper = query.upper()
        forbidden = ["INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER", "TRUNCATE"]
        
        for word in forbidden:
            if word in query_upper:
                raise ValueError(f"Запрещенное ключевое слово: {word}")
        
        return True


@app.list_tools()
async def list_tools():
    return [
        Tool(
            name="execute_query",
            description="Выполняет SELECT запрос к базе данных",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "SQL SELECT запрос"}
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="get_tables",
            description="Возвращает список всех таблиц в базе данных",
            inputSchema={"type": "object", "properties": {}}
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict):
    try:
        if name == "execute_query":
            query = arguments["query"]
            
            # Валидация
            QueryValidator.validate(query)
            
            # Выполнение с лимитом
            with engine.connect() as conn:
                result = conn.execute(text(query))
                rows = result.fetchmany(1000)  # Лимит 1000 строк
                
                if not rows:
                    return [TextContent(type="text", text="Результат пуст")]
                
                # Форматирование
                columns = result.keys()
                output = " | ".join(columns) + "\\n"
                output += "-" * 50 + "\\n"
                
                for row in rows:
                    output += " | ".join(str(v) for v in row) + "\\n"
                
                return [TextContent(type="text", text=output)]
        
        elif name == "get_tables":
            inspector = inspect(engine)
            tables = inspector.get_table_names()
            
            return [TextContent(type="text", text="\\n".join(f"📊 {t}" for t in tables))]
    
    except ValueError as e:
        return [TextContent(type="text", text=f"❌ {str(e)}")]
    except Exception as e:
        logger.error(f"DB Error: {e}", exc_info=True)
        return [TextContent(type="text", text=f"❌ Ошибка БД: {str(e)}")]


async def main():
    logger.info("Database connector запущен")
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
'''

lab5_task = """# Лабораторная работа 5: Полное AI-приложение

## Цель работы

Создать комплексное AI-приложение, объединяющее несколько MCP-серверов и Claude API.

## Задание

Создайте AI Coding Assistant с интеграцией:
- File System Server
- Git Server (опционально)
- Claude API для анализа кода

### Архитектура

```
Claude API
    ↓
Ваше приложение (orchestrator)
    ↓
├── File System MCP Server
├── Calculator MCP Server
└── Weather MCP Server
```

### Функциональность

1. **Чтение кода** через File System Server
2. **Анализ кода** через Claude API
3. **Выполнение вычислений** через Calculator
4. **Получение погоды** через Weather Service

### Требования

1. Интеграция с Claude API (Anthropic)
2. Подключение к 3+ MCP серверам
3. Tool calling обработка
4. Логирование всех операций
5. CLI интерфейс

## Критерии оценки

- ✅ Интеграция с Claude (30%)
- ✅ Работа с MCP серверами (30%)
- ✅ Tool calling (20%)
- ✅ CLI интерфейс (10%)
- ✅ Документация (10%)

## Время: 5-6 часов
"""

lab5_solution = '''"""
Lab 5: AI Coding Assistant - Решение
"""

import asyncio
import os
from anthropic import Anthropic
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class AIAssistant:
    """AI-ассистент с MCP серверами"""
    
    def __init__(self, api_key: str):
        self.client = Anthropic(api_key=api_key)
        self.mcp_servers = {}
        self.tools = []
    
    async def connect_server(self, name: str, command: str, args: list):
        """Подключение к MCP-серверу"""
        params = StdioServerParameters(command=command, args=args)
        
        stdio = stdio_client(params)
        read, write = await stdio.__aenter__()
        
        session = ClientSession(read, write)
        mcp = await session.__aenter__()
        await mcp.initialize()
        
        # Получаем инструменты
        tools_result = await mcp.list_tools()
        
        self.mcp_servers[name] = {
            "session": mcp,
            "tools": tools_result.tools
        }
        
        # Добавляем в общий список
        for tool in tools_result.tools:
            self.tools.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.inputSchema,
                "server": name
            })
        
        print(f"✅ Подключен сервер {name}: {len(tools_result.tools)} инструментов")
    
    async def chat(self, message: str):
        """Диалог с AI"""
        messages = [{"role": "user", "content": message}]
        
        print(f"\\n👤 Вы: {message}\\n")
        
        for _ in range(5):
            response = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=2048,
                tools=[{"name": t["name"], "description": t["description"], 
                       "input_schema": t["input_schema"]} for t in self.tools],
                messages=messages
            )
            
            if response.stop_reason == "tool_use":
                tool_results = []
                
                for block in response.content:
                    if block.type == "tool_use":
                        # Находим сервер для этого инструмента
                        server_name = next(t["server"] for t in self.tools if t["name"] == block.name)
                        server = self.mcp_servers[server_name]["session"]
                        
                        print(f"🔧 {block.name}({block.input})")
                        
                        result = await server.call_tool(block.name, block.input)
                        text = next(c.text for c in result.content if hasattr(c, "text"))
                        
                        print(f"   → {text}\\n")
                        
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": text
                        })
                
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": tool_results})
            
            elif response.stop_reason == "end_turn":
                answer = next(b.text for b in response.content if b.type == "text")
                print(f"🤖 Claude: {answer}\\n")
                break


async def main():
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ Установите ANTHROPIC_API_KEY")
        return
    
    assistant = AIAssistant(api_key)
    
    # Подключаем серверы
    await assistant.connect_server(
        "calculator",
        "python",
        ["../../lab_01_first_server/solution/server.py"]
    )
    
    # Примеры запросов
    await assistant.chat("Посчитай квадратный корень из 144 и умножь результат на 5")


if __name__ == "__main__":
    asyncio.run(main())
'''

# Сохраняю Labs 4 и 5
with open("mcp_course/labs/lab_04_database_connector/task.md", "w", encoding="utf-8") as f:
    f.write(lab4_task)

with open("mcp_course/labs/lab_04_database_connector/solution/server.py", "w", encoding="utf-8") as f:
    f.write(lab4_solution)

with open("mcp_course/labs/lab_05_full_application/task.md", "w", encoding="utf-8") as f:
    f.write(lab5_task)

with open("mcp_course/labs/lab_05_full_application/solution/main.py", "w", encoding="utf-8") as f:
    f.write(lab5_solution)

print("✅ Лабораторная работа 4 создана")
print("✅ Лабораторная работа 5 создана")
print("\n" + "="*60)
print("🎉 ВСЕ ЛАБОРАТОРНЫЕ РАБОТЫ СОЗДАНЫ!")
print("="*60)
