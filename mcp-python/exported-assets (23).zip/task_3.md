# Лабораторная работа 5: Полное AI-приложение

## Цель работы

Создать комплексное AI-приложение, объединяющее несколько MCP-серверов и Claude API.

## Задание

Создайте AI Coding Assistant с интеграцией:
- File System Server
- Git Server (опционально)
- Claude API для анализа кода

### Архитектура

```
Claude API
    ↓
Ваше приложение (orchestrator)
    ↓
├── File System MCP Server
├── Calculator MCP Server
└── Weather MCP Server
```

### Функциональность

1. **Чтение кода** через File System Server
2. **Анализ кода** через Claude API
3. **Выполнение вычислений** через Calculator
4. **Получение погоды** через Weather Service

### Требования

1. Интеграция с Claude API (Anthropic)
2. Подключение к 3+ MCP серверам
3. Tool calling обработка
4. Логирование всех операций
5. CLI интерфейс

## Критерии оценки

- ✅ Интеграция с Claude (30%)
- ✅ Работа с MCP серверами (30%)
- ✅ Tool calling (20%)
- ✅ CLI интерфейс (10%)
- ✅ Документация (10%)

## Время: 5-6 часов
