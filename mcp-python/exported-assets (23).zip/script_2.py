
# Lab 2: Сервис погоды

lab2_task = """# Лабораторная работа 2: Сервис погоды

## Цель работы

Создать MCP-сервер, интегрирующийся с внешним API для получения данных о погоде. Освоить работу с API, кэшированием и переменными окружения.

## Задание

Реализуйте MCP-сервер "weather-service" с интеграцией OpenWeatherMap API.

### Регистрация в OpenWeatherMap

1. Зарегистрируйтесь на https://openweathermap.org/
2. Получите бесплатный API ключ
3. Создайте файл `.env` с ключом:
   ```
   OPENWEATHER_API_KEY=your_api_key_here
   ```

### Инструменты

1. **get_current_weather** - Текущая погода в городе
   - Параметры: `city` (string), `units` (enum: "metric", "imperial", default: "metric")
   - Возвращает: Температура, описание, влажность, скорость ветра

2. **get_forecast** - Прогноз на 5 дней
   - Параметры: `city` (string), `days` (integer, 1-5)
   - Возвращает: Прогноз погоды по дням

3. **get_weather_by_coordinates** - Погода по координатам
   - Параметры: `lat` (number), `lon` (number)
   - Возвращает: Текущую погоду для координат

### Ресурсы

1. **weather://city/current** - Текущая погода (URI формат)
2. **weather://city/forecast** - Прогноз

### Требования

1. **Кэширование** - кэшируйте запросы на 30 минут (TTL)
2. **Обработка ошибок**:
   - Город не найден
   - Проблемы с API (rate limit, timeout)
   - Невалидный API ключ
3. **Асинхронные запросы** - используйте `aiohttp`
4. **Переменные окружения** - API ключ из `.env` файла
5. **Логирование** - логируйте все запросы к API

## Критерии оценки

- ✅ Все инструменты работают корректно (30%)
- ✅ Кэширование реализовано (20%)
- ✅ Обработка ошибок API (20%)
- ✅ Асинхронные запросы (15%)
- ✅ Ресурсы работают (10%)
- ✅ Код структурирован, есть документация (5%)

## API OpenWeatherMap

**Current Weather**:
```
GET https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric
```

**Forecast**:
```
GET https://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric
```

## Подсказки

1. Используйте `python-dotenv` для `.env` файлов
2. `aiohttp.ClientSession` для асинхронных HTTP запросов
3. Простой кэш: словарь с timestamps
4. Rate limit OpenWeatherMap: 60 запросов/минуту (бесплатный план)

## Время выполнения

**Ожидаемое время**: 2-3 часа

## Дополнительное задание

1. Добавьте инструмент **get_air_quality** - качество воздуха
2. Реализуйте **persistent кэш** (сохранение в файл)
3. Добавьте **метрики** - количество запросов к API, cache hit rate
"""

lab2_solution = '''"""
Лабораторная работа 2: Сервис погоды
Решение
"""

import asyncio
import logging
import os
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import aiohttp
from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, Resource, TextContent

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Создаем сервер
app = Server("weather-service")

# API конфигурация
API_KEY = os.getenv("OPENWEATHER_API_KEY")
BASE_URL = "https://api.openweathermap.org/data/2.5"


class WeatherCache:
    """Простой кэш с TTL для погодных данных"""
    
    def __init__(self, ttl_seconds: int = 1800):  # 30 минут
        self.cache: Dict[str, tuple[Any, datetime]] = {}
        self.ttl = ttl_seconds
        self.hits = 0
        self.misses = 0
    
    def get(self, key: str) -> Optional[Any]:
        """Получить данные из кэша"""
        if key in self.cache:
            data, timestamp = self.cache[key]
            if datetime.now() - timestamp < timedelta(seconds=self.ttl):
                self.hits += 1
                logger.info(f"Cache HIT: {key}")
                return data
            else:
                # Данные устарели
                del self.cache[key]
        
        self.misses += 1
        logger.info(f"Cache MISS: {key}")
        return None
    
    def set(self, key: str, data: Any):
        """Сохранить данные в кэш"""
        self.cache[key] = (data, datetime.now())
        logger.debug(f"Cached: {key}")
    
    def get_stats(self) -> dict:
        """Статистика кэша"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": f"{hit_rate:.1f}%",
            "cached_items": len(self.cache)
        }


# Глобальный кэш
cache = WeatherCache(ttl_seconds=1800)


async def fetch_weather(city: str, units: str = "metric") -> dict:
    """Получить текущую погоду через API"""
    
    # Проверяем кэш
    cache_key = f"weather:{city}:{units}"
    cached_data = cache.get(cache_key)
    if cached_data:
        return cached_data
    
    # Запрос к API
    url = f"{BASE_URL}/weather"
    params = {
        "q": city,
        "appid": API_KEY,
        "units": units
    }
    
    logger.info(f"API запрос: погода для {city}")
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, params=params, timeout=10) as response:
                if response.status == 404:
                    raise ValueError(f"Город '{city}' не найден")
                elif response.status == 401:
                    raise ValueError("Невалидный API ключ")
                elif response.status == 429:
                    raise ValueError("Превышен лимит запросов к API")
                
                response.raise_for_status()
                data = await response.json()
                
                # Сохраняем в кэш
                cache.set(cache_key, data)
                
                return data
                
        except asyncio.TimeoutError:
            raise ValueError("Timeout при запросе к API")
        except aiohttp.ClientError as e:
            raise ValueError(f"Ошибка сети: {str(e)}")


async def fetch_forecast(city: str, days: int = 5) -> dict:
    """Получить прогноз погоды"""
    
    cache_key = f"forecast:{city}:{days}"
    cached_data = cache.get(cache_key)
    if cached_data:
        return cached_data
    
    url = f"{BASE_URL}/forecast"
    params = {
        "q": city,
        "appid": API_KEY,
        "units": "metric"
    }
    
    logger.info(f"API запрос: прогноз для {city}")
    
    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params, timeout=10) as response:
            response.raise_for_status()
            data = await response.json()
            
            cache.set(cache_key, data)
            return data


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Регистрация инструментов"""
    return [
        Tool(
            name="get_current_weather",
            description="Получает текущую погоду для указанного города",
            inputSchema={
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "Название города (например: Moscow, London, New York)"
                    },
                    "units": {
                        "type": "string",
                        "enum": ["metric", "imperial"],
                        "description": "Единицы измерения (metric=Цельсий, imperial=Фаренгейт)",
                        "default": "metric"
                    }
                },
                "required": ["city"]
            }
        ),
        
        Tool(
            name="get_forecast",
            description="Получает прогноз погоды на несколько дней",
            inputSchema={
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "Название города"
                    },
                    "days": {
                        "type": "integer",
                        "description": "Количество дней (1-5)",
                        "minimum": 1,
                        "maximum": 5,
                        "default": 3
                    }
                },
                "required": ["city"]
            }
        ),
        
        Tool(
            name="get_cache_stats",
            description="Получает статистику кэширования запросов",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Обработка вызовов инструментов"""
    
    try:
        # Текущая погода
        if name == "get_current_weather":
            city = arguments["city"]
            units = arguments.get("units", "metric")
            
            data = await fetch_weather(city, units)
            
            # Форматируем ответ
            temp = data["main"]["temp"]
            feels_like = data["main"]["feels_like"]
            humidity = data["main"]["humidity"]
            description = data["weather"][0]["description"]
            wind_speed = data["wind"]["speed"]
            
            unit_symbol = "°C" if units == "metric" else "°F"
            
            result = f"""🌤 Погода в {city}:

🌡 Температура: {temp}{unit_symbol}
🤚 Ощущается как: {feels_like}{unit_symbol}
📝 Описание: {description}
💧 Влажность: {humidity}%
💨 Ветер: {wind_speed} м/с
"""
            
            return [TextContent(type="text", text=result)]
        
        # Прогноз
        elif name == "get_forecast":
            city = arguments["city"]
            days = arguments.get("days", 3)
            
            data = await fetch_forecast(city, days)
            
            # Форматируем прогноз
            result = f"📅 Прогноз погоды для {city}:\\n\\n"
            
            # Группируем по дням
            forecasts = data["list"][:days * 8]  # 8 записей в день
            
            for i in range(0, len(forecasts), 8):
                if i < len(forecasts):
                    forecast = forecasts[i]
                    date = forecast["dt_txt"].split()[0]
                    temp = forecast["main"]["temp"]
                    description = forecast["weather"][0]["description"]
                    
                    result += f"📆 {date}: {temp}°C, {description}\\n"
            
            return [TextContent(type="text", text=result)]
        
        # Статистика кэша
        elif name == "get_cache_stats":
            stats = cache.get_stats()
            
            result = f"""📊 Статистика кэша:

✅ Cache hits: {stats['hits']}
❌ Cache misses: {stats['misses']}
📈 Hit rate: {stats['hit_rate']}
💾 Кэшировано элементов: {stats['cached_items']}
"""
            
            return [TextContent(type="text", text=result)]
        
        else:
            raise ValueError(f"Неизвестный инструмент: {name}")
    
    except ValueError as e:
        logger.error(f"Ошибка валидации: {e}")
        return [TextContent(type="text", text=f"❌ Ошибка: {str(e)}")]
    
    except Exception as e:
        logger.error(f"Неожиданная ошибка: {e}", exc_info=True)
        return [TextContent(type="text", text=f"❌ Ошибка сервера: {str(e)}")]


@app.list_resources()
async def list_resources() -> list[Resource]:
    """Регистрация ресурсов"""
    return [
        Resource(
            uri="weather://cache/stats",
            name="Cache Statistics",
            description="Статистика кэширования погодных запросов",
            mimeType="application/json"
        )
    ]


@app.read_resource()
async def read_resource(uri: str) -> str:
    """Чтение ресурсов"""
    import json
    
    if uri == "weather://cache/stats":
        stats = cache.get_stats()
        return json.dumps(stats, indent=2, ensure_ascii=False)
    else:
        raise ValueError(f"Ресурс не найден: {uri}")


async def main():
    """Запуск сервера"""
    
    # Проверка API ключа
    if not API_KEY:
        logger.error("OPENWEATHER_API_KEY не установлен в .env файле")
        return
    
    logger.info("Запуск сервиса погоды...")
    logger.info(f"API Key: {API_KEY[:8]}...")
    
    async with stdio_server() as (read_stream, write_stream):
        logger.info("Сервер готов к приему запросов")
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

lab2_env = """# Конфигурация для сервиса погоды

# OpenWeatherMap API ключ
# Получите бесплатный ключ на https://openweathermap.org/api
OPENWEATHER_API_KEY=your_api_key_here

# Настройки кэша (необязательно)
CACHE_TTL_SECONDS=1800
"""

lab2_requirements = """# Зависимости для Lab 2: Сервис погоды

mcp>=0.1.0
aiohttp>=3.9.0
python-dotenv>=1.0.0
"""

# Сохраняю файлы Lab 2
with open("mcp_course/labs/lab_02_weather_service/task.md", "w", encoding="utf-8") as f:
    f.write(lab2_task)

with open("mcp_course/labs/lab_02_weather_service/solution/server.py", "w", encoding="utf-8") as f:
    f.write(lab2_solution)

with open("mcp_course/labs/lab_02_weather_service/solution/.env.example", "w", encoding="utf-8") as f:
    f.write(lab2_env)

with open("mcp_course/labs/lab_02_weather_service/solution/requirements.txt", "w", encoding="utf-8") as f:
    f.write(lab2_requirements)

print("✅ Лабораторная работа 2 создана:")
print("  - task.md")
print("  - solution/server.py")
print("  - solution/.env.example")
print("  - solution/requirements.txt")
