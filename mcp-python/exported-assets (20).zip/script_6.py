
# Создам диаграммы для модуля 4

# Mindmap
module4_mindmap = """@startmindmap
* Отладка и мониторинг MCP

** Логирование
*** Уровни
**** DEBUG - детальная информация
**** INFO - общая информация
**** WARNING - предупреждения
**** ERROR - ошибки
**** CRITICAL - критические ошибки
*** Настройка
**** logging.basicConfig()
**** handlers (StreamHandler, FileHandler)
**** format строки
*** Структурированное
**** structlog
**** JSON формат
**** Контекстная информация

** MCP Inspector
*** Запуск
**** npx @modelcontextprotocol/inspector
**** stdio сервер
**** HTTP сервер
*** Возможности
**** Визуализация соединения
**** Тестирование tools
**** Работа с resources
**** Отладка prompts
**** История запросов

left side

** Диагностика проблем
*** Сервер не запускается
**** Синтаксические ошибки
**** Отсутствие зависимостей
**** Проблемы asyncio
*** Клиент не подключается
**** Неправильный путь
**** Timeout
**** Права доступа
*** Инструменты не работают
**** Декораторы не применены
**** Неправильная сигнатура
**** Ошибки валидации
*** Производительность
**** Блокирующие операции
**** Отсутствие кэширования
**** Утечки памяти

** Мониторинг продакшн
*** Метрики
**** Доступность (uptime)
**** Производительность (latency)
**** Ошибки (error rate)
**** Ресурсы (CPU, память)
*** Системы мониторинга
**** Prometheus
**** Grafana
**** ELK Stack

** Best Practices
*** Контекстное логирование
**** request_id
**** contextvars
*** Версионирование
**** SERVER_VERSION
*** Graceful shutdown
**** signal handlers
**** cleanup
*** Валидация входа
**** Pydantic
**** JSON Schema
*** Таймауты
**** asyncio.timeout()
**** retry механизм

** Инструменты
*** MCP Inspector
**** Интерактивное тестирование
*** Python Debugger (pdb)
**** Точки останова
*** Профилирование
**** cProfile
**** memory_profiler

@endmindmap
"""

# Debugging flow диаграмма
module4_debug_flow = """@startuml

title Процесс отладки MCP-сервера

start

:Запуск сервера;

if (Сервер запустился?) then (нет)
    :Проверить stderr логи;
    :Проверить синтаксис кода;
    :Проверить зависимости;
    stop
else (да)
    :Сервер работает;
endif

:Подключение клиента;

if (Клиент подключился?) then (нет)
    :Проверить путь к серверу;
    :Проверить stdio transport;
    :Добавить debug логирование;
    stop
else (да)
    :Соединение установлено;
endif

:Запрос списка инструментов;

if (Инструменты возвращены?) then (нет)
    :Проверить декораторы @app.list_tools();
    :Проверить сигнатуру функции;
    :Добавить логирование в handler;
    stop
else (да)
    :Инструменты доступны;
endif

:Вызов инструмента;

if (Инструмент выполнен?) then (нет)
    partition "Диагностика ошибки" {
        if (Ошибка валидации?) then (да)
            :Проверить JSON Schema;
            :Проверить типы параметров;
            :Добавить валидацию в коде;
        else (нет)
            if (Ошибка выполнения?) then (да)
                :Добавить try/except;
                :Логировать стек-трейс;
                :Использовать pdb для отладки;
            else (нет)
                if (Таймаут?) then (да)
                    :Увеличить таймаут;
                    :Оптимизировать код;
                    :Добавить кэширование;
                else (нет)
                    :Использовать MCP Inspector;
                    :Проверить JSON-RPC сообщения;
                endif
            endif
        endif
    }
    stop
else (да)
    :Успех!;
endif

:Проверка производительности;

if (Производительность OK?) then (нет)
    :Профилирование кода;
    :Оптимизация алгоритмов;
    :Добавление кэширования;
else (да)
    :Готово к продакшн;
endif

stop

@enduml
"""

# Сохраняю диаграммы
with open("mcp_course/modules/module_04_debugging/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module4_mindmap)

with open("mcp_course/modules/module_04_debugging/debugging_flow.puml", "w", encoding="utf-8") as f:
    f.write(module4_debug_flow)

print("✅ Модуль 4 завершен - созданы диаграммы:")
print("  - mindmap.puml")
print("  - debugging_flow.puml")
print("\n📦 Модуль 4 полностью готов!")
