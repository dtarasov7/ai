
# Создам полнофункциональный сервер и диаграммы для модуля 3

# 06_full_featured_server.py
full_server = '''"""
Полнофункциональный MCP-сервер

Демонстрирует все возможности MCP SDK:
- Множественные инструменты (Tools)
- Ресурсы (Resources)
- Промпты (Prompts)
- Логирование
- Обработка ошибок
"""

import asyncio
import logging
import json
from datetime import datetime
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool, Resource, Prompt, PromptArgument,
    TextContent, PromptMessage
)

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Создаем полнофункциональный сервер
app = Server("full-featured-server")

# Хранилище данных (в реальном приложении это была бы БД)
DATA_STORE = {
    "notes": [],
    "tasks": []
}


# ==================== TOOLS ====================

@app.list_tools()
async def list_tools() -> list[Tool]:
    """Регистрация всех доступных инструментов"""
    logger.info("Запрошен список инструментов")
    
    return [
        # Управление заметками
        Tool(
            name="add_note",
            description="Добавляет новую заметку в хранилище",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Заголовок заметки"},
                    "content": {"type": "string", "description": "Содержание заметки"},
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Теги для категоризации"
                    }
                },
                "required": ["title", "content"]
            }
        ),
        
        Tool(
            name="search_notes",
            description="Ищет заметки по ключевым словам",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Поисковый запрос"},
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Фильтр по тегам"
                    }
                },
                "required": ["query"]
            }
        ),
        
        # Управление задачами
        Tool(
            name="create_task",
            description="Создает новую задачу",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Название задачи"},
                    "priority": {
                        "type": "string",
                        "enum": ["low", "medium", "high"],
                        "description": "Приоритет задачи"
                    },
                    "due_date": {"type": "string", "description": "Срок выполнения (YYYY-MM-DD)"}
                },
                "required": ["title"]
            }
        ),
        
        Tool(
            name="list_tasks",
            description="Показывает список задач с фильтрацией",
            inputSchema={
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "enum": ["pending", "completed", "all"],
                        "description": "Статус задач для отображения"
                    },
                    "priority": {
                        "type": "string",
                        "enum": ["low", "medium", "high"],
                        "description": "Фильтр по приоритету"
                    }
                }
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Обработка вызовов инструментов"""
    logger.info(f"Вызван инструмент: {name} с аргументами: {arguments}")
    
    try:
        # Добавление заметки
        if name == "add_note":
            note = {
                "id": len(DATA_STORE["notes"]) + 1,
                "title": arguments["title"],
                "content": arguments["content"],
                "tags": arguments.get("tags", []),
                "created_at": datetime.now().isoformat()
            }
            DATA_STORE["notes"].append(note)
            
            logger.info(f"Создана заметка с ID: {note['id']}")
            return [TextContent(
                type="text",
                text=f"✅ Заметка создана успешно\\nID: {note['id']}\\nЗаголовок: {note['title']}"
            )]
        
        # Поиск заметок
        elif name == "search_notes":
            query = arguments["query"].lower()
            tags_filter = arguments.get("tags", [])
            
            results = []
            for note in DATA_STORE["notes"]:
                # Проверка совпадения в заголовке или содержании
                matches_query = (query in note["title"].lower() or 
                               query in note["content"].lower())
                
                # Проверка тегов если указаны
                matches_tags = (not tags_filter or 
                              any(tag in note["tags"] for tag in tags_filter))
                
                if matches_query and matches_tags:
                    results.append(note)
            
            if results:
                result_text = f"Найдено заметок: {len(results)}\\n\\n"
                for note in results:
                    result_text += f"📝 [{note['id']}] {note['title']}\\n"
                    result_text += f"   {note['content'][:100]}...\\n"
                    result_text += f"   Теги: {', '.join(note['tags'])}\\n\\n"
                return [TextContent(type="text", text=result_text)]
            else:
                return [TextContent(
                    type="text",
                    text=f"❌ Заметок по запросу '{query}' не найдено"
                )]
        
        # Создание задачи
        elif name == "create_task":
            task = {
                "id": len(DATA_STORE["tasks"]) + 1,
                "title": arguments["title"],
                "priority": arguments.get("priority", "medium"),
                "due_date": arguments.get("due_date"),
                "status": "pending",
                "created_at": datetime.now().isoformat()
            }
            DATA_STORE["tasks"].append(task)
            
            logger.info(f"Создана задача с ID: {task['id']}")
            return [TextContent(
                type="text",
                text=f"✅ Задача создана\\nID: {task['id']}\\nНазвание: {task['title']}\\nПриоритет: {task['priority']}"
            )]
        
        # Список задач
        elif name == "list_tasks":
            status_filter = arguments.get("status", "all")
            priority_filter = arguments.get("priority")
            
            tasks = DATA_STORE["tasks"]
            
            # Фильтрация по статусу
            if status_filter != "all":
                tasks = [t for t in tasks if t["status"] == status_filter]
            
            # Фильтрация по приоритету
            if priority_filter:
                tasks = [t for t in tasks if t["priority"] == priority_filter]
            
            if tasks:
                result_text = f"📋 Задачи ({len(tasks)}):\\n\\n"
                for task in tasks:
                    priority_icon = {"low": "🔵", "medium": "🟡", "high": "🔴"}
                    icon = priority_icon.get(task["priority"], "⚪")
                    
                    result_text += f"{icon} [{task['id']}] {task['title']}\\n"
                    result_text += f"   Статус: {task['status']} | Приоритет: {task['priority']}\\n"
                    if task["due_date"]:
                        result_text += f"   Срок: {task['due_date']}\\n"
                    result_text += "\\n"
                
                return [TextContent(type="text", text=result_text)]
            else:
                return [TextContent(type="text", text="Задач не найдено")]
        
        else:
            raise ValueError(f"Неизвестный инструмент: {name}")
            
    except Exception as e:
        logger.error(f"Ошибка при выполнении инструмента {name}: {e}")
        return [TextContent(
            type="text",
            text=f"❌ Ошибка: {str(e)}"
        )]


# ==================== RESOURCES ====================

@app.list_resources()
async def list_resources() -> list[Resource]:
    """Регистрация доступных ресурсов"""
    logger.info("Запрошен список ресурсов")
    
    return [
        Resource(
            uri="data://notes/all",
            name="All Notes",
            description="Все сохраненные заметки в формате JSON",
            mimeType="application/json"
        ),
        
        Resource(
            uri="data://tasks/all",
            name="All Tasks",
            description="Все задачи в формате JSON",
            mimeType="application/json"
        ),
        
        Resource(
            uri="stats://summary",
            name="Statistics Summary",
            description="Сводная статистика по заметкам и задачам",
            mimeType="text/plain"
        )
    ]


@app.read_resource()
async def read_resource(uri: str) -> str:
    """Чтение ресурсов"""
    logger.info(f"Запрошен ресурс: {uri}")
    
    if uri == "data://notes/all":
        return json.dumps(DATA_STORE["notes"], indent=2, ensure_ascii=False)
    
    elif uri == "data://tasks/all":
        return json.dumps(DATA_STORE["tasks"], indent=2, ensure_ascii=False)
    
    elif uri == "stats://summary":
        total_notes = len(DATA_STORE["notes"])
        total_tasks = len(DATA_STORE["tasks"])
        pending_tasks = len([t for t in DATA_STORE["tasks"] if t["status"] == "pending"])
        
        stats = f"""Статистика системы
==================

Заметки:
  Всего: {total_notes}

Задачи:
  Всего: {total_tasks}
  В работе: {pending_tasks}
  Завершено: {total_tasks - pending_tasks}
"""
        return stats
    
    else:
        raise ValueError(f"Ресурс не найден: {uri}")


# ==================== PROMPTS ====================

@app.list_prompts()
async def list_prompts() -> list[Prompt]:
    """Регистрация промптов"""
    logger.info("Запрошен список промптов")
    
    return [
        Prompt(
            name="organize_notes",
            description="Помогает организовать и структурировать заметки",
            arguments=[
                PromptArgument(
                    name="goal",
                    description="Цель организации (categorize, summarize, prioritize)",
                    required=True
                )
            ]
        ),
        
        Prompt(
            name="task_planning",
            description="Помогает спланировать выполнение задач",
            arguments=[
                PromptArgument(
                    name="timeframe",
                    description="Временные рамки (today, week, month)",
                    required=True
                )
            ]
        )
    ]


@app.get_prompt()
async def get_prompt(name: str, arguments: dict) -> list[PromptMessage]:
    """Генерация промптов"""
    logger.info(f"Запрошен промпт: {name}")
    
    if name == "organize_notes":
        goal = arguments["goal"]
        notes_json = json.dumps(DATA_STORE["notes"], indent=2, ensure_ascii=False)
        
        prompt_text = f"""У меня есть следующие заметки:

{notes_json}

Помоги мне их организовать. Цель: {goal}

Пожалуйста:
1. Проанализируй содержание заметок
2. Предложи систему организации
3. Создай категории или теги
4. Дай рекомендации по улучшению структуры"""

        return [PromptMessage(
            role="user",
            content=TextContent(type="text", text=prompt_text)
        )]
    
    elif name == "task_planning":
        timeframe = arguments["timeframe"]
        tasks_json = json.dumps(DATA_STORE["tasks"], indent=2, ensure_ascii=False)
        
        prompt_text = f"""У меня есть следующие задачи:

{tasks_json}

Помоги спланировать их выполнение в рамках: {timeframe}

Пожалуйста:
1. Приоритизируй задачи
2. Предложи оптимальный порядок выполнения
3. Оцени реалистичность сроков
4. Дай рекомендации по планированию"""

        return [PromptMessage(
            role="user",
            content=TextContent(type="text", text=prompt_text)
        )]
    
    else:
        raise ValueError(f"Промпт не найден: {name}")


# ==================== MAIN ====================

async def main():
    """Запуск полнофункционального сервера"""
    logger.info("Запуск full-featured MCP сервера...")
    
    async with stdio_server() as (read_stream, write_stream):
        logger.info("Сервер готов к приему запросов")
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

with open("mcp_course/modules/module_03_python_sdk/examples/06_full_featured_server.py", "w", encoding="utf-8") as f:
    f.write(full_server)

print("✅ Создан 06_full_featured_server.py")
