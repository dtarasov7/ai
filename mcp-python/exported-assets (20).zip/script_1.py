
# Создам оставшиеся примеры для модуля 3

# 04_server_with_resources.py
server_with_resources = '''"""
MCP-сервер с ресурсами

Демонстрирует предоставление различных типов ресурсов:
- Конфигурационные данные
- Файлы из файловой системы
- Динамические данные
"""

import asyncio
import json
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, TextContent

# Создаем сервер
app = Server("resource-server")

# Симулируем конфигурацию приложения
APP_CONFIG = {
    "app_name": "MCP Resource Server",
    "version": "1.0.0",
    "debug": True,
    "database": {
        "host": "localhost",
        "port": 5432,
        "name": "mydb"
    },
    "features": {
        "logging": True,
        "caching": True,
        "metrics": False
    }
}

# Симулируем статистику сервера
SERVER_STATS = {
    "uptime_seconds": 3600,
    "requests_handled": 150,
    "errors_count": 3,
    "active_connections": 5
}


@app.list_resources()
async def list_resources() -> list[Resource]:
    """
    Регистрируем список доступных ресурсов.
    
    Ресурсы идентифицируются по URI и могут представлять:
    - Конфигурационные данные (config://)
    - Файлы (file://)
    - Динамические данные (stats://, metrics://)
    
    Returns:
        list[Resource]: Список доступных ресурсов
    """
    return [
        # Конфигурация приложения
        Resource(
            uri="config://app",
            name="Application Configuration",
            description="Текущая конфигурация приложения в формате JSON",
            mimeType="application/json"
        ),
        
        # Статистика сервера
        Resource(
            uri="stats://server",
            name="Server Statistics",
            description="Статистика работы сервера: uptime, запросы, ошибки",
            mimeType="application/json"
        ),
        
        # Информация о системе
        Resource(
            uri="system://info",
            name="System Information",
            description="Информация о системе: Python версия, ОС, память",
            mimeType="text/plain"
        ),
        
        # Документация API
        Resource(
            uri="docs://api",
            name="API Documentation",
            description="Документация по доступным эндпоинтам API",
            mimeType="text/markdown"
        )
    ]


@app.read_resource()
async def read_resource(uri: str) -> str:
    """
    Обработчик чтения ресурсов по URI.
    
    Args:
        uri: Уникальный идентификатор ресурса
        
    Returns:
        str: Содержимое ресурса (текст или JSON)
        
    Raises:
        ValueError: Если ресурс не найден
    """
    
    # Конфигурация приложения
    if uri == "config://app":
        # Возвращаем конфигурацию в виде отформатированного JSON
        return json.dumps(APP_CONFIG, indent=2, ensure_ascii=False)
    
    # Статистика сервера
    elif uri == "stats://server":
        # Возвращаем актуальную статистику
        return json.dumps(SERVER_STATS, indent=2, ensure_ascii=False)
    
    # Системная информация
    elif uri == "system://info":
        import platform
        import sys
        
        # Собираем информацию о системе
        info_lines = [
            f"Python Version: {sys.version}",
            f"Platform: {platform.platform()}",
            f"Architecture: {platform.machine()}",
            f"Processor: {platform.processor()}",
        ]
        
        return "\\n".join(info_lines)
    
    # Документация API
    elif uri == "docs://api":
        # Возвращаем документацию в Markdown формате
        docs = """# API Documentation

## Available Endpoints

### Configuration
- **GET** `/config` - Получить текущую конфигурацию
- **POST** `/config` - Обновить конфигурацию

### Statistics
- **GET** `/stats` - Получить статистику сервера
- **GET** `/stats/requests` - Статистика по запросам
- **GET** `/stats/errors` - Статистика по ошибкам

### System
- **GET** `/system/health` - Проверка состояния системы
- **GET** `/system/info` - Информация о системе

## Response Format

Все ответы возвращаются в формате JSON:

```json
{
  "status": "success",
  "data": {...}
}
```

## Error Handling

В случае ошибки возвращается:

```json
{
  "status": "error",
  "message": "Error description",
  "code": 400
}
```
"""
        return docs
    
    # Неизвестный ресурс
    else:
        raise ValueError(f"Ресурс не найден: {uri}")


async def main():
    """Запуск сервера через stdio transport"""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

# 05_server_with_prompts.py
server_with_prompts = '''"""
MCP-сервер с промптами

Демонстрирует создание предопределенных промптов для общих задач:
- Ревью кода
- Объяснение ошибок
- Генерация документации
- Оптимизация кода
"""

import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Prompt, PromptArgument, PromptMessage, TextContent

# Создаем сервер
app = Server("prompt-server")


@app.list_prompts()
async def list_prompts() -> list[Prompt]:
    """
    Регистрируем список доступных промптов.
    
    Промпты - это шаблонные сообщения, которые пользователь
    может использовать для быстрого запуска типовых задач.
    
    Returns:
        list[Prompt]: Список доступных промптов
    """
    return [
        # Ревью кода
        Prompt(
            name="code_review",
            description="Проводит детальное ревью кода с рекомендациями",
            arguments=[
                PromptArgument(
                    name="language",
                    description="Язык программирования (python, javascript, go и т.д.)",
                    required=True
                ),
                PromptArgument(
                    name="code",
                    description="Код для ревью",
                    required=True
                ),
                PromptArgument(
                    name="focus",
                    description="Фокус ревью: security, performance, style, или all",
                    required=False
                )
            ]
        ),
        
        # Объяснение ошибки
        Prompt(
            name="explain_error",
            description="Объясняет ошибку простым языком и предлагает решения",
            arguments=[
                PromptArgument(
                    name="error_message",
                    description="Текст сообщения об ошибке",
                    required=True
                ),
                PromptArgument(
                    name="context",
                    description="Контекст, в котором произошла ошибка (опционально)",
                    required=False
                )
            ]
        ),
        
        # Генерация документации
        Prompt(
            name="generate_docs",
            description="Генерирует документацию для кода",
            arguments=[
                PromptArgument(
                    name="code",
                    description="Код для документирования",
                    required=True
                ),
                PromptArgument(
                    name="style",
                    description="Стиль документации: google, numpy, sphinx",
                    required=False
                )
            ]
        ),
        
        # Оптимизация кода
        Prompt(
            name="optimize_code",
            description="Предлагает оптимизации для улучшения производительности",
            arguments=[
                PromptArgument(
                    name="code",
                    description="Код для оптимизации",
                    required=True
                ),
                PromptArgument(
                    name="target",
                    description="Цель оптимизации: speed, memory, readability",
                    required=False
                )
            ]
        ),
        
        # Рефакторинг
        Prompt(
            name="refactor",
            description="Предлагает варианты рефакторинга кода",
            arguments=[
                PromptArgument(
                    name="code",
                    description="Код для рефакторинга",
                    required=True
                ),
                PromptArgument(
                    name="goal",
                    description="Цель рефакторинга: simplify, modularize, patterns",
                    required=False
                )
            ]
        )
    ]


@app.get_prompt()
async def get_prompt(name: str, arguments: dict) -> list[PromptMessage]:
    """
    Генерирует промпт на основе шаблона и аргументов.
    
    Args:
        name: Название промпта
        arguments: Аргументы для подстановки в шаблон
        
    Returns:
        list[PromptMessage]: Сгенерированные сообщения промпта
        
    Raises:
        ValueError: Если промпт не найден
    """
    
    # Ревью кода
    if name == "code_review":
        language = arguments["language"]
        code = arguments["code"]
        focus = arguments.get("focus", "all")
        
        # Определяем аспекты для проверки в зависимости от фокуса
        aspects = {
            "security": ["SQL-инъекции", "XSS", "небезопасные функции", "валидация входных данных"],
            "performance": ["сложность алгоритмов", "использование памяти", "избыточные операции"],
            "style": ["читаемость", "именование", "структура", "соответствие стандартам"],
            "all": ["безопасность", "производительность", "читаемость", "лучшие практики"]
        }
        
        focus_aspects = aspects.get(focus, aspects["all"])
        aspects_text = "\\n".join([f"- {aspect}" for aspect in focus_aspects])
        
        prompt_text = f"""Проведи детальное ревью следующего кода на {language}.

```{language}
{code}
```

Сфокусируйся на следующих аспектах:
{aspects_text}

Для каждой найденной проблемы укажи:
1. Описание проблемы
2. Почему это важно
3. Конкретное решение
4. Пример исправленного кода (если применимо)

В конце дай общую оценку качества кода и приоритетные рекомендации."""

        return [
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=prompt_text)
            )
        ]
    
    # Объяснение ошибки
    elif name == "explain_error":
        error_message = arguments["error_message"]
        context = arguments.get("context", "")
        
        context_section = f"\\n\\nКонтекст:\\n{context}" if context else ""
        
        prompt_text = f"""Объясни следующую ошибку простым и понятным языком:

```
{error_message}
```{context_section}

Пожалуйста, укажи:

1. **Что означает эта ошибка**: Объясни простыми словами, что пошло не так

2. **Возможные причины**: Перечисли наиболее вероятные причины возникновения этой ошибки

3. **Как исправить**: Дай пошаговую инструкцию по исправлению

4. **Как предотвратить**: Советы по предотвращению подобных ошибок в будущем

5. **Полезные ссылки**: Если применимо, укажи ссылки на документацию

Объяснение должно быть понятно даже начинающему разработчику."""

        return [
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=prompt_text)
            )
        ]
    
    # Генерация документации
    elif name == "generate_docs":
        code = arguments["code"]
        style = arguments.get("style", "google")
        
        style_examples = {
            "google": "Google Style (Args, Returns, Raises)",
            "numpy": "NumPy Style (Parameters, Returns, Raises)",
            "sphinx": "Sphinx Style (:param, :returns, :raises)"
        }
        
        style_description = style_examples.get(style, style_examples["google"])
        
        prompt_text = f"""Сгенерируй подробную документацию для следующего кода:

```python
{code}
```

Требования к документации:
- Используй стиль: {style_description}
- Добавь docstring для модуля/класса/функции
- Опиши все параметры с типами
- Укажи возвращаемое значение
- Перечисли возможные исключения
- Добавь примеры использования
- Используй русский язык

Результат должен быть готов к копированию в код."""

        return [
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=prompt_text)
            )
        ]
    
    # Оптимизация кода
    elif name == "optimize_code":
        code = arguments["code"]
        target = arguments.get("target", "speed")
        
        target_descriptions = {
            "speed": "производительность и скорость выполнения",
            "memory": "использование памяти",
            "readability": "читаемость и поддерживаемость"
        }
        
        target_desc = target_descriptions.get(target, target_descriptions["speed"])
        
        prompt_text = f"""Проанализируй следующий код и предложи оптимизации для улучшения: {target_desc}

```python
{code}
```

Для каждой оптимизации укажи:
1. **Что можно улучшить**: Конкретное место в коде
2. **Почему это неоптимально**: Объяснение проблемы
3. **Предложенное решение**: Оптимизированный вариант кода
4. **Измеримое улучшение**: Примерная оценка выигрыша (если применимо)
5. **Компромиссы**: Есть ли негативные эффекты от оптимизации

Приоритизируй рекомендации по влиянию на {target_desc}."""

        return [
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=prompt_text)
            )
        ]
    
    # Рефакторинг
    elif name == "refactor":
        code = arguments["code"]
        goal = arguments.get("goal", "simplify")
        
        goal_descriptions = {
            "simplify": "упростить и сделать более понятным",
            "modularize": "разбить на модули и улучшить структуру",
            "patterns": "применить паттерны проектирования"
        }
        
        goal_desc = goal_descriptions.get(goal, goal_descriptions["simplify"])
        
        prompt_text = f"""Предложи варианты рефакторинга для следующего кода с целью: {goal_desc}

```python
{code}
```

Требования к рефакторингу:
1. Сохрани функциональность (код должен работать так же)
2. Улучши качество кода согласно цели: {goal_desc}
3. Следуй принципам SOLID (где применимо)
4. Используй pythonic подходы

Представь результат в виде:
- **Текущие проблемы**: Что не так с текущим кодом
- **Предложенные изменения**: Пошаговое описание рефакторинга
- **Рефакторенный код**: Полный код после изменений
- **Выгоды**: Что улучшилось после рефакторинга"""

        return [
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=prompt_text)
            )
        ]
    
    # Неизвестный промпт
    else:
        raise ValueError(f"Промпт не найден: {name}")


async def main():
    """Запуск сервера через stdio transport"""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

# Сохраняю файлы
with open("mcp_course/modules/module_03_python_sdk/examples/04_server_with_resources.py", "w", encoding="utf-8") as f:
    f.write(server_with_resources)

with open("mcp_course/modules/module_03_python_sdk/examples/05_server_with_prompts.py", "w", encoding="utf-8") as f:
    f.write(server_with_prompts)

print("✅ Созданы примеры:")
print("  - 04_server_with_resources.py")
print("  - 05_server_with_prompts.py")
