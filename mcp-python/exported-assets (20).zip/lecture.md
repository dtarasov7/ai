# Модуль 4: Отладка и мониторинг MCP-серверов

## Введение

Отладка и мониторинг являются критически важными аспектами разработки MCP-серверов. В этом модуле мы рассмотрим инструменты и техники для эффективной диагностики проблем и мониторинга работы серверов.

## Логирование в MCP

### Стандартное логирование Python

MCP-серверы используют стандартный модуль `logging` Python для вывода диагностической информации.

**Базовая настройка**:

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),  # Вывод в stderr
        logging.FileHandler('mcp_server.log')  # Запись в файл
    ]
)

logger = logging.getLogger(__name__)
```

### Уровни логирования

- **DEBUG**: Детальная информация для диагностики
- **INFO**: Общая информация о работе сервера
- **WARNING**: Предупреждения о потенциальных проблемах
- **ERROR**: Ошибки, которые не останавливают работу
- **CRITICAL**: Критические ошибки, требующие немедленного внимания

**Пример использования**:

```python
@app.call_tool()
async def call_tool(name: str, arguments: dict):
    logger.debug(f"Получен запрос: tool={name}, args={arguments}")

    try:
        logger.info(f"Выполнение инструмента: {name}")
        result = execute_tool(name, arguments)
        logger.info(f"Инструмент {name} выполнен успешно")
        return result

    except ValueError as e:
        logger.warning(f"Ошибка валидации: {e}")
        raise

    except Exception as e:
        logger.error(f"Неожиданная ошибка в {name}: {e}", exc_info=True)
        raise
```

### Структурированное логирование

Для продакшн-систем рекомендуется использовать структурированное логирование с библиотекой `structlog`:

```python
import structlog

logger = structlog.get_logger()

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    logger.info(
        "tool_called",
        tool_name=name,
        args_count=len(arguments),
        timestamp=datetime.now().isoformat()
    )
```

## MCP Inspector

MCP Inspector — это официальный инструмент для интерактивной отладки MCP-серверов.

### Запуск Inspector

```bash
# Для stdio сервера
npx @modelcontextprotocol/inspector python my_server.py

# Для HTTP сервера
npx @modelcontextprotocol/inspector http://localhost:8000/mcp

# С дополнительными аргументами
npx @modelcontextprotocol/inspector python my_server.py --arg1 value1
```

### Возможности Inspector

1. **Визуализация соединения**:
   - Статус подключения (connected/disconnected)
   - Информация о сервере (name, version)
   - Список capabilities

2. **Тестирование инструментов**:
   - Просмотр всех зарегистрированных tools
   - Интерактивное заполнение параметров
   - Выполнение с произвольными входными данными
   - Просмотр результатов и ошибок

3. **Работа с ресурсами**:
   - Список доступных resources
   - Чтение содержимого
   - Тестирование подписок на изменения

4. **Отладка промптов**:
   - Просмотр списка prompts
   - Генерация с тестовыми параметрами
   - Проверка шаблонов

5. **История запросов**:
   - Логирование всех JSON-RPC сообщений
   - Возможность экспорта в JSON
   - Повторное выполнение запросов

### Интерфейс Inspector

После запуска Inspector открывается веб-интерфейс на `http://localhost:5173`:

- **Connection Panel**: Статус соединения и server info
- **Tools Panel**: Список и тестирование инструментов
- **Resources Panel**: Просмотр и чтение ресурсов
- **Prompts Panel**: Тестирование промптов
- **Logs Panel**: История JSON-RPC сообщений

## Диагностика проблем

### Типичные проблемы и решения

#### 1. Сервер не запускается

**Симптомы**:
- Процесс завершается сразу после запуска
- Нет вывода в stdout

**Диагностика**:
```bash
# Запустите напрямую с логированием
python my_server.py 2>error.log

# Проверьте синтаксис
python -m py_compile my_server.py
```

**Возможные причины**:
- Синтаксические ошибки в коде
- Отсутствие зависимостей
- Неправильная настройка asyncio

#### 2. Клиент не может подключиться

**Симптомы**:
- Timeout при подключении
- Connection refused

**Диагностика**:
```python
# Добавьте отладочный вывод в сервер
async def main():
    print("Server starting...", file=sys.stderr)
    async with stdio_server() as (read, write):
        print("Server ready", file=sys.stderr)
        await app.run(read, write, app.create_initialization_options())
```

**Возможные причины**:
- Неправильный путь к серверу в клиенте
- Сервер завершается до установки соединения
- Проблемы с правами доступа

#### 3. Инструменты не вызываются

**Симптомы**:
- tools/list возвращает пустой список
- tools/call возвращает "method not found"

**Диагностика**:
```python
# Проверьте регистрацию handlers
@app.list_tools()
async def list_tools():
    tools = [...]  # Ваши инструменты
    print(f"Registered tools: {[t.name for t in tools]}", file=sys.stderr)
    return tools
```

**Возможные причины**:
- Декораторы не применены к функциям
- Функции не async
- Неправильная сигнатура функции

#### 4. Ошибки валидации параметров

**Симптомы**:
- Invalid params error
- JSON Schema validation failed

**Диагностика**:
```python
@app.call_tool()
async def call_tool(name: str, arguments: dict):
    # Логируйте входящие параметры
    logger.debug(f"Tool: {name}, Args: {json.dumps(arguments, indent=2)}")

    # Валидируйте вручную для отладки
    if name == "my_tool":
        required_fields = ["field1", "field2"]
        missing = [f for f in required_fields if f not in arguments]
        if missing:
            logger.error(f"Missing fields: {missing}")
```

**Возможные причины**:
- JSON Schema не соответствует ожидаемым параметрам
- Типы данных не совпадают
- Отсутствуют required поля

#### 5. Проблемы с производительностью

**Симптомы**:
- Медленные ответы
- Таймауты
- Высокое использование памяти

**Диагностика**:
```python
import time
import asyncio

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    start_time = time.time()

    try:
        result = await execute_tool(name, arguments)

        elapsed = time.time() - start_time
        logger.info(f"Tool {name} executed in {elapsed:.2f}s")

        return result
    finally:
        # Всегда логируем время выполнения
        elapsed = time.time() - start_time
        if elapsed > 5.0:  # Предупреждение если больше 5 секунд
            logger.warning(f"Slow tool execution: {name} took {elapsed:.2f}s")
```

**Возможные причины**:
- Блокирующие операции I/O
- Отсутствие кэширования
- Неэффективные алгоритмы
- Утечки памяти

## Мониторинг в продакшн

### Метрики для отслеживания

1. **Доступность**:
   - Uptime сервера
   - Частота перезапусков
   - Время ответа на ping

2. **Производительность**:
   - Среднее время выполнения инструментов
   - Количество запросов в секунду
   - Задержка ответа

3. **Ошибки**:
   - Количество ошибок по типам
   - Частота ошибок
   - Стек-трейсы критических ошибок

4. **Ресурсы**:
   - Использование CPU
   - Использование памяти
   - Количество открытых файлов

### Интеграция с системами мониторинга

**Prometheus**:
```python
from prometheus_client import Counter, Histogram, start_http_server

# Метрики
tool_calls = Counter('mcp_tool_calls_total', 'Total tool calls', ['tool_name'])
tool_duration = Histogram('mcp_tool_duration_seconds', 'Tool execution time', ['tool_name'])
tool_errors = Counter('mcp_tool_errors_total', 'Tool errors', ['tool_name', 'error_type'])

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    tool_calls.labels(tool_name=name).inc()

    with tool_duration.labels(tool_name=name).time():
        try:
            return await execute_tool(name, arguments)
        except Exception as e:
            tool_errors.labels(tool_name=name, error_type=type(e).__name__).inc()
            raise

# Запуск Prometheus exporter
start_http_server(9090)
```

## Best Practices для отладки

### 1. Используйте контекстное логирование

```python
import contextvars

request_id = contextvars.ContextVar('request_id', default='unknown')

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    req_id = str(uuid.uuid4())
    request_id.set(req_id)

    logger.info(f"[{req_id}] Tool called: {name}")
    # ... выполнение
    logger.info(f"[{req_id}] Tool completed: {name}")
```

### 2. Добавляйте версионирование

```python
SERVER_VERSION = "1.2.3"

app = Server("my-server")

# Логируйте версию при запуске
logger.info(f"Starting MCP server version {SERVER_VERSION}")
```

### 3. Graceful shutdown

```python
import signal

shutdown_event = asyncio.Event()

def signal_handler(sig, frame):
    logger.info(f"Received signal {sig}, shutting down...")
    shutdown_event.set()

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

async def main():
    async with stdio_server() as (read, write):
        server_task = asyncio.create_task(
            app.run(read, write, app.create_initialization_options())
        )

        await shutdown_event.wait()
        server_task.cancel()

        logger.info("Server shutdown complete")
```

### 4. Валидация на входе

```python
from pydantic import BaseModel, ValidationError

class ToolArguments(BaseModel):
    field1: str
    field2: int
    field3: Optional[list[str]] = None

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    try:
        # Валидируем через Pydantic
        args = ToolArguments(**arguments)
        logger.debug(f"Validated args: {args}")

        # Работаем с валидированными данными
        result = process(args.field1, args.field2)

    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        raise ValueError(f"Invalid arguments: {e}")
```

### 5. Обработка таймаутов

```python
@app.call_tool()
async def call_tool(name: str, arguments: dict):
    try:
        # Устанавливаем таймаут 30 секунд
        async with asyncio.timeout(30):
            result = await execute_long_operation(arguments)
            return result

    except asyncio.TimeoutError:
        logger.error(f"Tool {name} timed out after 30s")
        raise ValueError(f"Operation timed out")
```

## Инструменты отладки

### 1. MCP Inspector (основной инструмент)

Используйте для:
- Интерактивного тестирования
- Проверки JSON-RPC сообщений
- Отладки схем данных

### 2. Python Debugger (pdb)

```python
import pdb

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "problematic_tool":
        pdb.set_trace()  # Точка останова

    result = execute_tool(name, arguments)
    return result
```

### 3. Async профилирование

```python
import asyncio
import cProfile

async def main():
    profiler = cProfile.Profile()
    profiler.enable()

    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())

    profiler.disable()
    profiler.print_stats(sort='cumtime')
```

## Заключение

Эффективная отладка и мониторинг критически важны для надежной работы MCP-серверов. Используйте комбинацию инструментов:

- Логирование для диагностики проблем
- MCP Inspector для интерактивного тестирования
- Метрики для мониторинга в продакшн
- Best practices для предотвращения проблем

В следующем модуле мы рассмотрим интеграцию MCP-серверов с LLM-хостами, такими как Claude Desktop.

## Контрольные вопросы

1. Какие уровни логирования существуют и когда их использовать?
2. Как запустить MCP Inspector для stdio сервера?
3. Какие метрики важно отслеживать в продакшн?
4. Как диагностировать проблему "tools/list возвращает пустой список"?
5. Что такое graceful shutdown и зачем он нужен?

## Практические задания

1. Добавьте детальное логирование в существующий MCP-сервер
2. Протестируйте сервер с помощью MCP Inspector
3. Реализуйте обработку таймаутов для длительных операций
4. Добавьте метрики Prometheus в сервер
