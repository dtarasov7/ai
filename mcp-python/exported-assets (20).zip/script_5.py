
# Создам примеры кода и диаграммы для модуля 4

# 01_logging_example.py
logging_example = '''"""
Пример использования логирования в MCP-сервере

Демонстрирует различные уровни логирования и лучшие практики
"""

import asyncio
import logging
import sys
from datetime import datetime
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Настройка логирования с выводом в stderr и файл
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
    handlers=[
        # Вывод в stderr (клиент увидит логи)
        logging.StreamHandler(sys.stderr),
        # Запись в файл для постоянного хранения
        logging.FileHandler('mcp_server.log', encoding='utf-8')
    ]
)

logger = logging.getLogger(__name__)

# Создаем сервер
app = Server("logging-demo-server")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Регистрация инструментов с логированием"""
    # DEBUG: Детальная информация для разработчиков
    logger.debug("Функция list_tools() вызвана")
    
    tools = [
        Tool(
            name="process_data",
            description="Обрабатывает данные с логированием каждого шага",
            inputSchema={
                "type": "object",
                "properties": {
                    "data": {
                        "type": "string",
                        "description": "Данные для обработки"
                    },
                    "steps": {
                        "type": "integer",
                        "description": "Количество шагов обработки",
                        "minimum": 1,
                        "maximum": 10
                    }
                },
                "required": ["data", "steps"]
            }
        ),
        
        Tool(
            name="simulate_error",
            description="Симулирует различные типы ошибок для демонстрации логирования",
            inputSchema={
                "type": "object",
                "properties": {
                    "error_type": {
                        "type": "string",
                        "enum": ["validation", "runtime", "timeout"],
                        "description": "Тип ошибки для симуляции"
                    }
                },
                "required": ["error_type"]
            }
        )
    ]
    
    # INFO: Общая информация о работе
    logger.info(f"Зарегистрировано инструментов: {len(tools)}")
    logger.debug(f"Инструменты: {[t.name for t in tools]}")
    
    return tools


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Обработка вызовов инструментов с детальным логированием"""
    
    # Логируем входящий запрос
    logger.info(f"=== Начало обработки инструмента '{name}' ===")
    logger.debug(f"Аргументы: {arguments}")
    
    try:
        # Обработка данных
        if name == "process_data":
            data = arguments["data"]
            steps = arguments["steps"]
            
            logger.info(f"Обработка данных: длина={len(data)}, шагов={steps}")
            
            results = []
            for i in range(steps):
                # Логируем каждый шаг
                logger.debug(f"Шаг {i+1}/{steps}: обработка...")
                
                # Симуляция обработки
                await asyncio.sleep(0.1)
                
                result = f"Шаг {i+1}: обработано {len(data)} символов"
                results.append(result)
                
                logger.debug(f"Шаг {i+1} завершен успешно")
            
            logger.info(f"Обработка завершена успешно за {steps} шагов")
            
            return [TextContent(
                type="text",
                text="\\n".join(results)
            )]
        
        # Симуляция ошибок
        elif name == "simulate_error":
            error_type = arguments["error_type"]
            
            logger.warning(f"Симуляция ошибки типа: {error_type}")
            
            if error_type == "validation":
                # WARNING: Предупреждение о проблемах валидации
                logger.warning("Обнаружена ошибка валидации данных")
                raise ValueError("Невалидные входные данные")
                
            elif error_type == "runtime":
                # ERROR: Ошибка выполнения
                logger.error("Произошла ошибка выполнения", exc_info=False)
                raise RuntimeError("Ошибка при выполнении операции")
                
            elif error_type == "timeout":
                # CRITICAL: Критическая ошибка
                logger.critical("Операция превысила максимальное время ожидания")
                raise asyncio.TimeoutError("Превышено время ожидания")
        
        else:
            # Неизвестный инструмент
            logger.error(f"Попытка вызвать неизвестный инструмент: {name}")
            raise ValueError(f"Неизвестный инструмент: {name}")
    
    except ValueError as e:
        # Логируем ошибки валидации
        logger.warning(f"Ошибка валидации в '{name}': {e}")
        return [TextContent(
            type="text",
            text=f"❌ Ошибка валидации: {str(e)}"
        )]
    
    except RuntimeError as e:
        # Логируем ошибки выполнения
        logger.error(f"Ошибка выполнения в '{name}': {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=f"❌ Ошибка выполнения: {str(e)}"
        )]
    
    except Exception as e:
        # Логируем неожиданные ошибки с полным стек-трейсом
        logger.critical(
            f"Неожиданная ошибка в '{name}': {type(e).__name__}: {e}",
            exc_info=True  # Включаем стек-трейс
        )
        return [TextContent(
            type="text",
            text=f"❌ Критическая ошибка: {str(e)}"
        )]
    
    finally:
        # Всегда логируем завершение обработки
        logger.info(f"=== Завершение обработки инструмента '{name}' ===")


async def main():
    """Запуск сервера с логированием lifecycle событий"""
    
    # Логируем запуск сервера
    logger.info("=" * 60)
    logger.info("Запуск MCP сервера с демонстрацией логирования")
    logger.info(f"Время запуска: {datetime.now().isoformat()}")
    logger.info("=" * 60)
    
    try:
        async with stdio_server() as (read_stream, write_stream):
            logger.info("stdio transport инициализирован")
            logger.info("Сервер готов к приему запросов")
            
            # Запускаем сервер
            await app.run(
                read_stream,
                write_stream,
                app.create_initialization_options()
            )
            
    except KeyboardInterrupt:
        # Логируем graceful shutdown
        logger.info("Получен сигнал прерывания (Ctrl+C)")
        logger.info("Выполняется graceful shutdown...")
        
    except Exception as e:
        # Логируем критические ошибки при запуске
        logger.critical(f"Критическая ошибка при запуске сервера: {e}", exc_info=True)
        raise
        
    finally:
        # Всегда логируем завершение работы
        logger.info("=" * 60)
        logger.info("Сервер остановлен")
        logger.info(f"Время остановки: {datetime.now().isoformat()}")
        logger.info("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
'''

# 02_error_handling.py
error_handling = '''"""
Пример продвинутой обработки ошибок в MCP-сервере

Демонстрирует:
- Различные типы ошибок
- Retry механизм
- Таймауты
- Graceful degradation
"""

import asyncio
import logging
from typing import Optional
from datetime import datetime
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Server("error-handling-server")


# Декоратор для retry логики
def retry_on_error(max_attempts=3, delay=1.0):
    """
    Декоратор для автоматического повтора при ошибках
    
    Args:
        max_attempts: Максимальное количество попыток
        delay: Задержка между попытками в секундах
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(1, max_attempts + 1):
                try:
                    logger.info(f"Попытка {attempt}/{max_attempts}")
                    result = await func(*args, **kwargs)
                    
                    if attempt > 1:
                        logger.info(f"Успех после {attempt} попыток")
                    
                    return result
                    
                except Exception as e:
                    last_exception = e
                    logger.warning(
                        f"Попытка {attempt} не удалась: {type(e).__name__}: {e}"
                    )
                    
                    if attempt < max_attempts:
                        logger.info(f"Повтор через {delay} секунд...")
                        await asyncio.sleep(delay)
                    else:
                        logger.error(f"Все {max_attempts} попытки исчерпаны")
            
            # Если все попытки неудачны, выбрасываем последнюю ошибку
            raise last_exception
        
        return wrapper
    return decorator


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="flaky_operation",
            description="Операция, которая может случайно падать (демонстрация retry)",
            inputSchema={
                "type": "object",
                "properties": {
                    "success_rate": {
                        "type": "number",
                        "description": "Вероятность успеха (0.0 - 1.0)",
                        "minimum": 0.0,
                        "maximum": 1.0
                    }
                },
                "required": ["success_rate"]
            }
        ),
        
        Tool(
            name="timeout_operation",
            description="Операция с таймаутом (демонстрация timeout handling)",
            inputSchema={
                "type": "object",
                "properties": {
                    "duration": {
                        "type": "number",
                        "description": "Длительность операции в секундах"
                    },
                    "timeout": {
                        "type": "number",
                        "description": "Максимальное время ожидания в секундах"
                    }
                },
                "required": ["duration", "timeout"]
            }
        ),
        
        Tool(
            name="validated_operation",
            description="Операция с строгой валидацией входных данных",
            inputSchema={
                "type": "object",
                "properties": {
                    "email": {
                        "type": "string",
                        "description": "Email адрес"
                    },
                    "age": {
                        "type": "integer",
                        "description": "Возраст (18-120)"
                    }
                },
                "required": ["email", "age"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Обработчик с продвинутой обработкой ошибок"""
    
    try:
        # Flaky operation с retry
        if name == "flaky_operation":
            success_rate = arguments["success_rate"]
            
            @retry_on_error(max_attempts=3, delay=0.5)
            async def unreliable_operation():
                import random
                
                # Симулируем случайные ошибки
                if random.random() > success_rate:
                    raise RuntimeError("Случайная ошибка операции")
                
                return "Операция выполнена успешно"
            
            result = await unreliable_operation()
            return [TextContent(type="text", text=result)]
        
        # Операция с таймаутом
        elif name == "timeout_operation":
            duration = arguments["duration"]
            timeout = arguments["timeout"]
            
            try:
                # Устанавливаем таймаут
                async with asyncio.timeout(timeout):
                    logger.info(f"Начало операции (длительность: {duration}s, таймаут: {timeout}s)")
                    
                    # Симулируем длительную операцию
                    await asyncio.sleep(duration)
                    
                    logger.info("Операция завершена успешно")
                    return [TextContent(
                        type="text",
                        text=f"Операция завершена за {duration} секунд"
                    )]
                    
            except asyncio.TimeoutError:
                logger.error(f"Операция превысила таймаут {timeout}s")
                return [TextContent(
                    type="text",
                    text=f"❌ Таймаут: операция не завершилась за {timeout} секунд"
                )]
        
        # Валидация данных
        elif name == "validated_operation":
            email = arguments["email"]
            age = arguments["age"]
            
            # Валидация email
            if "@" not in email or "." not in email:
                logger.warning(f"Невалидный email: {email}")
                return [TextContent(
                    type="text",
                    text="❌ Ошибка валидации: невалидный email адрес"
                )]
            
            # Валидация возраста
            if not (18 <= age <= 120):
                logger.warning(f"Невалидный возраст: {age}")
                return [TextContent(
                    type="text",
                    text=f"❌ Ошибка валидации: возраст должен быть от 18 до 120 (получено: {age})"
                )]
            
            logger.info(f"Валидация успешна: email={email}, age={age}")
            return [TextContent(
                type="text",
                text=f"✅ Данные валидны: {email}, возраст {age} лет"
            )]
        
        else:
            raise ValueError(f"Неизвестный инструмент: {name}")
    
    except ValueError as e:
        # Ошибки валидации и неизвестные инструменты
        logger.error(f"Ошибка валидации: {e}")
        return [TextContent(type="text", text=f"❌ {str(e)}")]
    
    except RuntimeError as e:
        # Ошибки выполнения
        logger.error(f"Ошибка выполнения: {e}")
        return [TextContent(type="text", text=f"❌ Ошибка выполнения: {str(e)}")]
    
    except Exception as e:
        # Неожиданные ошибки
        logger.critical(f"Неожиданная ошибка: {type(e).__name__}: {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=f"❌ Критическая ошибка: {type(e).__name__}"
        )]


async def main():
    """Запуск сервера с обработкой ошибок"""
    logger.info("Запуск сервера с продвинутой обработкой ошибок")
    
    try:
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream,
                write_stream,
                app.create_initialization_options()
            )
    except KeyboardInterrupt:
        logger.info("Graceful shutdown по Ctrl+C")
    except Exception as e:
        logger.critical(f"Критическая ошибка сервера: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    asyncio.run(main())
'''

# Сохраняю примеры
with open("mcp_course/modules/module_04_debugging/examples/01_logging_example.py", "w", encoding="utf-8") as f:
    f.write(logging_example)

with open("mcp_course/modules/module_04_debugging/examples/02_error_handling.py", "w", encoding="utf-8") as f:
    f.write(error_handling)

print("✅ Примеры модуля 4 созданы:")
print("  - 01_logging_example.py")
print("  - 02_error_handling.py")
