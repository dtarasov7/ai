
# Создам диаграммы для модуля 3

# mindmap для модуля 3
module3_mindmap = """@startmindmap
* MCP Python SDK

** Установка
*** pip install mcp
*** uv pip install mcp
*** Зависимости
**** asyncio
**** pydantic

** Основные компоненты
*** Server
**** Создание серверов
**** Регистрация handlers
**** Управление capabilities
*** ClientSession
**** Подключение к серверам
**** Отправка запросов
**** Получение ответов
*** Transport
**** stdio
**** HTTP/SSE
*** Types
**** Tool
**** Resource
**** Prompt
**** TextContent

left side

** Декораторы Server
*** @app.list_tools()
**** Список инструментов
*** @app.call_tool()
**** Вызов инструментов
*** @app.list_resources()
**** Список ресурсов
*** @app.read_resource()
**** Чтение ресурсов
*** @app.list_prompts()
**** Список промптов
*** @app.get_prompt()
**** Генерация промптов

** Tools (Инструменты)
*** JSON Schema
**** Описание параметров
**** Валидация
*** Типы возврата
**** TextContent
**** ImageContent
**** EmbeddedResource
*** Обработка ошибок
**** try/except
**** Валидация входных данных

** Resources (Ресурсы)
*** URI схемы
**** file://
**** config://
**** data://
*** MIME типы
**** application/json
**** text/plain
**** text/markdown
*** Подписки
**** subscribe
**** unsubscribe

** Prompts (Промпты)
*** Аргументы
**** required/optional
**** Типы данных
*** PromptMessage
**** role: user/assistant
**** content: TextContent
*** Шаблоны
**** Динамическая генерация

** Клиент
*** StdioServerParameters
**** command
**** args
**** env
*** Методы ClientSession
**** initialize()
**** list_tools()
**** call_tool()
**** list_resources()
**** read_resource()

** Best Practices
*** Именование
**** kebab-case для серверов
**** snake_case для tools
*** Асинхронность
**** async/await для I/O
*** Валидация
**** Проверка входных данных
*** Логирование
**** logging module
*** Безопасность
**** Sandboxing
**** Rate limiting

@endmindmap
"""

# SDK архитектурная диаграмма
module3_sdk_arch = """@startuml

skinparam component {
    BackgroundColor<<server>> #C8E6C9
    BackgroundColor<<client>> #FFF9C4
    BackgroundColor<<transport>> #E1F5FE
    BackgroundColor<<types>> #F3E5F5
    BorderColor #333333
}

package "MCP Python SDK" {
    
    package "Server Components" <<server>> {
        component "Server" as server {
            [Handler Registry]
            [Capability Manager]
            [Request Router]
        }
        
        component "Decorators" as decorators {
            [@list_tools()]
            [@call_tool()]
            [@list_resources()]
            [@read_resource()]
            [@list_prompts()]
            [@get_prompt()]
        }
    }
    
    package "Client Components" <<client>> {
        component "ClientSession" as client {
            [Connection Manager]
            [Request Builder]
            [Response Parser]
        }
        
        component "Client API" as client_api {
            [initialize()]
            [list_tools()]
            [call_tool()]
            [list_resources()]
            [read_resource()]
        }
    }
    
    package "Transport Layer" <<transport>> {
        component "stdio" as stdio {
            [StdioServerParameters]
            [stdin/stdout handler]
        }
        
        component "HTTP/SSE" as http {
            [HTTP POST]
            [Server-Sent Events]
        }
    }
    
    package "Data Types" <<types>> {
        component "Core Types" as types {
            [Tool]
            [Resource]
            [Prompt]
            [TextContent]
            [PromptMessage]
        }
    }
}

' Connections
decorators --> server : registers handlers
client_api --> client : uses
server --> stdio : uses
server --> http : uses
client --> stdio : uses
client --> http : uses
server --> types : uses
client --> types : uses

note right of server
  Серверная часть:
  - Регистрация handlers
  - Обработка запросов
  - Управление capabilities
end note

note left of client
  Клиентская часть:
  - Подключение к серверам
  - Отправка запросов
  - Обработка ответов
end note

note bottom of stdio
  Локальный transport:
  - Быстрый
  - Без сети
  - Дочерние процессы
end note

@enduml
"""

# Сохраняю диаграммы
with open("mcp_course/modules/module_03_python_sdk/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module3_mindmap)

with open("mcp_course/modules/module_03_python_sdk/sdk_architecture.puml", "w", encoding="utf-8") as f:
    f.write(module3_sdk_arch)

print("✅ Модуль 3 завершен - созданы диаграммы:")
print("  - mindmap.puml")
print("  - sdk_architecture.puml")
print("\n📦 Модуль 3 полностью готов!")
