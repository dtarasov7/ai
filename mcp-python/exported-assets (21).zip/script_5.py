
# Создам примеры и диаграммы для модуля 6, затем модуль 7

# Пример интеграции с Anthropic
anthropic_example = '''"""
Интеграция MCP с Anthropic Claude API

Полный пример создания AI-ассистента с MCP инструментами
"""

import asyncio
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from anthropic import Anthropic


class MCPClaudeAssistant:
    """AI-ассистент на базе Claude с MCP инструментами"""
    
    def __init__(self, api_key: str):
        self.client = Anthropic(api_key=api_key)
        self.mcp_session = None
        self.tools = []
    
    async def connect_mcp(self, command: str, args: list):
        """Подключение к MCP-серверу"""
        server_params = StdioServerParameters(command=command, args=args)
        
        self.stdio = stdio_client(server_params)
        read, write = await self.stdio.__aenter__()
        
        self.session = ClientSession(read, write)
        self.mcp_session = await self.session.__aenter__()
        
        await self.mcp_session.initialize()
        
        # Получаем инструменты
        tools_result = await self.mcp_session.list_tools()
        self.tools = [
            {
                "name": t.name,
                "description": t.description,
                "input_schema": t.inputSchema
            }
            for t in tools_result.tools
        ]
        
        print(f"✅ Подключено {len(self.tools)} инструментов")
    
    async def chat(self, message: str):
        """Диалог с Claude"""
        messages = [{"role": "user", "content": message}]
        
        print(f"\\n👤 Вы: {message}\\n")
        
        for _ in range(5):  # Максимум 5 итераций
            response = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=2048,
                tools=self.tools,
                messages=messages
            )
            
            if response.stop_reason == "tool_use":
                # Выполняем инструменты
                tool_results = []
                
                for block in response.content:
                    if block.type == "tool_use":
                        print(f"🔧 {block.name}({block.input})")
                        
                        result = await self.mcp_session.call_tool(
                            block.name, block.input
                        )
                        
                        text = next(c.text for c in result.content if hasattr(c, 'text'))
                        print(f"   → {text}\\n")
                        
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": text
                        })
                
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": tool_results})
            
            elif response.stop_reason == "end_turn":
                answer = next(b.text for b in response.content if b.type == "text")
                print(f"🤖 Claude: {answer}\\n")
                break
    
    async def close(self):
        """Закрытие соединений"""
        if self.mcp_session:
            await self.session.__aexit__(None, None, None)
            await self.stdio.__aexit__(None, None, None)


async def main():
    assistant = MCPClaudeAssistant(os.environ["ANTHROPIC_API_KEY"])
    
    await assistant.connect_mcp(
        "python",
        ["../../module_03_python_sdk/examples/03_server_with_tools.py"]
    )
    
    await assistant.chat("Переведи 'Hello' в верхний регистр и посчитай 10 + 20")
    
    await assistant.close()


if __name__ == "__main__":
    asyncio.run(main())
'''

# Пример с OpenAI
openai_example = '''"""
Интеграция MCP с OpenAI GPT API

Пример function calling с GPT-4
"""

import asyncio
import os
import json
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from openai import OpenAI


def mcp_to_openai_function(tool):
    """Конвертирует MCP Tool в OpenAI Function"""
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.inputSchema
        }
    }


async def chat_with_tools():
    """Диалог с GPT-4 и MCP инструментами"""
    
    # Подключаемся к MCP
    server_params = StdioServerParameters(
        command="python",
        args=["../../module_03_python_sdk/examples/03_server_with_tools.py"]
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as mcp_session:
            await mcp_session.initialize()
            
            # Получаем инструменты
            tools_result = await mcp_session.list_tools()
            openai_tools = [mcp_to_openai_function(t) for t in tools_result.tools]
            
            print(f"✅ Доступно {len(openai_tools)} инструментов\\n")
            
            # OpenAI клиент
            client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
            
            messages = [
                {"role": "user", "content": "Посчитай 15 умножить на 3"}
            ]
            
            print(f"👤 Вы: {messages[0]['content']}\\n")
            
            for _ in range(5):
                response = client.chat.completions.create(
                    model="gpt-4-turbo",
                    messages=messages,
                    tools=openai_tools,
                    tool_choice="auto"
                )
                
                message = response.choices[0].message
                
                if message.tool_calls:
                    # Выполняем вызванные функции
                    messages.append(message)
                    
                    for tool_call in message.tool_calls:
                        print(f"🔧 {tool_call.function.name}")
                        print(f"   Аргументы: {tool_call.function.arguments}")
                        
                        # Вызываем через MCP
                        result = await mcp_session.call_tool(
                            tool_call.function.name,
                            json.loads(tool_call.function.arguments)
                        )
                        
                        text = next(c.text for c in result.content if hasattr(c, 'text'))
                        print(f"   Результат: {text}\\n")
                        
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": text
                        })
                else:
                    # Финальный ответ
                    print(f"🤖 GPT-4: {message.content}\\n")
                    break


if __name__ == "__main__":
    asyncio.run(chat_with_tools())
'''

# Mindmap модуля 6
module6_mindmap = """@startmindmap
* Интеграция с LLM

** Anthropic Claude
*** API Setup
**** pip install anthropic
**** API ключ
*** Tool calling
**** Нативная поддержка
**** JSON Schema формат
*** Преобразование
**** MCP → Anthropic
**** Прямое соответствие
*** Обработка
**** tool_use response
**** tool_result request

left side

** OpenAI GPT
*** API Setup
**** pip install openai
**** API ключ
*** Function calling
**** GPT-4, GPT-3.5-turbo
**** parameters формат
*** Преобразование
**** MCP → OpenAI
**** input_schema → parameters
*** Обработка
**** function_call response
**** function result

** Интеграция
*** MCP Client
**** Подключение к серверам
**** Получение инструментов
*** Преобразователь
**** Конвертация форматов
**** Адаптация схем
*** Executor
**** Вызов через MCP
**** Возврат результатов

** Best Practices
*** Кэширование
**** LRU cache
**** Хэширование промптов
*** Мониторинг
**** Подсчет токенов
**** Стоимость запросов
*** Обработка ошибок
**** Retry логика
**** Таймауты
**** Graceful degradation

** Оптимизация
*** Батчинг
**** Группировка запросов
*** Стриминг
**** Потоковые ответы
*** Лимиты
**** Обрезка истории
**** Token limits

@endmindmap
"""

# Диаграмма последовательности
module6_sequence = """@startuml

title Интеграция MCP с LLM API

participant "Приложение" as app
participant "MCP Client" as client
participant "MCP Server" as server
participant "LLM API\\n(Claude/GPT)" as llm

== Инициализация ==

app -> client: Подключение к серверу
client -> server: initialize()
server --> client: capabilities

client -> server: tools/list
server --> client: [MCP Tools]

client -> app: Инструменты получены
app -> app: Конвертация\\nMCP → LLM формат

== Диалог с инструментами ==

app -> llm: messages.create()\\n+ tools
activate llm

llm -> llm: Анализ запроса
llm --> app: tool_use/function_call
deactivate llm

app -> app: Парсинг вызова\\nинструмента

app -> client: call_tool(name, args)
activate client

client -> server: tools/call
activate server

server -> server: Выполнение\\nинструмента
server --> client: result
deactivate server

client --> app: TextContent
deactivate client

app -> llm: Продолжение диалога\\n+ tool_result
activate llm

llm -> llm: Генерация ответа\\nс учетом результата
llm --> app: Финальный ответ
deactivate llm

app -> app: Отображение\\nпользователю

@enduml
"""

# Сохраняю файлы
with open("mcp_course/modules/module_06_llm_integration/examples/anthropic_integration.py", "w", encoding="utf-8") as f:
    f.write(anthropic_example)

with open("mcp_course/modules/module_06_llm_integration/examples/openai_integration.py", "w", encoding="utf-8") as f:
    f.write(openai_example)

with open("mcp_course/modules/module_06_llm_integration/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module6_mindmap)

with open("mcp_course/modules/module_06_llm_integration/sequence_diagram.puml", "w", encoding="utf-8") as f:
    f.write(module6_sequence)

print("✅ Модуль 6 завершен:")
print("  - lecture.md")
print("  - anthropic_integration.py")
print("  - openai_integration.py")
print("  - mindmap.puml")
print("  - sequence_diagram.puml")
print("\n📦 Модуль 6 полностью готов!")
