
# Создам модуль 6 - Интеграция с LLM моделями

module6_lecture = """# Модуль 6: Интеграция MCP с LLM моделями

## Введение

В этом модуле мы рассмотрим, как интегрировать MCP-серверы с различными языковыми моделями через их API. Мы изучим работу с Anthropic Claude, OpenAI GPT, и другими моделями.

## Концепция интеграции

### Архитектура интеграции

```
Ваше приложение
    ↓
MCP Client ←→ MCP Server (ваши инструменты)
    ↓
LLM API (Claude, GPT, etc.)
```

**Ключевые компоненты**:
1. **MCP Client**: Подключается к вашим серверам и получает инструменты
2. **Преобразователь**: Конвертирует MCP tools в формат API LLM
3. **LLM API**: Принимает запросы с инструментами
4. **Executor**: Выполняет вызванные инструменты через MCP

## Anthropic Claude API

### Настройка

```bash
pip install anthropic mcp
```

```python
import os
from anthropic import Anthropic

client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
```

### Tool calling с Claude

Claude 3.5 Sonnet и новее поддерживают нативный tool calling:

```python
# Определение инструментов в формате Anthropic
tools = [
    {
        "name": "get_weather",
        "description": "Получает текущую погоду для указанного города",
        "input_schema": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "Название города"
                },
                "units": {
                    "type": "string",
                    "enum": ["celsius", "fahrenheit"],
                    "description": "Единицы измерения температуры"
                }
            },
            "required": ["city"]
        }
    }
]

# Запрос к Claude
response = client.messages.create(
    model="claude-3-5-sonnet-20241022",
    max_tokens=1024,
    tools=tools,
    messages=[
        {"role": "user", "content": "Какая погода в Москве?"}
    ]
)
```

### Обработка tool_use

```python
if response.stop_reason == "tool_use":
    for content_block in response.content:
        if content_block.type == "tool_use":
            tool_name = content_block.name
            tool_input = content_block.input
            
            # Выполняем инструмент
            result = execute_tool(tool_name, tool_input)
            
            # Продолжаем диалог с результатом
            response = client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                tools=tools,
                messages=[
                    {"role": "user", "content": "Какая погода в Москве?"},
                    {"role": "assistant", "content": response.content},
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": content_block.id,
                                "content": str(result)
                            }
                        ]
                    }
                ]
            )
```

### Преобразование MCP → Anthropic

```python
def mcp_tool_to_anthropic(mcp_tool):
    """Конвертирует MCP Tool в формат Anthropic"""
    return {
        "name": mcp_tool.name,
        "description": mcp_tool.description,
        "input_schema": mcp_tool.inputSchema
    }

# Использование
async with ClientSession(read, write) as mcp_session:
    await mcp_session.initialize()
    
    tools_result = await mcp_session.list_tools()
    anthropic_tools = [
        mcp_tool_to_anthropic(tool) 
        for tool in tools_result.tools
    ]
```

## OpenAI API

### Настройка

```bash
pip install openai mcp
```

```python
from openai import OpenAI

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
```

### Function calling с OpenAI

GPT-4 и GPT-3.5-turbo поддерживают function calling:

```python
# Определение функций в формате OpenAI
functions = [
    {
        "name": "get_weather",
        "description": "Получает текущую погоду для указанного города",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {
                    "type": "string",
                    "description": "Название города"
                },
                "units": {
                    "type": "string",
                    "enum": ["celsius", "fahrenheit"],
                    "description": "Единицы измерения"
                }
            },
            "required": ["city"]
        }
    }
]

# Запрос к GPT
response = client.chat.completions.create(
    model="gpt-4-turbo",
    messages=[
        {"role": "user", "content": "Какая погода в Москве?"}
    ],
    functions=functions,
    function_call="auto"
)
```

### Обработка function_call

```python
message = response.choices[0].message

if message.function_call:
    function_name = message.function_call.name
    function_args = json.loads(message.function_call.arguments)
    
    # Выполняем функцию
    result = execute_function(function_name, function_args)
    
    # Продолжаем диалог
    response = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "user", "content": "Какая погода в Москве?"},
            message,
            {
                "role": "function",
                "name": function_name,
                "content": str(result)
            }
        ],
        functions=functions
    )
```

### Преобразование MCP → OpenAI

```python
def mcp_tool_to_openai(mcp_tool):
    """Конвертирует MCP Tool в формат OpenAI"""
    return {
        "name": mcp_tool.name,
        "description": mcp_tool.description,
        "parameters": mcp_tool.inputSchema
    }

# Использование
async with ClientSession(read, write) as mcp_session:
    await mcp_session.initialize()
    
    tools_result = await mcp_session.list_tools()
    openai_functions = [
        mcp_tool_to_openai(tool) 
        for tool in tools_result.tools
    ]
```

## Полная интеграция с Anthropic

Пример полной интеграции MCP-сервера с Claude:

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from anthropic import Anthropic
import json


class MCPAnthropicIntegration:
    def __init__(self, anthropic_api_key: str):
        self.anthropic_client = Anthropic(api_key=anthropic_api_key)
        self.mcp_session = None
        self.tools = []
    
    async def connect_to_mcp_server(self, server_params: StdioServerParameters):
        """Подключение к MCP-серверу"""
        self.stdio_context = stdio_client(server_params)
        read, write = await self.stdio_context.__aenter__()
        
        self.session_context = ClientSession(read, write)
        self.mcp_session = await self.session_context.__aenter__()
        
        # Инициализация
        await self.mcp_session.initialize()
        
        # Получение инструментов
        tools_result = await self.mcp_session.list_tools()
        self.tools = [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.inputSchema
            }
            for tool in tools_result.tools
        ]
        
        print(f"✅ Подключено к MCP-серверу, доступно {len(self.tools)} инструментов")
    
    async def execute_tool(self, name: str, arguments: dict) -> str:
        """Выполнение инструмента через MCP"""
        result = await self.mcp_session.call_tool(name, arguments)
        
        # Извлекаем текст из результата
        for content in result.content:
            if hasattr(content, 'text'):
                return content.text
        
        return str(result)
    
    async def chat(self, user_message: str, max_iterations: int = 5):
        """Диалог с Claude с поддержкой инструментов"""
        messages = [{"role": "user", "content": user_message}]
        
        print(f"👤 Пользователь: {user_message}\\n")
        
        for iteration in range(max_iterations):
            # Запрос к Claude
            response = self.anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=2048,
                tools=self.tools,
                messages=messages
            )
            
            # Обработка ответа
            if response.stop_reason == "tool_use":
                # Собираем результаты вызовов инструментов
                tool_results = []
                
                for content_block in response.content:
                    if content_block.type == "text":
                        print(f"🤖 Claude: {content_block.text}")
                    
                    elif content_block.type == "tool_use":
                        print(f"🔧 Вызов: {content_block.name}")
                        print(f"   Аргументы: {json.dumps(content_block.input, ensure_ascii=False)}")
                        
                        # Выполняем инструмент
                        result = await self.execute_tool(
                            content_block.name,
                            content_block.input
                        )
                        
                        print(f"   Результат: {result}\\n")
                        
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": content_block.id,
                            "content": result
                        })
                
                # Добавляем в историю
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": tool_results})
                
            elif response.stop_reason == "end_turn":
                # Финальный ответ
                for content_block in response.content:
                    if content_block.type == "text":
                        print(f"🤖 Claude: {content_block.text}\\n")
                break
            
            else:
                print(f"⚠️  Неожиданный stop_reason: {response.stop_reason}")
                break
    
    async def close(self):
        """Закрытие соединений"""
        if self.mcp_session:
            await self.session_context.__aexit__(None, None, None)
            await self.stdio_context.__aexit__(None, None, None)


async def main():
    # Создаем интеграцию
    integration = MCPAnthropicIntegration(
        anthropic_api_key=os.environ.get("ANTHROPIC_API_KEY")
    )
    
    # Подключаемся к MCP-серверу
    server_params = StdioServerParameters(
        command="python",
        args=["my_server.py"]
    )
    
    await integration.connect_to_mcp_server(server_params)
    
    # Ведем диалог
    await integration.chat(
        "Переведи текст 'Hello World' в верхний регистр и затем посчитай сколько в нем символов"
    )
    
    # Закрываем
    await integration.close()


if __name__ == "__main__":
    asyncio.run(main())
```

## Работа с моделями без function calling

Для моделей, которые не поддерживают нативный function calling, можно использовать prompt engineering:

### ReAct паттерн

```python
def create_tools_prompt(tools):
    """Создает промпт с описанием инструментов"""
    tools_desc = []
    for tool in tools:
        tools_desc.append(f"- {tool['name']}: {tool['description']}")
    
    return f\"\"\"
У тебя есть доступ к следующим инструментам:

{chr(10).join(tools_desc)}

Для вызова инструмента используй формат:
ACTION: название_инструмента
INPUT: {{"параметр": "значение"}}

После получения результата продолжи рассуждения.
\"\"\"

# Использование
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": create_tools_prompt(tools)},
        {"role": "user", "content": "Какая погода в Москве?"}
    ]
)

# Парсинг ответа
if "ACTION:" in response.choices[0].message.content:
    # Извлекаем вызов инструмента и выполняем
    ...
```

## Стриминг ответов

### Anthropic streaming

```python
with client.messages.stream(
    model="claude-3-5-sonnet-20241022",
    max_tokens=1024,
    tools=tools,
    messages=messages
) as stream:
    for text in stream.text_stream:
        print(text, end="", flush=True)
    
    # Получаем финальный ответ с tool_use
    final_message = stream.get_final_message()
```

### OpenAI streaming

```python
stream = client.chat.completions.create(
    model="gpt-4-turbo",
    messages=messages,
    functions=functions,
    stream=True
)

for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

## Обработка ошибок

### Retry логика для API

```python
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10)
)
async def call_llm_with_retry(client, **kwargs):
    """Вызов LLM с автоматическим retry"""
    try:
        return client.messages.create(**kwargs)
    except Exception as e:
        print(f"⚠️  Ошибка API: {e}, повтор...")
        raise
```

### Обработка лимитов токенов

```python
def truncate_messages(messages, max_tokens=4000):
    """Обрезает историю сообщений до лимита токенов"""
    # Простая эвристика: 1 токен ≈ 4 символа
    total_chars = sum(len(str(m)) for m in messages)
    
    if total_chars > max_tokens * 4:
        # Оставляем системное сообщение и последние N сообщений
        return [messages[0]] + messages[-(max_tokens // 100):]
    
    return messages
```

## Best Practices

### 1. Кэширование вызовов LLM

```python
import functools
import hashlib
import json

@functools.lru_cache(maxsize=100)
def cached_llm_call(prompt_hash: str):
    # Кэшируется автоматически
    pass

def call_with_cache(prompt: str, **kwargs):
    # Создаем хэш от промпта и параметров
    prompt_hash = hashlib.md5(
        (prompt + json.dumps(kwargs, sort_keys=True)).encode()
    ).hexdigest()
    
    return cached_llm_call(prompt_hash)
```

### 2. Мониторинг использования токенов

```python
class TokenUsageTracker:
    def __init__(self):
        self.total_input_tokens = 0
        self.total_output_tokens = 0
    
    def track(self, response):
        usage = response.usage
        self.total_input_tokens += usage.input_tokens
        self.total_output_tokens += usage.output_tokens
        
        print(f"Использовано токенов: {usage.input_tokens} + {usage.output_tokens}")
        print(f"Всего: {self.total_input_tokens} + {self.total_output_tokens}")

tracker = TokenUsageTracker()
response = client.messages.create(...)
tracker.track(response)
```

### 3. Timeout для вызовов

```python
import asyncio

async def call_with_timeout(client, timeout=30, **kwargs):
    """Вызов LLM с таймаутом"""
    try:
        async with asyncio.timeout(timeout):
            return await asyncio.to_thread(
                client.messages.create,
                **kwargs
            )
    except asyncio.TimeoutError:
        print(f"❌ Таймаут {timeout}s превышен")
        raise
```

## Заключение

Интеграция MCP с LLM API открывает мощные возможности для создания AI-приложений с расширенными capabilities. Правильное преобразование инструментов и обработка tool calling являются ключом к успешной интеграции.

В следующем модуле мы применим все полученные знания для создания комплексных практических проектов.

## Контрольные вопросы

1. В чем разница между tool calling в Anthropic и function calling в OpenAI?
2. Как преобразовать MCP Tool в формат Anthropic?
3. Как обработать tool_use response от Claude?
4. Что такое ReAct паттерн и когда его использовать?
5. Какие best practices важны при работе с LLM API?

## Практические задания

1. Создайте интеграцию MCP-сервера с Anthropic Claude
2. Реализуйте поддержку OpenAI function calling
3. Добавьте кэширование вызовов LLM
4. Реализуйте мониторинг использования токенов
"""

with open("mcp_course/modules/module_06_llm_integration/lecture.md", "w", encoding="utf-8") as f:
    f.write(module6_lecture)

print("✅ Модуль 6 - лекция создана")
