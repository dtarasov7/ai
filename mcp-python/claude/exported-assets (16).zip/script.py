
# Продолжаю создание материалов курса
# Теперь создам Module 7, диаграммы, примеры кода и лабораторные работы

print("=== Создание Module 7: Практика ===")
print("Включает полную интеграцию всех компонентов\n")

print("=== Следующие компоненты для создания: ===")
components = [
    "Module 07 - Практика (лекция)",
    "Диаграммы PlantUML (architecture, message_flow, transport, mindmap)",
    "Примеры кода (stdio/http client/server, async tools, progress)",
    "Системные промпты (non-finetuned, structured output)",
    "Лабораторные работы 1-6 с пошаговыми инструкциями",
    "Утилиты (logger, helpers)"
]

for i, comp in enumerate(components, 1):
    print(f"{i}. {comp}")
