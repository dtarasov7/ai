
# Создам структуру файлов для остальных модулей курса
# Это поможет организовать контент

modules_content = {
    "module05": "LLM Host взаимодействие",
    "module06": "Интеграция с моделями",
    "module07": "Практика"
}

examples_files = [
    "simple_client_stdio.py",
    "simple_client_http.py", 
    "async_tools_example.py",
    "progress_notifications.py"
]

labs = [
    "lab01_basic_server",
    "lab02_resources_prompts",
    "lab03_async_tools",
    "lab04_http_transport",
    "lab05_progress",
    "lab06_full_integration"
]

print("Структура курса:")
print("\nОставшиеся модули:")
for mod, desc in modules_content.items():
    print(f"  - {mod}: {desc}")
    
print("\nПримеры кода для создания:")
for ex in examples_files:
    print(f"  - {ex}")
    
print("\nЛабораторные работы:")
for lab in labs:
    print(f"  - {lab}")
