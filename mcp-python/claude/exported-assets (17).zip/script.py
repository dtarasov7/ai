
# Продолжаю создание примеров кода и лабораторных работ

print("=== Создание примеров кода ===\n")

examples = [
    "simple_server_stdio.py - базовый stdio сервер",
    "simple_server_http.py - базовый HTTP/SSE сервер", 
    "simple_client_stdio.py - stdio клиент",
    "simple_client_http.py - HTTP/SSE клиент",
    "async_tools_example.py - асинхронные инструменты с httpx",
    "progress_notifications.py - progress notifications"
]

for ex in examples:
    print(f"  📝 {ex}")

print("\n=== Создание системных промптов ===\n")
prompts = [
    "non_finetuned_tool_usage.txt",
    "structured_output.txt"
]

for p in prompts:
    print(f"  📄 {p}")

print("\n=== Создание лабораторных работ ===\n")
labs = [
    "Lab 01: Базовый MCP-сервер",
    "Lab 02: Resources и Prompts", 
    "Lab 03: Асинхронные инструменты",
    "Lab 04: HTTP-транспорт",
    "Lab 05: Progress notifications",
    "Lab 06: Полная интеграция с LLM"
]

for lab in labs:
    print(f"  🧪 {lab}")
