
# Создам лекцию для модуля 3 - MCP SDK на Python
module3_lecture = """# Модуль 3: MCP SDK на Python

## Введение в MCP Python SDK

MCP Python SDK — это официальная библиотека для разработки MCP-серверов и клиентов на Python. SDK предоставляет удобные абстракции для работы с протоколом и упрощает создание интеграций.

### Установка

```bash
# Используя pip
pip install mcp

# Используя uv (рекомендуется)
uv pip install mcp
```

### Основные компоненты SDK

1. **Server**: Класс для создания MCP-серверов
2. **ClientSession**: Класс для создания MCP-клиентов
3. **Transport**: Транспортные механизмы (stdio, HTTP)
4. **Types**: Типы данных для работы с протоколом

## Архитектура SDK

### Серверная сторона

```
┌─────────────────────────────────────┐
│         MCP Server                   │
├─────────────────────────────────────┤
│  - Регистрация handlers              │
│  - Управление capabilities           │
│  - Обработка запросов                │
└─────────────────────────────────────┘
           │
           ├── Tools Handler
           ├── Resources Handler
           ├── Prompts Handler
           └── Logging Handler
```

### Клиентская сторона

```
┌─────────────────────────────────────┐
│       ClientSession                  │
├─────────────────────────────────────┤
│  - Установка соединения              │
│  - Отправка запросов                 │
│  - Получение ответов                 │
└─────────────────────────────────────┘
           │
           └── Transport (stdio/HTTP)
```

## Создание базового MCP-сервера

### Минимальный пример

Простейший MCP-сервер с одним инструментом:

```python
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import asyncio

# Создаем экземпляр сервера
app = Server("my-first-server")

# Регистрируем handler для списка инструментов
@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="echo",
            description="Повторяет переданный текст",
            inputSchema={
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "Текст для повтора"
                    }
                },
                "required": ["message"]
            }
        )
    ]

# Регистрируем handler для вызова инструментов
@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "echo":
        message = arguments["message"]
        return [TextContent(type="text", text=f"Эхо: {message}")]
    raise ValueError(f"Неизвестный инструмент: {name}")

# Запуск сервера
async def main():
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())

if __name__ == "__main__":
    asyncio.run(main())
```

### Ключевые концепции

**Декораторы**:
- `@app.list_tools()`: Регистрирует handler для tools/list
- `@app.call_tool()`: Регистрирует handler для tools/call
- `@app.list_resources()`: Регистрирует handler для resources/list
- `@app.read_resource()`: Регистрирует handler для resources/read
- `@app.list_prompts()`: Регистрирует handler для prompts/list
- `@app.get_prompt()`: Регистрирует handler для prompts/get

**Асинхронность**:
- Все handlers должны быть async функциями
- SDK построен на asyncio для эффективной обработки I/O

**Типизация**:
- SDK использует Pydantic для валидации данных
- Строгая типизация помогает избежать ошибок

## Работа с Tools (Инструментами)

### Регистрация инструментов

Инструменты описываются с помощью JSON Schema:

```python
from mcp.types import Tool

@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="calculate",
            description="Выполняет математические вычисления",
            inputSchema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["add", "subtract", "multiply", "divide"],
                        "description": "Тип операции"
                    },
                    "a": {
                        "type": "number",
                        "description": "Первое число"
                    },
                    "b": {
                        "type": "number",
                        "description": "Второе число"
                    }
                },
                "required": ["operation", "a", "b"]
            }
        )
    ]
```

### Реализация инструментов

```python
from mcp.types import TextContent

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "calculate":
        operation = arguments["operation"]
        a = arguments["a"]
        b = arguments["b"]
        
        if operation == "add":
            result = a + b
        elif operation == "subtract":
            result = a - b
        elif operation == "multiply":
            result = a * b
        elif operation == "divide":
            if b == 0:
                return [TextContent(
                    type="text",
                    text="Ошибка: деление на ноль"
                )]
            result = a / b
        
        return [TextContent(
            type="text",
            text=f"Результат: {result}"
        )]
    
    raise ValueError(f"Неизвестный инструмент: {name}")
```

### Типы возвращаемого контента

Инструменты могут возвращать разные типы контента:

```python
from mcp.types import TextContent, ImageContent, EmbeddedResource

# Текстовый контент
TextContent(type="text", text="Результат операции")

# Изображение (base64)
ImageContent(
    type="image",
    data="base64_encoded_image_data",
    mimeType="image/png"
)

# Встроенный ресурс
EmbeddedResource(
    type="resource",
    resource={
        "uri": "file:///path/to/file.txt",
        "mimeType": "text/plain",
        "text": "Содержимое файла"
    }
)
```

## Работа с Resources (Ресурсами)

### Регистрация ресурсов

Ресурсы предоставляют данные для LLM:

```python
from mcp.types import Resource

@app.list_resources()
async def list_resources() -> list[Resource]:
    return [
        Resource(
            uri="config://settings",
            name="Application Settings",
            description="Текущие настройки приложения",
            mimeType="application/json"
        ),
        Resource(
            uri="file:///var/log/app.log",
            name="Application Log",
            description="Лог-файл приложения",
            mimeType="text/plain"
        )
    ]
```

### Чтение ресурсов

```python
from mcp.types import TextContent, BlobContent

@app.read_resource()
async def read_resource(uri: str) -> str | bytes:
    if uri == "config://settings":
        import json
        settings = {
            "debug": True,
            "port": 8080,
            "host": "localhost"
        }
        return json.dumps(settings, indent=2)
    
    elif uri.startswith("file://"):
        # Извлекаем путь из URI
        file_path = uri[7:]  # Убираем "file://"
        
        # Читаем файл
        with open(file_path, "r") as f:
            return f.read()
    
    raise ValueError(f"Неизвестный ресурс: {uri}")
```

### Подписки на изменения ресурсов

```python
@app.subscribe_resource()
async def subscribe_resource(uri: str):
    # Логика подписки на изменения ресурса
    # Сервер должен отправлять уведомления при изменениях
    print(f"Подписка на ресурс: {uri}")

@app.unsubscribe_resource()
async def unsubscribe_resource(uri: str):
    # Логика отписки от ресурса
    print(f"Отписка от ресурса: {uri}")
```

## Работа с Prompts (Промптами)

### Регистрация промптов

Промпты предоставляют шаблоны для пользователей:

```python
from mcp.types import Prompt, PromptArgument

@app.list_prompts()
async def list_prompts() -> list[Prompt]:
    return [
        Prompt(
            name="code_review",
            description="Запрос на ревью кода",
            arguments=[
                PromptArgument(
                    name="language",
                    description="Язык программирования",
                    required=True
                ),
                PromptArgument(
                    name="code",
                    description="Код для ревью",
                    required=True
                )
            ]
        ),
        Prompt(
            name="explain_error",
            description="Объяснение ошибки",
            arguments=[
                PromptArgument(
                    name="error_message",
                    description="Текст ошибки",
                    required=True
                )
            ]
        )
    ]
```

### Генерация промптов

```python
from mcp.types import PromptMessage, TextContent

@app.get_prompt()
async def get_prompt(name: str, arguments: dict) -> list[PromptMessage]:
    if name == "code_review":
        language = arguments["language"]
        code = arguments["code"]
        
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Пожалуйста, проведи ревью следующего кода на {language}:

```{language}
{code}
```

Обрати внимание на:
1. Правильность реализации
2. Потенциальные баги
3. Производительность
4. Читаемость и стиль
5. Безопасность

Предложи улучшения где необходимо."""
                )
            )
        ]
    
    elif name == "explain_error":
        error_message = arguments["error_message"]
        
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Объясни следующую ошибку простым языком:

```
{error_message}
```

Укажи:
1. Что означает эта ошибка
2. Возможные причины
3. Как исправить
4. Как предотвратить в будущем"""
                )
            )
        ]
    
    raise ValueError(f"Неизвестный промпт: {name}")
```

## Создание MCP-клиента

### Базовый клиент

```python
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import asyncio

async def main():
    # Параметры для запуска сервера
    server_params = StdioServerParameters(
        command="python",
        args=["my_server.py"]
    )
    
    # Подключаемся к серверу
    async with stdio_client(server_params) as (read, write):
        # Создаем сессию
        async with ClientSession(read, write) as session:
            # Инициализация
            await session.initialize()
            
            # Получаем список инструментов
            tools = await session.list_tools()
            print("Доступные инструменты:", tools)
            
            # Вызываем инструмент
            result = await session.call_tool(
                "echo",
                arguments={"message": "Hello, MCP!"}
            )
            print("Результат:", result)

if __name__ == "__main__":
    asyncio.run(main())
```

### Работа с ресурсами из клиента

```python
async with ClientSession(read, write) as session:
    await session.initialize()
    
    # Получаем список ресурсов
    resources = await session.list_resources()
    
    # Читаем конкретный ресурс
    content = await session.read_resource("config://settings")
    print("Содержимое ресурса:", content)
    
    # Подписываемся на изменения
    await session.subscribe_resource("file:///var/log/app.log")
```

### Работа с промптами из клиента

```python
async with ClientSession(read, write) as session:
    await session.initialize()
    
    # Получаем список промптов
    prompts = await session.list_prompts()
    
    # Получаем конкретный промпт
    messages = await session.get_prompt(
        "code_review",
        arguments={
            "language": "python",
            "code": "def add(a, b):\\n    return a + b"
        }
    )
    
    # messages содержит готовый промпт для LLM
    for message in messages:
        print(f"{message.role}: {message.content.text}")
```

## Логирование и отладка

### Настройка логирования на сервере

```python
import logging
from mcp.server import Server

# Настройка стандартного логгера Python
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

app = Server("my-server")

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    # Логирование внутри handler
    logging.info(f"Вызван инструмент: {name}")
    logging.debug(f"Аргументы: {arguments}")
    
    try:
        # Выполнение операции
        result = perform_operation(name, arguments)
        logging.info(f"Операция завершена успешно")
        return result
    except Exception as e:
        logging.error(f"Ошибка при выполнении: {e}")
        raise
```

### Отправка логов клиенту

```python
from mcp.server.stdio import stdio_server

async def main():
    async with stdio_server() as (read, write):
        # SDK автоматически перенаправляет stderr логи клиенту
        await app.run(read, write, app.create_initialization_options())
```

## Обработка ошибок

### На стороне сервера

```python
from mcp.types import TextContent

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        # Валидация аргументов
        if name == "divide":
            if arguments.get("b") == 0:
                raise ValueError("Деление на ноль невозможно")
        
        # Выполнение операции
        result = execute_tool(name, arguments)
        
        return [TextContent(type="text", text=str(result))]
        
    except ValueError as e:
        # Валидационные ошибки
        return [TextContent(
            type="text",
            text=f"Ошибка валидации: {str(e)}"
        )]
        
    except Exception as e:
        # Неожиданные ошибки
        logging.error(f"Неожиданная ошибка: {e}", exc_info=True)
        raise  # Пробрасываем дальше, SDK обработает как JSON-RPC error
```

### На стороне клиента

```python
from mcp.types import McpError

async def call_tool_safely(session, name: str, arguments: dict):
    try:
        result = await session.call_tool(name, arguments)
        return result
        
    except McpError as e:
        # Ошибка протокола MCP
        print(f"MCP ошибка: {e.code} - {e.message}")
        return None
        
    except Exception as e:
        # Другие ошибки
        print(f"Неожиданная ошибка: {e}")
        return None
```

## Best Practices

### Именование

1. **Серверы**: Используйте kebab-case, например `file-system-server`
2. **Инструменты**: Используйте snake_case, например `read_file`
3. **Ресурсы**: Используйте URI схемы, например `file://`, `config://`

### Описания

1. **Инструменты**: Пишите четкие описания того, что делает инструмент
2. **Параметры**: Документируйте каждый параметр в JSON Schema
3. **Ресурсы**: Указывайте правильный MIME-тип

### Производительность

1. **Асинхронность**: Используйте `async/await` для I/O операций
2. **Кэширование**: Кэшируйте медленные операции
3. **Batch операции**: Группируйте запросы где возможно

### Безопасность

1. **Валидация**: Всегда валидируйте входные данные
2. **Sandboxing**: Изолируйте выполнение опасных операций
3. **Ограничения**: Устанавливайте лимиты на размер данных и время выполнения

## Примеры из реальной практики

### Сервер для работы с файлами

```python
import os
from pathlib import Path
from mcp.server import Server
from mcp.types import Tool, Resource, TextContent

app = Server("file-system-server")

# Корневая директория (безопасность)
ROOT_DIR = Path("/allowed/directory")

@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_files",
            description="Список файлов в директории",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string"}
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="read_file",
            description="Чтение содержимого файла",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string"}
                },
                "required": ["path"]
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "list_files":
        path = ROOT_DIR / arguments["path"]
        
        # Проверка безопасности
        if not path.resolve().is_relative_to(ROOT_DIR):
            raise ValueError("Доступ запрещен")
        
        files = [f.name for f in path.iterdir()]
        return [TextContent(
            type="text",
            text="\\n".join(files)
        )]
    
    elif name == "read_file":
        path = ROOT_DIR / arguments["path"]
        
        if not path.resolve().is_relative_to(ROOT_DIR):
            raise ValueError("Доступ запрещен")
        
        content = path.read_text()
        return [TextContent(type="text", text=content)]
```

## Заключение

MCP Python SDK предоставляет мощный и удобный способ создания интеграций для LLM-приложений. В следующем модуле мы рассмотрим инструменты отладки и мониторинга MCP-серверов.

## Контрольные вопросы

1. Какие основные компоненты входят в MCP Python SDK?
2. Как зарегистрировать handler для инструмента?
3. В чем разница между Tools, Resources и Prompts?
4. Как обрабатывать ошибки в MCP-сервере?
5. Какие best practices следует соблюдать при разработке?

## Практические задания

1. Создайте MCP-сервер с тремя математическими инструментами
2. Реализуйте клиента, который вызывает все инструменты
3. Добавьте логирование и обработку ошибок
"""

with open("mcp_course/modules/module_03_python_sdk/lecture.md", "w", encoding="utf-8") as f:
    f.write(module3_lecture)

print("✅ Модуль 3 - лекция создана")
