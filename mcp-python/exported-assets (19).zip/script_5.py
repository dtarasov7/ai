
# Создам все примеры кода для модуля 3

# 01_basic_server.py
basic_server = '''"""
Базовый MCP-сервер на Python

Этот пример демонстрирует минимальную реализацию MCP-сервера,
который предоставляет один простой инструмент для сложения чисел.
"""

import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Создаем экземпляр MCP-сервера
# name: имя сервера, которое будет отображаться клиентам
# version: версия сервера для отслеживания совместимости
app = Server("basic-calculator")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """
    Обработчик для запроса списка доступных инструментов.
    
    Этот метод вызывается когда клиент отправляет tools/list запрос.
    Возвращает список объектов Tool с описанием каждого инструмента.
    
    Returns:
        list[Tool]: Список доступных инструментов
    """
    return [
        Tool(
            # Уникальное имя инструмента
            name="add",
            # Описание для LLM - должно быть четким и информативным
            description="Складывает два числа и возвращает результат",
            # JSON Schema для валидации входных параметров
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {
                        "type": "number",
                        "description": "Первое число"
                    },
                    "b": {
                        "type": "number",
                        "description": "Второе число"
                    }
                },
                # Обязательные параметры
                "required": ["a", "b"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """
    Обработчик для вызова инструмента.
    
    Этот метод вызывается когда клиент отправляет tools/call запрос.
    Выполняет запрошенный инструмент с переданными аргументами.
    
    Args:
        name: Имя вызываемого инструмента
        arguments: Словарь с аргументами инструмента
        
    Returns:
        list[TextContent]: Результат выполнения инструмента
        
    Raises:
        ValueError: Если инструмент не найден
    """
    if name == "add":
        # Извлекаем аргументы из словаря
        a = arguments["a"]
        b = arguments["b"]
        
        # Выполняем вычисление
        result = a + b
        
        # Возвращаем результат в виде текстового контента
        # TextContent - стандартный способ возврата текста в MCP
        return [
            TextContent(
                type="text",
                text=f"Результат: {a} + {b} = {result}"
            )
        ]
    else:
        # Если инструмент не найден, выбрасываем ошибку
        raise ValueError(f"Неизвестный инструмент: {name}")


async def main():
    """
    Главная функция для запуска сервера.
    
    Использует stdio transport для коммуникации через стандартные потоки.
    Это подходит для локальных серверов, запускаемых как дочерние процессы.
    """
    # Создаем stdio server и передаем ему наше приложение
    # stdio_server читает из stdin и пишет в stdout
    async with stdio_server() as (read_stream, write_stream):
        # Запускаем сервер и обрабатываем запросы
        await app.run(
            read_stream,
            write_stream,
            # Опции инициализации
            app.create_initialization_options()
        )


# Точка входа
if __name__ == "__main__":
    # Запускаем асинхронную главную функцию
    asyncio.run(main())
'''

# 02_basic_client.py
basic_client = '''"""
Базовый MCP-клиент на Python

Этот пример демонстрирует как подключиться к MCP-серверу,
получить список инструментов и вызвать инструмент.
"""

import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    """
    Главная функция клиента.
    
    Подключается к серверу, получает список инструментов и вызывает add.
    """
    
    # Определяем параметры для запуска сервера
    # command: команда для запуска (python, node, и т.д.)
    # args: аргументы командной строки (путь к серверу)
    # env: переменные окружения (опционально)
    server_params = StdioServerParameters(
        command="python",
        args=["01_basic_server.py"],
        env=None
    )
    
    # Подключаемся к серверу через stdio transport
    # stdio_client создает дочерний процесс и управляет коммуникацией
    async with stdio_client(server_params) as (read, write):
        # Создаем клиентскую сессию
        # ClientSession управляет протокольным взаимодействием
        async with ClientSession(read, write) as session:
            
            # Инициализируем соединение
            # Обмениваемся capabilities и версией протокола
            await session.initialize()
            
            print("=" * 50)
            print("Подключение к MCP-серверу установлено")
            print("=" * 50)
            
            # Получаем список доступных инструментов
            # Отправляет tools/list запрос
            tools_result = await session.list_tools()
            
            print("\\nДоступные инструменты:")
            for tool in tools_result.tools:
                print(f"  - {tool.name}: {tool.description}")
            
            # Вызываем инструмент add
            # Отправляет tools/call запрос с параметрами
            print("\\nВызов инструмента 'add' с аргументами a=15, b=27...")
            result = await session.call_tool(
                "add",
                arguments={"a": 15, "b": 27}
            )
            
            # Выводим результат
            print("\\nРезультат:")
            for content in result.content:
                # Проверяем тип контента
                if hasattr(content, 'text'):
                    print(f"  {content.text}")
            
            print("\\n" + "=" * 50)
            print("Работа завершена")
            print("=" * 50)


# Точка входа
if __name__ == "__main__":
    # Запускаем асинхронную главную функцию
    asyncio.run(main())
'''

# Сохраняю файлы
with open("mcp_course/modules/module_03_python_sdk/examples/01_basic_server.py", "w", encoding="utf-8") as f:
    f.write(basic_server)

with open("mcp_course/modules/module_03_python_sdk/examples/02_basic_client.py", "w", encoding="utf-8") as f:
    f.write(basic_client)

print("✅ Базовые примеры созданы:")
print("  - 01_basic_server.py")
print("  - 02_basic_client.py")
