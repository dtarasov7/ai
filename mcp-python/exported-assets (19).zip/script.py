
import os

# Проверяю существующую структуру
if os.path.exists("mcp_course"):
    print("✅ Найдена существующая структура курса")
    print("Продолжаю с модуля 2...")
else:
    print("⚠️ Структура не найдена, создаю заново...")
    # Создаем структуру директорий
    directories = [
        "mcp_course",
        "mcp_course/modules",
        "mcp_course/modules/module_01_introduction",
        "mcp_course/modules/module_02_protocol",
        "mcp_course/modules/module_03_python_sdk",
        "mcp_course/modules/module_03_python_sdk/examples",
        "mcp_course/modules/module_04_debugging",
        "mcp_course/modules/module_04_debugging/examples",
        "mcp_course/modules/module_05_llm_host",
        "mcp_course/modules/module_05_llm_host/examples",
        "mcp_course/modules/module_06_llm_integration",
        "mcp_course/modules/module_06_llm_integration/examples",
        "mcp_course/modules/module_07_practice",
        "mcp_course/labs",
        "mcp_course/labs/lab_01_first_server",
        "mcp_course/labs/lab_01_first_server/solution",
        "mcp_course/labs/lab_02_weather_service",
        "mcp_course/labs/lab_02_weather_service/solution",
        "mcp_course/labs/lab_03_file_manager",
        "mcp_course/labs/lab_03_file_manager/solution",
        "mcp_course/labs/lab_04_database_connector",
        "mcp_course/labs/lab_04_database_connector/solution",
        "mcp_course/labs/lab_05_full_application",
        "mcp_course/labs/lab_05_full_application/solution",
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    
    print(f"✅ Создано {len(directories)} директорий")
