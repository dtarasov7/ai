
# Создам продвинутые примеры серверов

# 03_server_with_tools.py  
server_with_tools = '''"""
MCP-сервер с несколькими инструментами

Демонстрирует создание сервера с множеством инструментов
разных типов: математические операции, строковые операции, утилиты.
"""

import asyncio
import json
from datetime import datetime
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Создаем сервер
app = Server("multi-tool-server")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """
    Регистрируем несколько инструментов разных категорий.
    """
    return [
        # Математические операции
        Tool(
            name="calculate",
            description="Выполняет математические операции: сложение, вычитание, умножение, деление",
            inputSchema={
                "type": "object",
                "properties": {
                    "operation": {
                        "type": "string",
                        "enum": ["add", "subtract", "multiply", "divide"],
                        "description": "Тип математической операции"
                    },
                    "a": {
                        "type": "number",
                        "description": "Первое число"
                    },
                    "b": {
                        "type": "number",
                        "description": "Второе число"
                    }
                },
                "required": ["operation", "a", "b"]
            }
        ),
        
        # Строковые операции
        Tool(
            name="text_transform",
            description="Преобразует текст: верхний/нижний регистр, переворачивает",
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Текст для преобразования"
                    },
                    "transform": {
                        "type": "string",
                        "enum": ["uppercase", "lowercase", "reverse", "capitalize"],
                        "description": "Тип преобразования"
                    }
                },
                "required": ["text", "transform"]
            }
        ),
        
        # Утилиты
        Tool(
            name="get_timestamp",
            description="Возвращает текущую дату и время в различных форматах",
            inputSchema={
                "type": "object",
                "properties": {
                    "format": {
                        "type": "string",
                        "enum": ["iso", "unix", "readable"],
                        "description": "Формат вывода времени",
                        "default": "iso"
                    }
                }
            }
        ),
        
        # JSON операции
        Tool(
            name="json_format",
            description="Форматирует JSON строку с отступами",
            inputSchema={
                "type": "object",
                "properties": {
                    "json_string": {
                        "type": "string",
                        "description": "JSON строка для форматирования"
                    },
                    "indent": {
                        "type": "number",
                        "description": "Количество пробелов для отступа",
                        "default": 2
                    }
                },
                "required": ["json_string"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """
    Обработчик вызовов инструментов с логикой для каждого типа.
    """
    
    # Математический калькулятор
    if name == "calculate":
        operation = arguments["operation"]
        a = arguments["a"]
        b = arguments["b"]
        
        # Выполняем операцию
        if operation == "add":
            result = a + b
            op_symbol = "+"
        elif operation == "subtract":
            result = a - b
            op_symbol = "-"
        elif operation == "multiply":
            result = a * b
            op_symbol = "*"
        elif operation == "divide":
            # Проверка деления на ноль
            if b == 0:
                return [TextContent(
                    type="text",
                    text="Ошибка: деление на ноль невозможно"
                )]
            result = a / b
            op_symbol = "/"
        
        return [TextContent(
            type="text",
            text=f"Результат: {a} {op_symbol} {b} = {result}"
        )]
    
    # Преобразование текста
    elif name == "text_transform":
        text = arguments["text"]
        transform = arguments["transform"]
        
        if transform == "uppercase":
            result = text.upper()
        elif transform == "lowercase":
            result = text.lower()
        elif transform == "reverse":
            result = text[::-1]
        elif transform == "capitalize":
            result = text.capitalize()
        
        return [TextContent(
            type="text",
            text=f"Преобразование '{transform}': {result}"
        )]
    
    # Получение временной метки
    elif name == "get_timestamp":
        format_type = arguments.get("format", "iso")
        now = datetime.now()
        
        if format_type == "iso":
            result = now.isoformat()
        elif format_type == "unix":
            result = str(int(now.timestamp()))
        elif format_type == "readable":
            result = now.strftime("%Y-%m-%d %H:%M:%S")
        
        return [TextContent(
            type="text",
            text=f"Текущее время ({format_type}): {result}"
        )]
    
    # Форматирование JSON
    elif name == "json_format":
        json_string = arguments["json_string"]
        indent = arguments.get("indent", 2)
        
        try:
            # Парсим JSON
            data = json.loads(json_string)
            # Форматируем с отступами
            formatted = json.dumps(data, indent=indent, ensure_ascii=False)
            
            return [TextContent(
                type="text",
                text=f"Отформатированный JSON:\\n{formatted}"
            )]
        except json.JSONDecodeError as e:
            return [TextContent(
                type="text",
                text=f"Ошибка парсинга JSON: {str(e)}"
            )]
    
    # Неизвестный инструмент
    else:
        raise ValueError(f"Неизвестный инструмент: {name}")


async def main():
    """Запуск сервера через stdio transport"""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
'''

with open("mcp_course/modules/module_03_python_sdk/examples/03_server_with_tools.py", "w", encoding="utf-8") as f:
    f.write(server_with_tools)

print("✅ 03_server_with_tools.py создан")
