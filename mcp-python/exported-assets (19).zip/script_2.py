
# Создам все диаграммы для модуля 2

# Mindmap для модуля 2
module2_mindmap = """@startmindmap
* MCP Protocol

** Transport Layer
*** stdio
**** Локальная коммуникация
**** stdin/stdout/stderr
**** Высокая производительность
**** Без сетевых накладных расходов
*** HTTP/SSE
**** Удаленная коммуникация
**** HTTP POST запросы
**** Server-Sent Events
**** OAuth/Bearer tokens
**** API keys

** Message Types
*** Request
**** Требует ответа
**** id + method + params
**** tools/call, resources/read
*** Response
**** Успешный результат
**** id + result
*** Error
**** Код ошибки
**** Сообщение
**** code + message + data
*** Notification
**** Без ответа
**** Без id
**** logging, progress

left side

** Client Capabilities
*** Roots
**** Корневые директории
**** Границы доступа
*** Sampling
**** Запросы к LLM
**** Агентское поведение
*** Elicitation
**** Запросы к пользователю
**** Интерактивность
*** Experimental
**** Новые функции
**** Тестирование

** Server Capabilities
*** Prompts
**** Шаблоны
**** Slash-команды
**** Пользователь контролирует
*** Resources
**** Данные и контекст
**** Файлы, БД, API
**** Приложение контролирует
*** Tools
**** Функции
**** Действия
**** LLM контролирует
*** Logging
**** debug, info, warning, error
*** Completions
**** Автодополнение

** Utilities
*** Cancellation
**** Отмена операций
**** cancelled notification
*** Progress
**** Прогресс операций
**** progress notifications
*** Ping
**** Keep-alive
**** Проверка соединения

** Inspector
*** Визуализация
*** Тестирование tools
*** Отладка
*** История запросов

** Lifecycle
*** Initialize
**** Обмен capabilities
**** Protocol version
*** Work
**** Запросы/ответы
**** Уведомления
*** Shutdown
**** Graceful close

@endmindmap
"""

# Transport диаграмма
module2_transport = """@startuml
!define RECTANGLE class

skinparam sequence {
    ArrowColor #333333
    ActorBorderColor #333333
    LifeLineBorderColor #333333
    ParticipantBorderColor #333333
    ParticipantBackgroundColor #E8EAF6
    ActorBackgroundColor #C5CAE9
}

title MCP Transport Mechanisms

== stdio Transport ==

participant "Host\\nApplication" as host1
participant "MCP Client" as client1
participant "MCP Server\\n(Child Process)" as server1

host1 -> server1 : Запуск процесса
activate server1

client1 -> server1 : Request (stdin)
note right
  JSON-RPC через 
  стандартный ввод
end note

server1 -> client1 : Response (stdout)
note right
  JSON-RPC через
  стандартный вывод
end note

server1 -> client1 : Logs (stderr)
note right
  Логи и ошибки
  через stderr
end note

client1 -> server1 : Graceful shutdown
deactivate server1

== HTTP/SSE Transport ==

participant "MCP Client" as client2
participant "HTTP Server" as http
participant "MCP Server\\n(Handler)" as server2

client2 -> http : POST /mcp\\n+ Authorization header
activate http
http -> server2 : Обработка запроса
activate server2
server2 -> http : JSON-RPC Response
deactivate server2
http -> client2 : HTTP 200 + JSON
deactivate http

== SSE для уведомлений ==

client2 -> http : GET /mcp/events\\n(SSE connection)
activate http
http -> client2 : text/event-stream

server2 -> http : Notification (progress)
http -> client2 : data: {"jsonrpc":"2.0",...}

server2 -> http : Notification (log)
http -> client2 : data: {"jsonrpc":"2.0",...}

client2 -> http : Закрытие SSE
deactivate http

@enduml
"""

# Message types диаграмма
module2_message_types = """@startuml

!define ENTITY class
skinparam class {
    BackgroundColor<<request>> #E1F5FE
    BackgroundColor<<response>> #C8E6C9
    BackgroundColor<<error>> #FFCDD2
    BackgroundColor<<notification>> #FFF9C4
    BorderColor #333333
}

class "Request" <<request>> {
    + jsonrpc: "2.0"
    + method: string
    + params: object
    + id: number | string
    --
    Требует ответа
    Имеет уникальный ID
}

class "Response" <<response>> {
    + jsonrpc: "2.0"
    + result: any
    + id: number | string
    --
    Успешный ответ
    ID соответствует запросу
}

class "Error" <<error>> {
    + jsonrpc: "2.0"
    + error: ErrorObject
    + id: number | string
    --
    Ошибка выполнения
    Содержит код и сообщение
}

class "ErrorObject" {
    + code: number
    + message: string
    + data?: any
    --
    Структура ошибки
}

class "Notification" <<notification>> {
    + jsonrpc: "2.0"
    + method: string
    + params?: object
    --
    Без ответа
    Нет поля id
}

Request "1" --> "1" Response : отвечает
Request "1" --> "0..1" Error : или ошибка
"Error" *-- "1" ErrorObject : содержит

note right of Request
  Примеры методов:
  - tools/call
  - resources/read
  - prompts/get
  - initialize
end note

note right of Response
  Содержит результат
  выполнения метода
end note

note right of Error
  Стандартные коды:
  -32700: Parse error
  -32600: Invalid Request
  -32601: Method not found
  -32602: Invalid params
  -32603: Internal error
end note

note right of Notification
  Примеры:
  - notifications/progress
  - notifications/message
  - logging/message
  - notifications/initialized
end note

@enduml
"""

# Capabilities диаграмма
module2_capabilities = """@startuml

!define RECTANGLE class

skinparam component {
    BackgroundColor<<client>> #FFF9C4
    BackgroundColor<<server>> #C8E6C9
    BorderColor #333333
}

package "MCP Client Capabilities" <<client>> {
    [Roots] as roots
    [Sampling] as sampling
    [Elicitation] as elicitation
    [Experimental] as exp_client
    
    note right of roots
      Корневые директории:
      - file:///path/to/project
      - Определение границ доступа
      - listChanged notifications
    end note
    
    note right of sampling
      Запросы к LLM:
      - sampling/createMessage
      - Агентское поведение
      - Контроль пользователя
    end note
    
    note right of elicitation
      Запросы к пользователю:
      - Дополнительная информация
      - Интерактивные workflow
    end note
}

package "MCP Server Capabilities" <<server>> {
    [Prompts] as prompts
    [Resources] as resources
    [Tools] as tools
    [Logging] as logging
    [Completions] as completions
    [Experimental] as exp_server
    
    note right of prompts
      Шаблоны:
      - prompts/list
      - prompts/get
      - Пользователь инициирует
    end note
    
    note right of resources
      Контекст и данные:
      - resources/list
      - resources/read
      - resources/subscribe
      - Приложение контролирует
    end note
    
    note right of tools
      Функции:
      - tools/list
      - tools/call
      - LLM инициирует
      - Согласие пользователя
    end note
    
    note right of logging
      Логирование:
      - debug, info
      - warning, error
      - logging/setLevel
    end note
    
    note right of completions
      Автодополнение:
      - Для промптов
      - Для аргументов
    end note
}

actor "User" as user
component "LLM" as llm
component "Application" as app

user --> prompts : инициирует
llm --> tools : инициирует
app --> resources : управляет

sampling --> llm : запрос
elicitation --> user : запрос

@enduml
"""

# Сохраняю все диаграммы
with open("mcp_course/modules/module_02_protocol/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module2_mindmap)

with open("mcp_course/modules/module_02_protocol/transport.puml", "w", encoding="utf-8") as f:
    f.write(module2_transport)

with open("mcp_course/modules/module_02_protocol/message_types.puml", "w", encoding="utf-8") as f:
    f.write(module2_message_types)

with open("mcp_course/modules/module_02_protocol/capabilities.puml", "w", encoding="utf-8") as f:
    f.write(module2_capabilities)

print("✅ Модуль 2 - все диаграммы созданы:")
print("  - mindmap.puml")
print("  - transport.puml")
print("  - message_types.puml")
print("  - capabilities.puml")
