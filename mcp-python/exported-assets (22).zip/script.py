
import os

# Проверяю структуру
if not os.path.exists("mcp_course"):
    print("⚠️ Создаю структуру заново...")
    directories = [
        "mcp_course/modules/module_05_llm_host/examples",
        "mcp_course/modules/module_06_llm_integration/examples",
        "mcp_course/modules/module_07_practice",
        "mcp_course/labs/lab_01_first_server/solution",
        "mcp_course/labs/lab_02_weather_service/solution",
        "mcp_course/labs/lab_03_file_manager/solution",
        "mcp_course/labs/lab_04_database_connector/solution",
        "mcp_course/labs/lab_05_full_application/solution",
    ]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print(f"✅ Создано директорий: {len(directories)}")
else:
    print("✅ Структура курса найдена")

print("\n🚀 Начинаю создание модулей 5-7 и лабораторных работ...")
