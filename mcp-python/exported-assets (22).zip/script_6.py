
# Создам модуль 7 - Практические проекты

module7_lecture = """# Модуль 7: Практические проекты с MCP

## Введение

В этом модуле мы применим все полученные знания для создания реальных проектов с использованием MCP. Мы рассмотрим полный цикл разработки: от проектирования до развертывания и мониторинга.

## Проект 1: Файловый менеджер

### Описание

MCP-сервер для безопасной работы с файловой системой. Позволяет LLM читать, записывать, искать файлы в ограниченной директории.

### Возможности

**Инструменты**:
- `list_directory` - Список файлов и папок
- `read_file` - Чтение содержимого файла
- `write_file` - Запись в файл
- `search_files` - Поиск файлов по имени или содержимому
- `get_file_info` - Метаинформация о файле

**Ресурсы**:
- `file://путь/к/файлу` - Содержимое файлов
- `dir://путь/к/папке` - Структура директории

**Безопасность**:
- Ограничение работы одной корневой директорией
- Валидация путей (предотвращение path traversal)
- Ограничение размера файлов
- Whitelist расширений файлов

### Ключевые моменты реализации

```python
import os
from pathlib import Path

class FileSystemServer:
    def __init__(self, root_dir: str, max_file_size: int = 10*1024*1024):
        self.root = Path(root_dir).resolve()
        self.max_size = max_file_size
    
    def validate_path(self, path: str) -> Path:
        # Безопасная проверка пути
        full_path = (self.root / path).resolve()
        
        # Проверка, что путь внутри root
        if not str(full_path).startswith(str(self.root)):
            raise ValueError("Path outside root directory")
        
        return full_path
```

## Проект 2: Сервис погоды

### Описание

MCP-сервер для получения информации о погоде через внешние API.

### Возможности

**Инструменты**:
- `get_current_weather` - Текущая погода
- `get_forecast` - Прогноз на несколько дней
- `get_weather_alerts` - Погодные предупреждения

**Ресурсы**:
- `weather://city/current` - Текущая погода для города
- `weather://city/forecast` - Прогноз для города

**Интеграция**:
- OpenWeatherMap API
- Кэширование запросов (TTL 30 минут)
- Обработка rate limits

### Ключевые моменты

```python
import aiohttp
from datetime import datetime, timedelta

class WeatherCache:
    def __init__(self, ttl_seconds: int = 1800):
        self.cache = {}
        self.ttl = ttl_seconds
    
    def get(self, key: str):
        if key in self.cache:
            data, timestamp = self.cache[key]
            if datetime.now() - timestamp < timedelta(seconds=self.ttl):
                return data
        return None
    
    def set(self, key: str, data):
        self.cache[key] = (data, datetime.now())
```

## Проект 3: Коннектор к базе данных

### Описание

Безопасный MCP-сервер для выполнения SQL запросов к базе данных.

### Возможности

**Инструменты**:
- `execute_query` - Выполнение SELECT запросов
- `get_tables` - Список таблиц
- `describe_table` - Схема таблицы
- `get_table_stats` - Статистика по таблице

**Ресурсы**:
- `db://schema` - Схема всей БД
- `db://table/название` - Данные таблицы

**Безопасность**:
- Только READ операции (SELECT)
- Query sanitization
- Ограничение количества строк
- Timeout для запросов

### Ключевые моменты

```python
import sqlparse
from sqlalchemy import create_engine, text

class DatabaseServer:
    ALLOWED_KEYWORDS = {'SELECT', 'FROM', 'WHERE', 'JOIN', 'ORDER', 'GROUP', 'LIMIT'}
    
    def validate_query(self, query: str) -> bool:
        parsed = sqlparse.parse(query)[0]
        
        # Проверяем тип запроса
        if parsed.get_type() != 'SELECT':
            raise ValueError("Only SELECT queries allowed")
        
        # Проверяем ключевые слова
        tokens = [t.value.upper() for t in parsed.tokens if t.ttype is sqlparse.tokens.Keyword]
        if not all(t in self.ALLOWED_KEYWORDS for t in tokens):
            raise ValueError("Forbidden SQL keywords")
        
        return True
```

## Проект 4: AI Coding Assistant

### Описание

Комплексный AI-ассистент для разработчиков, объединяющий несколько MCP-серверов.

### Архитектура

```
LLM-хост (Claude Desktop)
    ↓
├── File System Server (чтение/запись кода)
├── Git Server (работа с репозиторием)
├── Linter Server (проверка кода)
└── Documentation Server (поиск в документации)
```

### Возможности

**File System Server**:
- Чтение и запись файлов проекта
- Поиск по кодовой базе

**Git Server**:
- `git_status` - Статус репозитория
- `git_diff` - Изменения
- `git_log` - История коммитов
- `git_commit` - Создание коммита

**Linter Server**:
- `lint_file` - Проверка файла
- `format_code` - Форматирование
- `check_types` - Проверка типов

**Documentation Server**:
- `search_docs` - Поиск в документации
- `get_api_reference` - Справка по API

### Сценарии использования

**1. Рефакторинг кода**:
```
Пользователь: Отрефактори функцию calculate в файле utils.py

LLM:
1. [read_file] Читает utils.py
2. [lint_file] Проверяет текущий код
3. Предлагает улучшения
4. [write_file] Записывает новую версию
5. [git_diff] Показывает изменения
```

**2. Исправление багов**:
```
Пользователь: Исправь ошибку в tests/test_api.py

LLM:
1. [read_file] Читает тест
2. [git_log] Смотрит последние изменения
3. [search_docs] Ищет документацию по API
4. Анализирует проблему
5. [write_file] Исправляет код
6. [lint_file] Проверяет исправление
```

## Best Practices для production

### 1. Структура проекта

```
my-mcp-server/
├── src/
│   ├── __init__.py
│   ├── server.py          # Основной сервер
│   ├── tools/             # Инструменты
│   │   ├── __init__.py
│   │   ├── file_ops.py
│   │   └── search.py
│   ├── resources/         # Ресурсы
│   │   └── handlers.py
│   └── utils/             # Утилиты
│       ├── validation.py
│       └── cache.py
├── tests/
│   ├── test_tools.py
│   └── test_resources.py
├── requirements.txt
├── setup.py
├── README.md
└── .env.example
```

### 2. Конфигурация

```python
from pydantic import BaseSettings

class ServerConfig(BaseSettings):
    # Основные настройки
    server_name: str = "my-server"
    debug: bool = False
    
    # API ключи
    api_key: str
    
    # Лимиты
    max_file_size: int = 10 * 1024 * 1024
    request_timeout: int = 30
    
    # Пути
    root_directory: str
    cache_directory: str
    
    class Config:
        env_file = ".env"

config = ServerConfig()
```

### 3. Тестирование

```python
import pytest
from mcp.server.stdio import stdio_server
from your_server import app

@pytest.mark.asyncio
async def test_tool_execution():
    # Тест инструмента
    result = await app.call_tool_handler(
        "tool_name",
        {"arg": "value"}
    )
    
    assert result is not None
    assert result[0].text == "expected result"
```

### 4. Логирование

```python
import logging
import structlog

# Структурированное логирование для продакшн
structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.add_log_level,
        structlog.processors.JSONRenderer()
    ]
)

logger = structlog.get_logger()

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    logger.info(
        "tool_called",
        tool_name=name,
        args=arguments,
        user_id=get_user_id()  # если доступно
    )
```

### 5. Мониторинг

```python
from prometheus_client import Counter, Histogram

# Метрики
tool_calls_total = Counter(
    'mcp_tool_calls_total',
    'Total tool calls',
    ['tool_name', 'status']
)

tool_duration = Histogram(
    'mcp_tool_duration_seconds',
    'Tool execution duration',
    ['tool_name']
)

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    with tool_duration.labels(tool_name=name).time():
        try:
            result = await execute_tool(name, arguments)
            tool_calls_total.labels(tool_name=name, status='success').inc()
            return result
        except Exception as e:
            tool_calls_total.labels(tool_name=name, status='error').inc()
            raise
```

### 6. Развертывание

**Docker**:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY src/ ./src/

ENV PYTHONUNBUFFERED=1

CMD ["python", "src/server.py"]
```

**Systemd service**:
```ini
[Unit]
Description=MCP Server
After=network.target

[Service]
Type=simple
User=mcp
WorkingDirectory=/opt/mcp-server
Environment="PYTHONUNBUFFERED=1"
EnvironmentFile=/opt/mcp-server/.env
ExecStart=/opt/mcp-server/venv/bin/python src/server.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## Заключение

Создание production-ready MCP-серверов требует внимания к деталям: безопасность, производительность, мониторинг, тестирование. Следуя best practices из этого модуля, вы сможете создавать надежные и масштабируемые серверы.

Теперь переходите к лабораторным работам, где вы примените все эти знания на практике!

## Итоговая проверка знаний

1. Какие аспекты безопасности критичны для файлового менеджера?
2. Зачем нужно кэширование в сервисе погоды?
3. Почему в БД коннекторе разрешены только SELECT запросы?
4. Как организовать структуру production проекта?
5. Какие метрики важно отслеживать?

## Дальнейшее развитие

- Изучите продвинутые паттерны архитектуры MCP
- Создайте свои уникальные серверы
- Публикуйте серверы для сообщества
- Интегрируйтесь с различными LLM провайдерами
- Участвуйте в развитии MCP экосистемы
"""

with open("mcp_course/modules/module_07_practice/lecture.md", "w", encoding="utf-8") as f:
    f.write(module7_lecture)

print("✅ Модуль 7 - лекция создана")
print("\n🎯 Все модули (1-7) завершены!")
print("\n📚 Начинаю создание лабораторных работ...")
