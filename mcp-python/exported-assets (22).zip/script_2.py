
# Создам примеры и диаграммы для модуля 5

# Пример конфигурации Claude Desktop
claude_config = """{
  "mcpServers": {
    "calculator": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/calculator/server.py"
      ]
    },
    
    "file-system": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/filesystem/server.py"
      ],
      "env": {
        "ROOT_DIR": "/Users/username/Documents",
        "MAX_FILE_SIZE": "10485760"
      }
    },
    
    "weather": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/weather/server.py"
      ],
      "env": {
        "OPENWEATHER_API_KEY": "your-api-key-here"
      }
    },
    
    "database": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/database/server.py"
      ],
      "env": {
        "DB_HOST": "localhost",
        "DB_PORT": "5432",
        "DB_NAME": "mydb",
        "DB_USER": "user",
        "DB_PASSWORD": "password"
      }
    },
    
    "notes": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/notes/server.py"
      ],
      "env": {
        "NOTES_DIR": "/Users/username/.notes"
      }
    }
  }
}
"""

# Пример собственного LLM-хоста
custom_host = '''"""
Пример собственного LLM-хоста с MCP

Демонстрирует создание простого хоста, который:
- Подключается к MCP-серверу
- Интегрируется с Anthropic Claude API
- Обрабатывает tool calling
"""

import asyncio
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from anthropic import Anthropic
import json


def convert_mcp_tool_to_anthropic(mcp_tool):
    """
    Конвертирует MCP Tool в формат Anthropic
    
    Args:
        mcp_tool: Tool объект из MCP
        
    Returns:
        dict: Tool в формате Anthropic
    """
    return {
        "name": mcp_tool.name,
        "description": mcp_tool.description,
        "input_schema": mcp_tool.inputSchema
    }


async def run_conversation_with_tools():
    """Главная функция - запускает диалог с поддержкой MCP инструментов"""
    
    # Конфигурация MCP-сервера
    server_params = StdioServerParameters(
        command="python",
        args=["../module_03_python_sdk/examples/03_server_with_tools.py"],
        env=None
    )
    
    # Подключаемся к MCP-серверу
    print("🔌 Подключение к MCP-серверу...")
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as mcp_session:
            # Инициализируем соединение
            await mcp_session.initialize()
            print("✅ MCP-сервер подключен\\n")
            
            # Получаем список инструментов
            tools_result = await mcp_session.list_tools()
            print(f"📦 Доступно инструментов: {len(tools_result.tools)}")
            for tool in tools_result.tools:
                print(f"   - {tool.name}: {tool.description}")
            print()
            
            # Конвертируем MCP tools в формат Anthropic
            anthropic_tools = [
                convert_mcp_tool_to_anthropic(tool)
                for tool in tools_result.tools
            ]
            
            # Создаем клиент Anthropic
            anthropic_client = Anthropic(
                api_key=os.environ.get("ANTHROPIC_API_KEY")
            )
            
            # История сообщений
            messages = []
            
            # Пользовательский запрос
            user_message = "Переведи текст 'Hello World' в верхний регистр и затем посчитай 15 умножить на 3"
            print(f"👤 Пользователь: {user_message}\\n")
            
            messages.append({
                "role": "user",
                "content": user_message
            })
            
            # Максимум 5 итераций для предотвращения бесконечных циклов
            max_iterations = 5
            
            for iteration in range(max_iterations):
                print(f"🤖 Claude (итерация {iteration + 1}):")
                
                # Запрос к Claude
                response = anthropic_client.messages.create(
                    model="claude-3-5-sonnet-20241022",
                    max_tokens=1024,
                    tools=anthropic_tools,
                    messages=messages
                )
                
                print(f"   Stop reason: {response.stop_reason}")
                
                # Обрабатываем ответ
                if response.stop_reason == "tool_use":
                    # Claude хочет использовать инструмент(ы)
                    tool_results = []
                    
                    for content_block in response.content:
                        if content_block.type == "text":
                            print(f"   Текст: {content_block.text}")
                        
                        elif content_block.type == "tool_use":
                            tool_name = content_block.name
                            tool_input = content_block.input
                            
                            print(f"   🔧 Вызов инструмента: {tool_name}")
                            print(f"      Аргументы: {json.dumps(tool_input, indent=6)}")
                            
                            # Вызываем инструмент через MCP
                            try:
                                result = await mcp_session.call_tool(
                                    tool_name,
                                    tool_input
                                )
                                
                                # Извлекаем текст из результата
                                result_text = ""
                                for content in result.content:
                                    if hasattr(content, 'text'):
                                        result_text = content.text
                                
                                print(f"      Результат: {result_text}")
                                
                                tool_results.append({
                                    "type": "tool_result",
                                    "tool_use_id": content_block.id,
                                    "content": result_text
                                })
                                
                            except Exception as e:
                                print(f"      ❌ Ошибка: {e}")
                                tool_results.append({
                                    "type": "tool_result",
                                    "tool_use_id": content_block.id,
                                    "content": f"Error: {str(e)}",
                                    "is_error": True
                                })
                    
                    # Добавляем ответ ассистента в историю
                    messages.append({
                        "role": "assistant",
                        "content": response.content
                    })
                    
                    # Добавляем результаты инструментов
                    messages.append({
                        "role": "user",
                        "content": tool_results
                    })
                    
                    print()
                    
                elif response.stop_reason == "end_turn":
                    # Claude завершил ответ
                    final_response = ""
                    for content_block in response.content:
                        if content_block.type == "text":
                            final_response = content_block.text
                    
                    print(f"   📝 Финальный ответ: {final_response}\\n")
                    break
                
                else:
                    print(f"   Неожиданный stop_reason: {response.stop_reason}\\n")
                    break
            
            print("=" * 60)
            print("✅ Диалог завершен")


if __name__ == "__main__":
    # Проверяем наличие API ключа
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("❌ Ошибка: Установите переменную окружения ANTHROPIC_API_KEY")
        print("   export ANTHROPIC_API_KEY='your-api-key'")
    else:
        asyncio.run(run_conversation_with_tools())
'''

# Mindmap для модуля 5
module5_mindmap = """@startmindmap
* Интеграция с LLM-хостом

** LLM-хост
*** Роль в архитектуре
**** UI для пользователя
**** Управление LLM
**** MCP Client manager
**** Контроль безопасности
*** Популярные хосты
**** Claude Desktop
**** VS Code (Cline)
**** Zed Editor
**** Собственные хосты

left side

** Claude Desktop
*** Установка
**** Официальный сайт
**** Windows/macOS/Linux
*** Конфигурация
**** claude_desktop_config.json
**** Расположение по ОС
**** JSON структура
*** Множественные серверы
**** mcpServers объект
**** Уникальные имена
*** Переменные окружения
**** API ключи
**** Конфигурация
**** Секреты

** Использование в хосте
*** Обнаружение серверов
**** Автозапуск
**** Индикатор статуса
*** Вызов инструментов
**** Автоматическое обнаружение
**** Tool calling
*** Работа с ресурсами
**** Автозапрос контекста
**** Анализ данных
*** Промпты
**** Slash-команды
**** Интерактивные формы

** Собственный хост
*** Компоненты
**** MCP ClientSession
**** LLM API клиент
**** Преобразование форматов
*** Anthropic интеграция
**** Messages API
**** Tool calling
**** Итеративный диалог
*** OpenAI интеграция
**** Chat completions
**** Function calling

** Безопасность
*** Контроль доступа
**** Разрешения пользователя
**** Опасные операции
*** Sandboxing
**** Docker контейнеры
**** Изоляция процессов
*** Аудит
**** Логирование вызовов
**** Трекинг действий

** Отладка
*** Проверка конфигурации
**** Валидация JSON
**** Проверка путей
*** Логи хоста
**** Расположение
**** Мониторинг
*** Типичные проблемы
**** Сервер не запускается
**** Инструменты не видны
**** Ошибки аутентификации

** Best Practices
*** Организация
**** Структура директорий
**** Документация
*** Версионирование
**** Версии серверов
*** Graceful degradation
**** Опциональные зависимости

@endmindmap
"""

# Диаграмма интеграции
module5_integration = """@startuml

title Интеграция LLM-хоста с MCP-серверами

actor "Пользователь" as user
participant "LLM-хост\\n(Claude Desktop)" as host
participant "MCP Client\\n(встроенный)" as client
participant "LLM API\\n(Claude)" as llm
collections "MCP Servers" as servers

== Инициализация ==

user -> host: Запуск приложения
activate host

host -> host: Чтение конфигурации\\nclaud_desktop_config.json

loop Для каждого сервера в конфигурации
    host -> servers: Запуск сервера\\n(stdio process)
    activate servers
    
    host -> client: Создание ClientSession
    activate client
    
    client -> servers: initialize()
    servers --> client: server_info, capabilities
    
    client -> servers: tools/list
    servers --> client: [список инструментов]
    
    client --> host: Сервер готов
    deactivate client
end

host --> user: ✅ Готов к работе

== Пользовательский запрос ==

user -> host: "Посчитай 15 + 27"
host -> llm: messages.create()\\n+ tools список

llm -> llm: Анализ запроса
llm --> host: tool_use: "add"\\n{a: 15, b: 27}

host -> client: Активация MCP Client
activate client

client -> servers: tools/call\\n"add" {a:15, b:27}
activate servers

servers -> servers: Выполнение инструмента
servers --> client: result: "15 + 27 = 42"
deactivate servers

client --> host: TextContent: "42"
deactivate client

host -> llm: tool_result: "42"
llm -> llm: Генерация ответа
llm --> host: "Результат: 42"

host --> user: Отображение результата

== Работа с ресурсами ==

user -> host: "Покажи мою конфигурацию"

host -> client: Активация клиента
activate client

client -> servers: resources/list
servers --> client: [config://app, ...]

client -> servers: resources/read\\n"config://app"
servers --> client: JSON конфигурация

client --> host: Данные конфигурации
deactivate client

host -> llm: messages.create()\\n+ контекст
llm --> host: Анализ конфигурации

host --> user: Результат анализа

== Завершение ==

user -> host: Закрытие приложения

host -> servers: Остановка процессов
deactivate servers

deactivate host

@enduml
"""

# Сохраняю файлы
with open("mcp_course/modules/module_05_llm_host/examples/claude_desktop_config.json", "w", encoding="utf-8") as f:
    f.write(claude_config)

with open("mcp_course/modules/module_05_llm_host/examples/custom_host.py", "w", encoding="utf-8") as f:
    f.write(custom_host)

with open("mcp_course/modules/module_05_llm_host/mindmap.puml", "w", encoding="utf-8") as f:
    f.write(module5_mindmap)

with open("mcp_course/modules/module_05_llm_host/integration_diagram.puml", "w", encoding="utf-8") as f:
    f.write(module5_integration)

print("✅ Модуль 5 завершен:")
print("  - lecture.md")
print("  - claude_desktop_config.json")
print("  - custom_host.py")
print("  - mindmap.puml")
print("  - integration_diagram.puml")
print("\n📦 Модуль 5 полностью готов!")
