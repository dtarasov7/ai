# Модуль 5: Интеграция с LLM-хостом

## Введение

LLM-хост — это приложение, которое использует языковую модель и может подключаться к MCP-серверам для расширения своих возможностей. В этом модуле мы рассмотрим, как интегрировать ваши MCP-серверы с популярными LLM-хостами.

## Концепция LLM-хоста

### Роль хоста в архитектуре MCP

```
Пользователь
    ↓
LLM-хост (Claude Desktop, VS Code, etc.)
    ↓
MCP Client (встроенный в хост)
    ↓
MCP Servers (ваши серверы)
```

**Хост отвечает за**:
- Предоставление UI для пользователя
- Управление LLM (языковой моделью)
- Запуск и управление MCP-клиентами
- Контроль безопасности и разрешений
- Отображение результатов работы серверов

## Claude Desktop

Claude Desktop — это официальное настольное приложение от Anthropic, которое имеет встроенную поддержку MCP.

### Установка Claude Desktop

1. Скачайте Claude Desktop с официального сайта: https://claude.ai/download
2. Установите приложение для вашей ОС (Windows, macOS, Linux)
3. Войдите в свой аккаунт Anthropic

### Конфигурация MCP-серверов

Claude Desktop использует JSON-файл для конфигурации MCP-серверов.

**Расположение конфигурационного файла**:

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux**: `~/.config/Claude/claude_desktop_config.json`

### Структура конфигурации

```json
{
  "mcpServers": {
    "server-name": {
      "command": "python",
      "args": [
        "/path/to/your/server.py"
      ],
      "env": {
        "ENVIRONMENT_VARIABLE": "value"
      }
    }
  }
}
```

### Пример конфигурации

```json
{
  "mcpServers": {
    "file-system": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/filesystem_server.py"
      ],
      "env": {
        "ROOT_DIR": "/Users/username/Documents"
      }
    },

    "database": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/database_server.py"
      ],
      "env": {
        "DB_HOST": "localhost",
        "DB_PORT": "5432",
        "DB_NAME": "mydb"
      }
    },

    "calculator": {
      "command": "python",
      "args": [
        "/Users/username/mcp-servers/calculator_server.py"
      ]
    }
  }
}
```

### Множественные серверы

Claude Desktop может подключаться к нескольким MCP-серверам одновременно:

```json
{
  "mcpServers": {
    "weather": {
      "command": "python",
      "args": ["/path/to/weather_server.py"],
      "env": {
        "API_KEY": "your-api-key"
      }
    },

    "notes": {
      "command": "python",
      "args": ["/path/to/notes_server.py"]
    },

    "calendar": {
      "command": "node",
      "args": ["/path/to/calendar-server.js"]
    }
  }
}
```

### Переменные окружения

Используйте переменные окружения для конфиденциальных данных:

```json
{
  "mcpServers": {
    "api-integration": {
      "command": "python",
      "args": ["/path/to/api_server.py"],
      "env": {
        "API_KEY": "sk-...",
        "API_URL": "https://api.example.com",
        "DEBUG": "false"
      }
    }
  }
}
```

**Best practice**: Никогда не коммитьте API ключи в Git. Используйте `.env` файлы или системные переменные окружения.

## Использование серверов в Claude Desktop

### Обнаружение серверов

После добавления конфигурации:

1. Перезапустите Claude Desktop
2. Серверы автоматически запустятся при старте приложения
3. В интерфейсе появится индикатор подключенных серверов

### Вызов инструментов

Claude автоматически видит все доступные инструменты из подключенных серверов:

**Пример диалога**:

```
Пользователь: Посчитай 15 + 27

Claude: [Использует инструмент "add" из calculator сервера]
Результат: 15 + 27 = 42
```

### Работа с ресурсами

Claude может автоматически запрашивать ресурсы для контекста:

```
Пользователь: Проанализируй мой конфиг

Claude: [Запрашивает ресурс "config://app" из сервера]
[Анализирует JSON конфигурацию]

На основе вашей конфигурации:
- Приложение в debug режиме
- База данных: PostgreSQL на localhost:5432
- Включено логирование и кэширование
```

### Использование промптов

Промпты становятся slash-командами в Claude Desktop:

```
Пользователь: /code_review

[Открывается форма с полями из промпта]
Language: python
Code: [пользователь вставляет код]

[Claude генерирует детальное ревью]
```

## Другие LLM-хосты

### VS Code с Cline (ранее Claude Dev)

**Установка**:
1. Установите расширение Cline из VS Code Marketplace
2. Настройте API ключ Anthropic

**Конфигурация MCP**:

Создайте файл `.vscode/mcp.json` в вашем проекте:

```json
{
  "mcpServers": {
    "project-tools": {
      "command": "python",
      "args": ["${workspaceFolder}/mcp_server.py"]
    }
  }
}
```

### Zed Editor

Zed имеет встроенную поддержку MCP через конфигурацию:

**~/.config/zed/settings.json**:

```json
{
  "assistant": {
    "mcp_servers": {
      "my-server": {
        "command": "python",
        "args": ["/path/to/server.py"]
      }
    }
  }
}
```

### Собственный LLM-хост

Вы можете создать собственный хост, используя MCP Python SDK:

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
import anthropic  # или openai

async def run_llm_host():
    # Подключаемся к MCP-серверу
    server_params = StdioServerParameters(
        command="python",
        args=["my_server.py"]
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as mcp_session:
            await mcp_session.initialize()

            # Получаем доступные инструменты
            tools_result = await mcp_session.list_tools()

            # Создаем клиент Anthropic
            client = anthropic.Anthropic(api_key="...")

            # Преобразуем MCP tools в формат Anthropic
            anthropic_tools = convert_mcp_to_anthropic_tools(tools_result.tools)

            # Запрос к Claude
            response = client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1024,
                tools=anthropic_tools,
                messages=[
                    {"role": "user", "content": "Посчитай 15 + 27"}
                ]
            )

            # Если Claude хочет вызвать инструмент
            if response.stop_reason == "tool_use":
                for content_block in response.content:
                    if content_block.type == "tool_use":
                        # Вызываем инструмент через MCP
                        result = await mcp_session.call_tool(
                            content_block.name,
                            content_block.input
                        )

                        print(f"Результат: {result}")

asyncio.run(run_llm_host())
```

## Безопасность и разрешения

### Контроль доступа

LLM-хост должен запрашивать разрешение пользователя перед:

1. **Вызовом инструментов**, которые:
   - Изменяют данные
   - Взаимодействуют с внешними API
   - Выполняют системные команды

2. **Доступом к ресурсам**, содержащим:
   - Конфиденциальную информацию
   - Персональные данные
   - Корпоративные секреты

### Sandboxing

Рекомендуется запускать MCP-серверы в изолированном окружении:

```json
{
  "mcpServers": {
    "untrusted-server": {
      "command": "docker",
      "args": [
        "run",
        "--rm",
        "-i",
        "mcp-server-image"
      ]
    }
  }
}
```

### Аудит действий

Логируйте все вызовы инструментов для аудита:

```python
import logging

logger = logging.getLogger(__name__)

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    # Аудит-лог
    logger.info(
        f"AUDIT: Tool called",
        extra={
            "tool": name,
            "args": arguments,
            "timestamp": datetime.now().isoformat(),
            "user": get_current_user()  # если доступно
        }
    )

    result = execute_tool(name, arguments)
    return result
```

## Отладка интеграции с хостом

### Проверка конфигурации

**Шаг 1**: Убедитесь, что конфигурационный файл валиден:

```bash
# Проверка JSON
cat ~/Library/Application\ Support/Claude/claude_desktop_config.json | python -m json.tool
```

**Шаг 2**: Проверьте пути к серверам:

```bash
# Тестовый запуск сервера
python /path/to/your/server.py
```

**Шаг 3**: Проверьте переменные окружения:

```python
import os
import sys

print("Environment:", file=sys.stderr)
for key, value in os.environ.items():
    if key.startswith("DB_") or key == "API_KEY":
        print(f"  {key}: {value}", file=sys.stderr)
```

### Логи Claude Desktop

**macOS**:
```bash
# Просмотр логов
tail -f ~/Library/Logs/Claude/mcp*.log
```

**Windows**:
```powershell
# Просмотр логов
Get-Content "$env:APPDATA\Claude\Logs\mcp*.log" -Wait
```

### Типичные проблемы

**1. Сервер не запускается**:
- Проверьте права выполнения: `chmod +x server.py`
- Проверьте shebang: `#!/usr/bin/env python3`
- Проверьте виртуальное окружение

**2. Инструменты не видны**:
- Убедитесь, что сервер возвращает список tools
- Проверьте логи сервера через stderr
- Используйте MCP Inspector для тестирования

**3. Ошибки аутентификации**:
- Проверьте переменные окружения
- Убедитесь, что API ключи актуальны

## Best Practices

### 1. Организация серверов

```
~/mcp-servers/
├── filesystem/
│   ├── server.py
│   ├── requirements.txt
│   └── README.md
├── database/
│   ├── server.py
│   ├── requirements.txt
│   └── README.md
└── shared/
    └── utils.py
```

### 2. Документация серверов

Создайте README для каждого сервера:

```markdown
# File System MCP Server

## Описание
Предоставляет доступ к файловой системе через MCP.

## Конфигурация

\`\`\`json
{
  "command": "python",
  "args": ["/path/to/filesystem/server.py"],
  "env": {
    "ROOT_DIR": "/path/to/allowed/directory"
  }
}
\`\`\`

## Инструменты
- `list_files` - Список файлов
- `read_file` - Чтение файла
- `write_file` - Запись файла

## Безопасность
Сервер ограничен директорией ROOT_DIR.
```

### 3. Версионирование

Указывайте версию в имени сервера:

```json
{
  "mcpServers": {
    "my-server-v1": {
      "command": "python",
      "args": ["/path/to/server_v1.py"]
    }
  }
}
```

### 4. Graceful degradation

Сервер должен корректно работать при отсутствии опциональных зависимостей:

```python
try:
    import optional_library
    FEATURE_ENABLED = True
except ImportError:
    FEATURE_ENABLED = False
    logger.warning("Optional feature disabled: optional_library not found")

@app.list_tools()
async def list_tools():
    tools = [...]  # Основные инструменты

    if FEATURE_ENABLED:
        tools.append(...)  # Опциональные инструменты

    return tools
```

## Заключение

Интеграция MCP-серверов с LLM-хостами открывает огромные возможности для расширения функциональности AI-ассистентов. Claude Desktop предоставляет удобный способ использования ваших серверов, а возможность создания собственных хостов дает полную гибкость.

В следующем модуле мы рассмотрим интеграцию с различными LLM API и как работать с моделями, которые поддерживают или не поддерживают function calling.

## Контрольные вопросы

1. Где находится конфигурационный файл Claude Desktop на разных ОС?
2. Как добавить несколько MCP-серверов в конфигурацию?
3. Зачем использовать переменные окружения в конфигурации?
4. Какие действия требуют разрешения пользователя?
5. Как отладить проблемы с запуском сервера в хосте?

## Практические задания

1. Настройте Claude Desktop для работы с вашим MCP-сервером
2. Создайте конфигурацию с несколькими серверами
3. Протестируйте вызов инструментов через Claude Desktop
4. Реализуйте аудит-логирование вызовов инструментов
