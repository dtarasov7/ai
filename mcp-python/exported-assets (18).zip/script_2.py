
# requirements.txt
requirements_content = """# MCP Python SDK
mcp>=1.7.0

# Асинхронные библиотеки
aiohttp>=3.9.0
anyio>=4.0.0

# Для работы с конфигурацией
pyyaml>=6.0.0
python-dotenv>=1.0.0

# Для примеров с LLM
openai>=1.0.0
anthropic>=0.21.0

# Для работы с данными
pydantic>=2.0.0

# Логирование
structlog>=24.0.0

# Для тестирования
pytest>=8.0.0
pytest-asyncio>=0.23.0

# Для разработки
black>=24.0.0
ruff>=0.3.0
mypy>=1.8.0
"""

with open("mcp_course/requirements.txt", "w", encoding="utf-8") as f:
    f.write(requirements_content)

print("✅ requirements.txt создан")
