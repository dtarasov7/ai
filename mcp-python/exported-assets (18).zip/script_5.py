
# Модуль 1 - Архитектурная диаграмма
module1_architecture = """@startuml
!define RECTANGLE class

skinparam componentStyle rectangle
skinparam backgroundColor #FEFEFE
skinparam component {
    BackgroundColor<<host>> #E1F5FF
    BackgroundColor<<client>> #FFF9C4
    BackgroundColor<<server>> #C8E6C9
    BorderColor #333333
    FontSize 13
}

' Определение компонентов
package "Host Application" <<host>> {
    component "LLM Application\\n(Claude Desktop, VS Code)" as host
    component "UI Layer" as ui
    component "Security & Control" as security
}

package "MCP Client Layer" <<client>> {
    component "MCP Client" as client {
        component "Connection Manager" as conn
        component "Capability Negotiator" as cap
        component "Request/Response Handler" as handler
    }
}

package "MCP Servers" <<server>> {
    component "File System Server" as fs_server {
        component "Resources" as fs_res
        component "Tools" as fs_tools
    }
    
    component "Database Server" as db_server {
        component "Resources" as db_res
        component "Tools" as db_tools
    }
    
    component "API Integration Server" as api_server {
        component "Resources" as api_res
        component "Tools" as api_tools
        component "Prompts" as api_prompts
    }
}

' Внешние системы
database "PostgreSQL" as db
folder "File System" as fs
cloud "External APIs" as api

' Пользователь
actor "User" as user

' Связи
user --> ui : Взаимодействие
ui --> host : Команды
host --> security : Проверка доступа
host --> client : Управление
security --> client : Авторизация

client -down-> fs_server : JSON-RPC\\n(stdio)
client -down-> db_server : JSON-RPC\\n(stdio)
client -down-> api_server : JSON-RPC\\n(HTTP/SSE)

fs_server --> fs : Чтение/запись
db_server --> db : SQL запросы
api_server --> api : HTTP запросы

note right of user
  Пользователь явно
  контролирует доступ
  к данным и действиям
end note

note right of client
  Клиент может подключаться
  к множеству серверов
  одновременно
end note

note bottom of fs_server
  Каждый сервер предоставляет:
  - Resources (данные)
  - Tools (функции)
  - Prompts (шаблоны)
end note

@enduml
"""

with open("mcp_course/modules/module_01_introduction/architecture.puml", "w", encoding="utf-8") as f:
    f.write(module1_architecture)

print("✅ Модуль 1 - архитектурная диаграмма создана")
