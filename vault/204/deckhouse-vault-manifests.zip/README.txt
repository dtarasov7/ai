Deckhouse Kubernetes -> external HashiCorp Vault OSS 2.0.4 example package

Placeholders to replace:
- https://vault.example.com:8200
- https://api.d8-prod.example.com:6443
- registry.example.com/billing-api:1.0.0
- Vault CA certificate in 03-secrets-store-integration-moduleconfig.yaml
- example database credentials

Suggested order:
1. kubectl apply -f manifests/00-namespaces-serviceaccounts.yaml
2. kubectl apply -f manifests/01-vault-token-reviewer-rbac.yaml
3. kubectl apply -f manifests/02-vault-token-reviewer-token.yaml
4. configure VAULT_ADDR, VAULT_TOKEN, KUBE_API and run vault/setup-vault.sh
5. kubectl apply -f manifests/03-secrets-store-integration-moduleconfig.yaml
6. CSI: apply 10 + 11 manifests
7. ENV: apply 20 (or 21) manifest

Do not commit real tokens, Vault CA private keys, or real secret values to Git.
