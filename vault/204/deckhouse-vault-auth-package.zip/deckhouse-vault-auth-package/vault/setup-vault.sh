#!/usr/bin/env bash
set -euo pipefail

# Required inputs:
#   VAULT_ADDR=https://vault.example.com:8200
#   VAULT_TOKEN=<admin token capable of enabling auth/secrets and writing policies>
#   KUBE_API=https://api.d8-prod.example.com:6443
# Optional:
#   AUTH_PATH=d8-prod
#   REVIEWER_SECRET=vault-token-reviewer-token
#   REVIEWER_NS=vault-auth

: "${VAULT_ADDR:?set VAULT_ADDR}"
: "${VAULT_TOKEN:?set VAULT_TOKEN}"
: "${KUBE_API:?set KUBE_API}"

AUTH_PATH="${AUTH_PATH:-d8-prod}"
REVIEWER_SECRET="${REVIEWER_SECRET:-vault-token-reviewer-token}"
REVIEWER_NS="${REVIEWER_NS:-vault-auth}"

export VAULT_ADDR VAULT_TOKEN

TOKEN_REVIEWER_JWT="$(kubectl -n "${REVIEWER_NS}" get secret "${REVIEWER_SECRET}" -o go-template='{{ .data.token }}' | base64 --decode)"
KUBE_CA_CERT="$(kubectl config view --raw --minify --flatten -o jsonpath='{.clusters[0].cluster.certificate-authority-data}' | base64 --decode)"

if ! vault auth list -format=json | jq -e --arg p "${AUTH_PATH}/" 'has($p)' >/dev/null; then
  vault auth enable -path="${AUTH_PATH}" kubernetes
fi

vault write "auth/${AUTH_PATH}/config" \
  kubernetes_host="${KUBE_API}" \
  kubernetes_ca_cert="${KUBE_CA_CERT}" \
  token_reviewer_jwt="${TOKEN_REVIEWER_JWT}"

if ! vault secrets list -format=json | jq -e 'has("apps-kv/")' >/dev/null; then
  vault secrets enable -path=apps-kv -version=2 kv
fi

# Example data only: replace immediately in a real environment.
vault kv put apps-kv/prod/billing/database \
  username='billing_user' \
  password='REPLACE_ME'

vault policy write billing-api-ro - <<'HCL'
path "apps-kv/data/prod/billing/database" {
  capabilities = ["read"]
}
HCL

vault write "auth/${AUTH_PATH}/role/billing-api" \
  bound_service_account_names='billing-api' \
  bound_service_account_namespaces='billing' \
  token_policies='billing-api-ro' \
  audience='vault' \
  token_ttl='10m' \
  token_max_ttl='30m'

vault read "auth/${AUTH_PATH}/config"
vault read "auth/${AUTH_PATH}/role/billing-api"
