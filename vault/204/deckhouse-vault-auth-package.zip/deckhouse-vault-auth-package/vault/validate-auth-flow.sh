#!/usr/bin/env bash
set -euo pipefail

: "${VAULT_ADDR:?set VAULT_ADDR}"
AUTH_PATH="${AUTH_PATH:-d8-prod}"

WORKLOAD_JWT="$(kubectl -n billing create token billing-api --audience=vault --duration=10m)"

# Decode payload for inspection only. Authentication must never rely on local decode alone.
echo "=== JWT payload ==="
python3 - <<'PY' "${WORKLOAD_JWT}"
import base64, json, sys
p=sys.argv[1].split('.')[1]
p += '=' * (-len(p) % 4)
print(json.dumps(json.loads(base64.urlsafe_b64decode(p)), indent=2, ensure_ascii=False))
PY

# Login exactly as the Deckhouse CSI/provider or ENV injector conceptually does.
echo "=== Vault login ==="
LOGIN_JSON="$(jq -n --arg role billing-api --arg jwt "${WORKLOAD_JWT}" '{role:$role,jwt:$jwt}')"
RESPONSE="$(curl -fsS --request POST --header 'Content-Type: application/json' --data "${LOGIN_JSON}" "${VAULT_ADDR}/v1/auth/${AUTH_PATH}/login")"
echo "${RESPONSE}" | jq '{auth: {policies: .auth.policies, lease_duration: .auth.lease_duration, renewable: .auth.renewable, metadata: .auth.metadata}}'

CLIENT_TOKEN="$(echo "${RESPONSE}" | jq -r '.auth.client_token')"

echo "=== Read KV v2 secret (values redacted) ==="
curl -fsS --header "X-Vault-Token: ${CLIENT_TOKEN}" "${VAULT_ADDR}/v1/apps-kv/data/prod/billing/database" \
  | jq '.data.data | with_entries(.value="***REDACTED***")'
