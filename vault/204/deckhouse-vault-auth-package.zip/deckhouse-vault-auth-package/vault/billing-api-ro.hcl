# KV v2 data endpoint. Keep the path as narrow as possible.
path "apps-kv/data/prod/billing/database" {
  capabilities = ["read"]
}
