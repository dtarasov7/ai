#!/usr/bin/env bash
set -euo pipefail

HTPASSWD_LINE="${1:-}"
if [[ -z "$HTPASSWD_LINE" ]]; then
  echo "Usage: $0 '<username:bcrypt-hash>'" >&2
  exit 1
fi

: "${VAULT_ADDR:?VAULT_ADDR is required}"
: "${VAULT_TOKEN:?VAULT_TOKEN is required}"
: "${TOKEN_REVIEWER_JWT:?TOKEN_REVIEWER_JWT is required}"
: "${KUBERNETES_HOST:?KUBERNETES_HOST is required}"
: "${KUBERNETES_CA_CERT:?KUBERNETES_CA_CERT is required}"

curl_json() {
  local method="$1"
  local url="$2"
  local data="${3:-}"
  if [[ -n "$data" ]]; then
    curl -fsS \
      -H "X-Vault-Token: ${VAULT_TOKEN}" \
      -H "Content-Type: application/json" \
      -X "$method" \
      -d "$data" \
      "$url"
  else
    curl -fsS \
      -H "X-Vault-Token: ${VAULT_TOKEN}" \
      -H "Content-Type: application/json" \
      -X "$method" \
      "$url"
  fi
}

curl_json POST "${VAULT_ADDR}/v1/sys/mounts/secret" '{"type":"kv","options":{"version":"2"}}' || true
curl_json POST "${VAULT_ADDR}/v1/sys/auth/kubernetes" '{"type":"kubernetes"}' || true

CONFIG_PAYLOAD=$(cat <<JSON
{
  "token_reviewer_jwt": $(jq -Rn --arg v "$TOKEN_REVIEWER_JWT" '$v'),
  "kubernetes_host": $(jq -Rn --arg v "$KUBERNETES_HOST" '$v'),
  "kubernetes_ca_cert": $(jq -Rn --arg v "$KUBERNETES_CA_CERT" '$v')
}
JSON
)

curl_json POST "${VAULT_ADDR}/v1/auth/kubernetes/config" "$CONFIG_PAYLOAD"

POLICY_PAYLOAD='{"policy":"path \"secret/data/nginx/basic-auth\" { capabilities = [\"read\"] }"}'
curl_json PUT "${VAULT_ADDR}/v1/sys/policies/acl/nginx-basic-auth" "$POLICY_PAYLOAD"

ROLE_PAYLOAD='{
  "bound_service_account_names": "nginx-vault",
  "bound_service_account_namespaces": "web",
  "policies": "nginx-basic-auth",
  "ttl": "1h"
}'
curl_json POST "${VAULT_ADDR}/v1/auth/kubernetes/role/nginx-basic-auth" "$ROLE_PAYLOAD"

SECRET_PAYLOAD=$(cat <<JSON
{
  "data": {
    "htpasswd": $(jq -Rn --arg v "$HTPASSWD_LINE" '$v')
  }
}
JSON
)

curl_json POST "${VAULT_ADDR}/v1/secret/data/nginx/basic-auth" "$SECRET_PAYLOAD"

echo "Vault configured successfully through HTTP API."
