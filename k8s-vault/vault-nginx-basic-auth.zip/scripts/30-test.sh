#!/usr/bin/env bash
set -euo pipefail

USER_NAME="${1:-demo}"
PASSWORD="${2:-}"
if [[ -z "$PASSWORD" ]]; then
  echo "Usage: $0 <username> <password>" >&2
  exit 1
fi

kubectl -n web port-forward svc/nginx-basic-auth 8080:80 >/tmp/nginx-port-forward.log 2>&1 &
PF_PID=$!
trap 'kill $PF_PID >/dev/null 2>&1 || true' EXIT
sleep 3

echo "== Without credentials =="
curl -i http://127.0.0.1:8080/ || true

echo
echo "== With credentials =="
curl -i -u "$USER_NAME:$PASSWORD" http://127.0.0.1:8080/ || true

echo
echo "== Rendered htpasswd file =="
kubectl -n web exec deploy/nginx-basic-auth -- cat /vault/secrets/htpasswd
