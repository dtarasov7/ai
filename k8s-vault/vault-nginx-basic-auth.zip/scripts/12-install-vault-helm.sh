#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

kubectl apply -f "$ROOT_DIR/manifests/00-vault-namespace.yaml"
kubectl apply -f "$ROOT_DIR/manifests/01-vault-serviceaccount.yaml"
kubectl apply -f "$ROOT_DIR/manifests/02-vault-auth-delegator-clusterrolebinding.yaml"

helm repo add hashicorp https://helm.releases.hashicorp.com >/dev/null
helm repo update >/dev/null

helm upgrade --install vault hashicorp/vault \
  --namespace vault \
  -f "$ROOT_DIR/manifests/vault-helm-values.yaml"

echo
 echo "If this is a fresh Vault install, initialize and unseal it, for example:"
 echo "  kubectl -n vault exec -it vault-0 -- vault operator init"
 echo "  kubectl -n vault exec -it vault-0 -- vault operator unseal"
 echo
 echo "Then port-forward UI/API if needed:"
 echo "  kubectl -n vault port-forward svc/vault 8200:8200"
