#!/usr/bin/env bash
set -euo pipefail

USER_NAME="${1:-demo}"
PASSWORD="${2:-}"

if [[ -z "$PASSWORD" ]]; then
  echo "Usage: $0 <username> <password>" >&2
  exit 1
fi

if command -v htpasswd >/dev/null 2>&1; then
  htpasswd -nbB "$USER_NAME" "$PASSWORD"
  exit 0
fi

if command -v docker >/dev/null 2>&1; then
  docker run --rm httpd:2.4-alpine htpasswd -nbB "$USER_NAME" "$PASSWORD"
  exit 0
fi

echo "Neither htpasswd nor docker is available." >&2
exit 1
