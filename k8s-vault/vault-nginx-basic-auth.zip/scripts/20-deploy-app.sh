#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

kubectl apply -f "$ROOT_DIR/manifests/10-web-namespace.yaml"
kubectl apply -f "$ROOT_DIR/manifests/11-nginx-serviceaccount.yaml"
kubectl apply -f "$ROOT_DIR/manifests/12-nginx-configmap.yaml"
kubectl apply -f "$ROOT_DIR/manifests/13-nginx-html-configmap.yaml"
kubectl apply -f "$ROOT_DIR/manifests/14-nginx-deployment.yaml"
kubectl apply -f "$ROOT_DIR/manifests/15-nginx-service.yaml"

echo "Application deployed."
kubectl -n web rollout status deploy/nginx-basic-auth
