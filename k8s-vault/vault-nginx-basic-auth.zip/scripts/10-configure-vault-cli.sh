#!/usr/bin/env bash
set -euo pipefail

HTPASSWD_LINE="${1:-}"
if [[ -z "$HTPASSWD_LINE" ]]; then
  echo "Usage: $0 '<username:bcrypt-hash>'" >&2
  exit 1
fi

: "${VAULT_ADDR:?VAULT_ADDR is required}"
: "${VAULT_TOKEN:?VAULT_TOKEN is required}"

export VAULT_ADDR VAULT_TOKEN

# Попытаться автоматически получить reviewer JWT и CA cert из service account Vault
if [[ -z "${TOKEN_REVIEWER_JWT:-}" ]]; then
  SECRET_NAME="$(kubectl -n vault get sa vault -o jsonpath='{.secrets[0].name}' 2>/dev/null || true)"
  if [[ -n "$SECRET_NAME" ]]; then
    TOKEN_REVIEWER_JWT="$(kubectl -n vault get secret "$SECRET_NAME" -o jsonpath='{.data.token}' | base64 -d)"
  fi
fi

if [[ -z "${KUBERNETES_CA_CERT:-}" ]]; then
  if kubectl -n vault get secret >/dev/null 2>&1; then
    KUBERNETES_CA_CERT="$(kubectl config view --raw --minify --flatten -o jsonpath='{.clusters[0].cluster.certificate-authority-data}' | base64 -d)"
  fi
fi

: "${TOKEN_REVIEWER_JWT:?TOKEN_REVIEWER_JWT is required}"
: "${KUBERNETES_HOST:?KUBERNETES_HOST is required}"
: "${KUBERNETES_CA_CERT:?KUBERNETES_CA_CERT is required}"

vault secrets enable -path=secret kv-v2 || true
vault auth enable kubernetes || true

vault write auth/kubernetes/config \
  token_reviewer_jwt="$TOKEN_REVIEWER_JWT" \
  kubernetes_host="$KUBERNETES_HOST" \
  kubernetes_ca_cert="$KUBERNETES_CA_CERT"

cat > /tmp/nginx-basic-auth-policy.hcl <<'POLICY'
path "secret/data/nginx/basic-auth" {
  capabilities = ["read"]
}
POLICY

vault policy write nginx-basic-auth /tmp/nginx-basic-auth-policy.hcl

vault write auth/kubernetes/role/nginx-basic-auth \
  bound_service_account_names=nginx-vault \
  bound_service_account_namespaces=web \
  policies=nginx-basic-auth \
  ttl=1h

vault kv put secret/nginx/basic-auth htpasswd="$HTPASSWD_LINE"

echo "Vault configured successfully."
