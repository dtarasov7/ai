# NGINX + HashiCorp Vault + Kubernetes Auth + Vault Agent Injector

Этот архив содержит готовый пример, в котором:

- `nginx` защищает `/` через HTTP Basic Auth
- файл `htpasswd` не хранится в `env` и не хранится в Kubernetes Secret
- секрет берётся из Vault через `Vault Agent Injector`
- Pod аутентифицируется в Vault через `ServiceAccount` (`kubernetes` auth method)

## Что внутри

- `manifests/00-vault-namespace.yaml` — namespace для Vault
- `manifests/01-vault-serviceaccount.yaml` — service account Vault
- `manifests/02-vault-auth-delegator-clusterrolebinding.yaml` — доступ Vault к TokenReview
- `manifests/10-web-namespace.yaml` — namespace приложения
- `manifests/11-nginx-serviceaccount.yaml` — service account приложения
- `manifests/12-nginx-configmap.yaml` — конфиг nginx с `auth_basic_user_file`
- `manifests/13-nginx-html-configmap.yaml` — тестовая HTML-страница
- `manifests/14-nginx-deployment.yaml` — deployment с Vault Injector annotations
- `manifests/15-nginx-service.yaml` — service для nginx
- `manifests/vault-helm-values.yaml` — пример values для установки Vault Helm chart
- `scripts/00-generate-htpasswd.sh` — генерация bcrypt-строки для `htpasswd`
- `scripts/10-configure-vault-cli.sh` — настройка Vault через `vault` CLI
- `scripts/11-configure-vault-api.sh` — настройка Vault через HTTP API (`curl`)
- `scripts/12-install-vault-helm.sh` — установка Vault через Helm
- `scripts/20-deploy-app.sh` — применение Kubernetes-манифестов
- `scripts/30-test.sh` — проверка доступа
- `scripts/env.example` — пример переменных окружения

## Предпосылки

Нужно иметь:

- Kubernetes-кластер
- `kubectl`
- `helm`
- установленный `Vault` CLI **или** `curl`
- ingress не обязателен; для проверки достаточно `kubectl port-forward`

## Важные допущения

Этот набор файлов рассчитан на типовой сценарий:

- Vault устанавливается в namespace `vault`
- приложение разворачивается в namespace `web`
- путь секрета в Vault: `secret/data/nginx/basic-auth`
- роль в Vault: `nginx-basic-auth`
- service account приложения: `nginx-vault`
- service account Vault: `vault`

## Быстрый старт

### 1. Установить Vault в Kubernetes

```bash
bash scripts/12-install-vault-helm.sh
```

### 2. Подготовить service accounts и namespaces

```bash
kubectl apply -f manifests/00-vault-namespace.yaml
kubectl apply -f manifests/01-vault-serviceaccount.yaml
kubectl apply -f manifests/02-vault-auth-delegator-clusterrolebinding.yaml
kubectl apply -f manifests/10-web-namespace.yaml
kubectl apply -f manifests/11-nginx-serviceaccount.yaml
```

### 3. Сгенерировать htpasswd

```bash
bash scripts/00-generate-htpasswd.sh demo 'S3cr3t-Passw0rd'
```

Скопируй выведенную строку вида:

```text
demo:$2y$05$.....................................................
```

### 4. Подготовить переменные для настройки Vault

Скопируй `scripts/env.example` в `.env` и заполни значения.

### 5A. Настроить Vault через CLI

```bash
set -a
source scripts/env.example
set +a
bash scripts/10-configure-vault-cli.sh 'demo:$2y$05$.....................................................'
```

### 5B. Или настроить Vault через HTTP API

```bash
set -a
source scripts/env.example
set +a
bash scripts/11-configure-vault-api.sh 'demo:$2y$05$.....................................................'
```

### 6. Развернуть nginx

```bash
bash scripts/20-deploy-app.sh
```

### 7. Проверить

```bash
bash scripts/30-test.sh demo 'S3cr3t-Passw0rd'
```

## Что делает nginx

В `nginx` включён Basic Auth:

- realm: `Restricted`
- файл пользователей: `/vault/secrets/htpasswd`

Этот файл рендерится Injector'ом из Vault по аннотациям Pod:

- `vault.hashicorp.com/agent-inject: "true"`
- `vault.hashicorp.com/role: "nginx-basic-auth"`
- `vault.hashicorp.com/agent-inject-secret-htpasswd: "secret/data/nginx/basic-auth"`
- `vault.hashicorp.com/agent-inject-template-htpasswd: ...`

## Почему в Pod нет пароля для Vault

Pod использует не статический пароль, а identity через Kubernetes `ServiceAccount`.
Vault проверяет service account token через `kubernetes` auth method и выдаёт короткоживущий Vault token.

## На что обратить внимание в проде

- обязательно использовать TLS между Pod и Vault
- хранить Vault за ingress/load balancer'ом с валидным сертификатом или внутренним PKI
- не использовать root token в автоматизации
- ограничить policy только нужным путём
- не использовать `default` service account
- отдельно настроить unseal/auto-unseal Vault
- включить audit device в Vault

## Что не входит в пример

- production-ready ingress
- HA-конфигурация Vault
- auto-unseal через cloud KMS/HSM
- ротация паролей пользователей для `htpasswd`

## Полезные официальные источники

- Vault Agent Injector аннотации: https://developer.hashicorp.com/vault/docs/deploy/kubernetes/injector/annotations
- Vault Kubernetes auth: https://developer.hashicorp.com/vault/docs/auth/kubernetes
- Vault Injector examples: https://developer.hashicorp.com/vault/docs/deploy/kubernetes/injector/examples
- Vault KV v2 API: https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2
- Kubernetes Service Accounts: https://kubernetes.io/docs/concepts/security/service-accounts/
- Kubernetes RBAC: https://kubernetes.io/docs/reference/access-authn-authz/rbac/
