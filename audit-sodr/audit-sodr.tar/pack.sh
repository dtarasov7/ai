#!/bin/bash
tar cf $1.tar *
base64 $1.tar > $1.txt 

